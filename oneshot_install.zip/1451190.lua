addappid(1451190) -- Undisputed
-- MAIN APP DEPOTS
addappid(1451191, 1, "543e5be37b6ba13500441680b3434302f89112d8f1fae261eec6e6cb245ffd22") -- Depot 1451191
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2900100) -- Undisputed - WBC Pack
addappid(2946350) -- Undisputed - Roy Jones Jr. 93
addappid(3102510) -- Undisputed - The Problem Child Pack
addappid(3525000) -- Undisputed - The Iron and Steel Pack
addappid(3740110) -- Undisputed - The Mexican Monster Pack
addappid(3870270) -- Undisputed - The Takeover Pack
addappid(4030960) -- Undisputed - The Senator Pack
addappid(4031830) -- Undisputed - The Championship Upgrade Pack

-- Auto added manifests
setManifestid(1451191,"7871995303069855279",1)
