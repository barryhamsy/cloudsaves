addappid(225540) -- Just Cause 3
-- MAIN APP DEPOTS
addappid(225543, 1, "826bcd9a6402ca627cb7da34e457666d980263f786ad5906abacb50a8dc0aa49") -- Executable
addappid(225542, 1, "65b63f137d22b4d68b224e33214ad542c811717d23a4f19e7e121152d1731284") -- Game Content
addappid(225546, 1, "dae9fcd0aba7363045c3c8cc0de6d4ca24cb1fb34c90dcc88e6b9df6c379c241") -- Patch_1_content
addappid(225541, 1, "11641ce3a84f5df9d911a42126c2ecb8c5f20fa2d238d461a88b5de57dc69e01") -- Just Cause 3 - Japanese
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Just Cause 3 - Firestarter Customization Skins (AppID: 348880)
addappid(348880)
addtoken(348880, "28524454984808304")
addappid(348880, 1, "759ac9314f330c521bfc531af78bd05432bfb7237a43342f4d5ab0645a08bcac") -- Just Cause 3 - Firestarter Customization Skins - Just Cause 3 - Firestarter Customization Skins (348880) Depot
-- Just Cause 3 - Combat Buggy (AppID: 388290)
addappid(388290)
addtoken(388290, "959059306810932740")
addappid(388290, 1, "e911cdb508c20cdcc30c076fb0c4b8a64be7636bb4b00683b364a4ea162e3dec") -- Just Cause 3 - Combat Buggy - Just Cause 3 - Combat Buggy (388290) Depot
-- Just Cause 3 - Mini-Gun Racing Boat (AppID: 388291)
addappid(388291)
addtoken(388291, "14614437623702395458")
addappid(388291, 1, "221d46b3ba7f249e83cc65f65afba635f5b66ac3a31167d9788a48cd1b510693") -- Just Cause 3 - Mini-Gun Racing Boat - Just Cause 3 - Mini-Gun Racing Boat (388291) Depot
-- Just Cause 3 - Rocket Launcher Sports Car (AppID: 388292)
addappid(388292)
addtoken(388292, "9531247583402693672")
addappid(388292, 1, "5085e3d7a4b61c21d0cf72a684d52602aaa2afd9c40a550f8ce8d754e34e3330") -- Just Cause 3 - Rocket Launcher Sports Car - Just Cause 3 - Rocket Launcher Sports Car (388292) Depot
-- Just Cause 3 - Final Argument Sniper Rifle (AppID: 388293)
addappid(388293)
addtoken(388293, "15182026358339846159")
addappid(388293, 1, "80b19c62c27174697ff80fb6f082f8a02051bc7811b44eef57a2601cf3377d01") -- Just Cause 3 - Final Argument Sniper Rifle - Just Cause 3 - Final Argument Sniper Rifle (388293) Depot
-- Just Cause 3 - Capstone Bloodhound RPG (AppID: 388294)
addappid(388294)
addtoken(388294, "646129243686930459")
addappid(388294, 1, "0d39c22766f4bcebda59fbd145a1d9b88f2233b8c616829d815fffc960d916ae") -- Just Cause 3 - Capstone Bloodhound RPG - Just Cause 3 - Capstone Bloodhound RPG (388294) Depot
-- Just Cause 3 DLC Mech Land Assault Pack (AppID: 400490)
addappid(400490)
addappid(400490, 1, "d25290f603cf2c79e74882263254326a75a0211a01e08723d1c15f7390ee9003") -- Just Cause 3 DLC Mech Land Assault Pack - Just Cause 3 - DLC 1 : Land (400490) Depot
-- Just Cause 3 DLC Sky Fortress Pack (AppID: 400551)
addappid(400551)
addappid(400551, 1, "cc8a4a34523c5eb9a480ede759873d2b64364c4fa5b185c6c1c9786d6361c05e") -- Just Cause 3 DLC Sky Fortress Pack - Just Cause 3 - DLC 3 Air (400551) Depot
-- Just Cause 3 DLC Kousav Rifle (AppID: 442050)
addappid(442050)
addappid(442050, 1, "f893150ddee9ecabf471994e4fd9c2e6b0cf206b22d835678b4a96907bea08c4") -- Just Cause 3 DLC Kousav Rifle - Just Cause 3 - Rico Weapon Customization Challenge (442050) Depot
-- Just Cause 3 DLC Bavarium Sea Heist Pack (AppID: 442051)
addappid(442051)
addappid(442051, 1, "b9ff92df30abb797203d9954b32f829786826e086a6b8c5b959ce8c4c7b0195c") -- Just Cause 3 DLC Bavarium Sea Heist Pack - Just Cause 3 - DLC : Sea (442051) Depot
-- Just Cause 3 DLC Reaper Missile Mech (AppID: 442052)
addappid(442052)
addappid(442052, 1, "007706667aa5a7c2c2c312b2569f2a3e6487d71f33df9ba92135a3b6f9c32219") -- Just Cause 3 DLC Reaper Missile Mech - JC3 DLC 3 (442052) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(401850) -- Just Cause 3 DLC Air, Land  Sea Expansion Pass
addtoken(401850, "14564498708459939306")

-- Auto added manifests
setManifestid(225541,"1911512221543433473",1)
setManifestid(225542,"1223586538567044881",1)
setManifestid(225543,"3730640572082548617",1)
setManifestid(225546,"4215009976396786371",1)
setManifestid(348880,"5864688775201349085",1)
setManifestid(388290,"8592015745330152706",1)
setManifestid(388291,"587908208119070136",1)
setManifestid(388292,"8990419076158053679",1)
setManifestid(388293,"1705723185642806420",1)
setManifestid(388294,"5803691050490662585",1)
setManifestid(400490,"6305873131564962973",1)
setManifestid(400551,"8892955897748613929",1)
setManifestid(442050,"2661530807273256948",1)
setManifestid(442051,"8949581938271775085",1)
setManifestid(442052,"6242256647832589882",1)
