addappid(368260) -- Marvel's Midnight Suns
-- MAIN APP DEPOTS
addappid(368261, 1, "70e0c68fc7e9ff3b4054bcfda8648cae98efa3b3905a29d91c2eaeee83dd9b21") -- Depot 368261
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1712442) -- Doctor Strange Defenders Skin
addappid(1922631) -- Marvels Midnight Suns - The Good, the Bad, and the Undead
addappid(1922632) -- Marvels Midnight Suns - Redemption
addappid(1922633) -- Marvels Midnight Suns - The Hunger
addappid(1922634) -- Marvels Midnight Suns - Blood Storm
addappid(2074340) -- Marvels Midnight Suns Season Pass
addappid(2100870) -- Digital Deluxe Edition Skins
addappid(2100871) -- Legendary Edition Skins

-- Auto added manifests
setManifestid(1523211,"5488617169383930545",1)
setManifestid(368261,"8365479610763304140",1)
