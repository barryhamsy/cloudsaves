addappid(2499860, 1, "1e58a20f0aa0e0d214a207103d0d8042cd3d432a0ecf06e62a381366aa724dbe") -- DRAGON QUEST VII Reimagined
-- MAIN APP DEPOTS
addappid(2499861, 1, "78d85bb7957e80d4fac0655a65ff9bee61dafc06c753de2713726e9860d6a860") -- Depot 2499861
setManifestid(2499861, "2643123553345631986", 8634368897)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3257600) -- DRAGON QUEST VII Reimagined The Road of Regal Wretches
addappid(3378680) -- DRAGON QUEST VII Reimagined Luminarys Livery
addappid(3378690) -- DRAGON QUEST VII Reimagined Jam-Packed Swag Bag
addappid(3378700) -- DRAGON QUEST VII Reimagined Early Bird Bonus Trodain Togs, Seed of Proficiency x3
addtoken(3378700, "9317591769083609258")
addappid(3378720) -- DRAGON QUEST VII Reimagined Silver Slime Shield
addtoken(3378720, "1107469435969586498")
addappid(3378750) -- DRAGON QUEST VII Reimagined Item Set Lucky Pendant, Seed of Life
addappid(3378760) -- DRAGON QUEST VII Reimagined Item Set Gold Bracer, Seed of Magic
addappid(3543080) -- DRAGON QUEST VII Reimagined White Wolf Costume
addtoken(3543080, "2047583276778140402")
addappid(3995580) -- DRAGON QUEST VII Reimagined Additional DLC Sets
addtoken(3995580, "14307469858210407774")