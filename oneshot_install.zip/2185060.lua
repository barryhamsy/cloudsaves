-- 2185060's Lua and Manifest Created by Hubcap Manifest
-- Two Point Museum
-- Created: March 19, 2026 at 14:50:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 16
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2185060, 1, "2340a2fa4b9bb44e786eb62e5866d2f8b2b4c5d73c0173273064b5a6424c5d1d") -- Two Point Museum
-- MAIN APP DEPOTS
addappid(2185061, 1, "a98101165ba3b99b3d98c5866360aa7cb08eeffd31ec95a9d024a824ff57c792") -- Depot 2185061
setManifestid(2185061, "7423407547274860665", 4987391778)
addappid(2185062, 1, "50e06e5a50d397f8af97494176ecfb9f75bb4082443bbe1fb111f44715c18d61") -- Depot 2185062
setManifestid(2185062, "3014743437142674605", 4851906608)
addappid(2185063, 1, "e68d0e65f0ced4a31e4932edecd8ff65ad2f1b503bff1b0e74faa05ae4d5356c") -- Depot 2185063
setManifestid(2185063, "6162155711228809402", 5146074636)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Two Point Museum Sonic Pre-Purchase Pack  (AppID: 2999840)
addappid(2999840)
addappid(2999841, 1, "17c8f80c3b69386aa95d085d8d9acf78ded50c7d234c3fe760843b1854e57d5d") -- Two Point Museum Sonic Pre-Purchase Pack  - Depot 2999841
setManifestid(2999841, "4641401289589527075", 51241216)
addappid(2999842, 1, "c17024c21617ad2a2c48ab1ef147fa5631840f4a8e92735f4ceddc9bcf4aa2cb") -- Two Point Museum Sonic Pre-Purchase Pack  - Depot 2999842
setManifestid(2999842, "5701886906430894855", 51586977)
addappid(2999843, 1, "e9ef0ab3c1526da46248fa2d6b362fe47d752025d6737c04217e276330a0f57f") -- Two Point Museum Sonic Pre-Purchase Pack  - Depot 2999843
setManifestid(2999843, "4483154084420526161", 51241211)
-- Two Point Museum Explorer Upgrade Pack (AppID: 2999850)
addappid(2999850)
addappid(2999851, 1, "08a857d0c27299f066279413cf450e11262163e9fdd33ed8146402834a75a318") -- Two Point Museum Explorer Upgrade Pack - Depot 2999851
setManifestid(2999851, "5303984816366019077", 25535155)
addappid(2999852, 1, "6a30c41e89a00e6dccd56cde848599d00d6f98edb86f68d8ad3ca11a7772fbb7") -- Two Point Museum Explorer Upgrade Pack - Depot 2999852
setManifestid(2999852, "8918481798725075022", 26156141)
addappid(2999853, 1, "02e1edb27de1b992bbac282fe43c00b39aced6b5b1ff1e6dce02a711d64adbe4") -- Two Point Museum Explorer Upgrade Pack - Depot 2999853
setManifestid(2999853, "3836550410533387658", 25535155)
-- Two Point Museum Fantasy Finds (AppID: 3592600)
addappid(3592600)
addappid(3592601, 1, "8fc6c6248dc796e6fd5cc6834560bebbe05cd43fca1209ce06cd28d42a3421b1") -- Two Point Museum Fantasy Finds - Depot 3592601
setManifestid(3592601, "2039674076927037602", 125746283)
addappid(3592602, 1, "f176a616fceffd4977533324e8cbecec75de625ac741be1563f35bc159674382") -- Two Point Museum Fantasy Finds - Depot 3592602
setManifestid(3592602, "7997083216902393500", 132909373)
addappid(3592603, 1, "d0e5329d3415a09f040f4c36085ad1ecbe427e72f8505095a0798f4d0068b0e9") -- Two Point Museum Fantasy Finds - Depot 3592603
setManifestid(3592603, "7356652839589231519", 125746279)
-- Two Point Museum Zooseum (AppID: 3804850)
addappid(3804850)
addappid(3804851, 1, "245b7148e9c97035fcc19d3bb6286994fe4bbfec32c17a6803f915ce8704d421") -- Two Point Museum Zooseum - Depot 3804851
setManifestid(3804851, "6399295225169265925", 119824979)
addappid(3804852, 1, "a583d14bddd9f6fc992424ce67bf9b15784a5f4955af01eb3cd14f80a12d606d") -- Two Point Museum Zooseum - Depot 3804852
setManifestid(3804852, "6378796147817521033", 125899905)
addappid(3804853, 1, "1e6e361d4b7c2b23303f99e11c058d5e82c3112aa3f0111e1ae7966c40e0070b") -- Two Point Museum Zooseum - Depot 3804853
setManifestid(3804853, "2065046130223408671", 119824984)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4114071) -- Depot 4114071 (empty depot)
-- addappid(4114072) -- Depot 4114072 (empty depot)
-- addappid(4114073) -- Depot 4114073 (empty depot)
-- addappid(4511681) -- Depot 4511681 (empty depot)
-- addappid(4511682) -- Depot 4511682 (empty depot)
-- addappid(4511683) -- Depot 4511683 (empty depot)