addappid(3369070) -- Law School
-- MAIN APP DEPOTS
addappid(3369071, 1, "fb1cf4f7ef604c1c832043b3d97f863d9a62c048ccc044f94f0eb009d99b9f78") -- Depot 3369071
setManifestid(3369071, "8449570328570396375", 8623958569)
-- DLCS WITH DEDICATED DEPOTS
-- Law School - Season 1 - Official Walkthrough (AppID: 3836080)
addappid(3836080)
addappid(3836080, 1, "8e06b897611bb074aa685d2d0bcfe7e9d8a3de0debb388895d8e7e626772f166") -- Law School - Season 1 - Official Walkthrough - Depot 3836080
setManifestid(3836080, "4280835069092400133", 19243004)
-- Law School - Season 1 - Wallpaper Set (AppID: 3838750)
addappid(3838750)
addappid(3838750, 1, "465d4256a1afb50cd95b121bd8ea3631aa16d894331fdaab1420ecef77cae91e") -- Law School - Season 1 - Wallpaper Set - Depot 3838750
setManifestid(3838750, "8751417086461103855", 382551435)