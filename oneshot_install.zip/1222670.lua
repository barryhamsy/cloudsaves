-- 1222670's Lua and Manifest Created by Hubcap Manifest
-- The Sims™ 4
-- Created: April 10, 2026 at 13:22:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 877
-- Total DLCs: 55
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1222670, 1, "9d02e30149094ff85e5614fd8f0b25b48c497110f54dadbd3a169b66ed71908f") -- The Sims™ 4
-- MAIN APP DEPOTS
addappid(1222671, 1, "e1124bb686138cfe075e28aaf22b23cfe9229021b5d5763ce6c101a8f04ea17d") -- Telstar - Wright Content
setManifestid(1222671, "2135158870061583748", 28029868612)
addappid(1222672, 1, "db57b3748618a0de3ec60324c0c9048ad39cf06ff86c89c4a743b106542e1069") -- The Sims 4 - en_US
setManifestid(1222672, "3168269724576777407", 11231862)
addappid(1222673, 1, "1f3153ffdf2ceb3515822766568e30476dcccd1ba3e4e230bd9e45d0c5c9e801") -- The Sims 4 - cs_CZ
setManifestid(1222673, "715794034684798276", 13432906)
addappid(1222674, 1, "0280ef9b1d04f625d78568d180dca65bbe2ab287b413a2552638dcdb6f61b1bc") -- The Sims 4 - da_DK
setManifestid(1222674, "7593076995308958403", 11229226)
addappid(1222675, 1, "86c063296cd675d5197c31864ced3f272fb02fad0b1785b971b643f3ed4cb2a8") -- The Sims 4 - de_DE
setManifestid(1222675, "5657107715878596301", 12066436)
addappid(1222676, 1, "bbac56ab6638b9871cf0510995667864a806b58f91510ce8bba0554d84930e95") -- The Sims 4 - es_ES
setManifestid(1222676, "9216601062695578160", 12936389)
addappid(1222677, 1, "5450468d98b119cec8d5f3f4a7e25d07b8dbb69d93ef5ac363808c748fca88d9") -- The Sims 4 - fi_FI
setManifestid(1222677, "7936012316829194467", 12591359)
addappid(1222678, 1, "09fc3c3bb7500a4e669130b9e367bb75f654b497f42aeb9a20fede233131d5cf") -- The Sims 4 - fr_FR
setManifestid(1222678, "4924703277184656025", 12567783)
addappid(1222679, 1, "b249c84a1e3053f85053d1ad13bc133266da11e3726270be83cd2253cedd9472") -- The Sims 4 - it_IT
setManifestid(1222679, "4532129697335637317", 12272451)
addappid(1235723, 1, "76c7b0405dbb1c3d968cfcb10063a45caa485ca62326462b246eeab94cbb7615") -- The Sims 4 - ja_JP
setManifestid(1235723, "8794189190268893900", 12711738)
addappid(1235724, 1, "79af07f74134b091c2ffbe29ab41900658f649241f775e3cc77516bc16a3a93a") -- The Sims 4 - ko_KR
setManifestid(1235724, "5451709162779195977", 15900021)
addappid(1235725, 1, "ad46ac7f24e5852ca09f0ad344f095bed7ded3c845527c02685eaa5d43c5dcbf") -- The Sims 4 - nl_NL
setManifestid(1235725, "3010081345108249274", 12377240)
addappid(1235726, 1, "d35e2e550467ea9f70b0132be3046fc6596a2b2d316b422fde9f68e0982fb9a9") -- The Sims 4 - no_NO
setManifestid(1235726, "2552252296067571815", 11563642)
addappid(1235727, 1, "b341180d6ed2983b13878d0b5084223b6f0820477dbb23c9dfe9a09cff06a62c") -- The Sims 4 - pl_PL
setManifestid(1235727, "1713403548664541654", 12868138)
addappid(1235728, 1, "08c729f6eea34298bfa862773efef2f7bdbc6b34c0e61faa1470af73ffa5170b") -- The Sims 4 - pt_BR
setManifestid(1235728, "3777640655664744816", 12324458)
addappid(1235729, 1, "3646836b7f1babe0400bd9e82b91ea5c7d985c8ac522b0e6b821fc18f8d8006c") -- The Sims 4 - ru_RU
setManifestid(1235729, "1588975526626957178", 14334802)
addappid(1235735, 1, "378924290af63f536c8a487f76b078b03cb845c3ec5fd4b3e3dbe8c460f30b49") -- The Sims 4 - sv_SE
setManifestid(1235735, "5976807900576303256", 11155861)
addappid(1235736, 1, "6f6e3c611cc2e22dccba6fdb8ba18fd81d6c98e42688eae95c0238d923fa39d8") -- The Sims 4 - zh_TW
setManifestid(1235736, "153762268265288460", 13297662)
addappid(1235737, 1, "f1347fb7c75ee199910446fc99b640f38ef06884c30198a7b9b437e6f83eb380") -- The Sims 4 - zh_CN
setManifestid(1235737, "7669375743215487284", 15320285)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "543852336262541558", 242619127)
-- DLCS WITH DEDICATED DEPOTS
-- The Sims 4 Get Famous (AppID: 1235720)
addappid(1235720)
addappid(1235720, 1, "76f4d3b559bf2c31e90d7fec4d9548d042c1c149771cfedfd97de04893a05a89") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - Content
setManifestid(1235720, "6325242057672701391", 2837669882)
addappid(1242600, 1, "d5794cd59bf286e57ee93ca20df0b3bf6a3a752a3da0191160155eee2778e580") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - en_US
setManifestid(1242600, "2108865334864484938", 198520)
addappid(1242601, 1, "4fc4e8b32ee969f118d0aef5a552fde772b825aaf604f8997a25fb3f59b7e6a4") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - cs_CZ
setManifestid(1242601, "5870567455343886111", 198369)
addappid(1242602, 1, "da31d7bc1e5ba1ba78fc5c11843a0231de395fbeaa39fd34cd4a16de23713e4b") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - da_DK
setManifestid(1242602, "4003059623204408481", 171473)
addappid(1242603, 1, "13fe96a21341864b8cc528852351c2fdbe313fafa5daa93dbbd74510728e9fd0") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - de_DE
setManifestid(1242603, "8082882235201707219", 184974)
addappid(1242604, 1, "75a5c57d23ecfdca2b118c3e334688d52274bba166e8810694b79ba09c9d5082") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - es_ES
setManifestid(1242604, "7200494567676926249", 189139)
addappid(1242605, 1, "7291cc2b79799427dca37d8d3c6936ef051f3d1a2a9e8e3e164aacc04019e4f3") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - fi_FI
setManifestid(1242605, "3179515884013234521", 173321)
addappid(1242606, 1, "52c4b5618684908bf6257b5ad8663ca1ca74a87a6cbca9362347fbde948f50ae") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - fr_FR
setManifestid(1242606, "4237049483786533678", 188869)
addappid(1242607, 1, "8150d2e48b256aeac4e6cb0292f5b2b4ed01bee603c8a29ba22238fa4568fa40") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - it_IT
setManifestid(1242607, "8691217806034292625", 188520)
addappid(1242608, 1, "8b24c57a91ff20e48394aecd85425531ee0596c86ebaa8aa6feebe568406c896") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ja_JP
setManifestid(1242608, "241101040712163319", 187141)
addappid(1242609, 1, "d09a1607ac35d5ec3f9d99edf6ada4eeb238cd4d57f02d176af74986557fcbfd") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ko_KR
setManifestid(1242609, "1989685558969682712", 186543)
addappid(1242610, 1, "e176ec57ef5f82eea5d5f06a2004102d1c035ed9ac9d80a456d1d938b9f2e4cd") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - nl_NL
setManifestid(1242610, "4808818524355985454", 178379)
addappid(1242611, 1, "a41d3aa000f61f68c1e7f15886da25acde87768d62c99466b7110dc87cc7a4da") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - no_NO
setManifestid(1242611, "3158376292276503528", 169452)
addappid(1242612, 1, "fcd533f9aef2d7f5e0e16644cbd2fd16586cb02de3ed7e27e5e18cef78ced037") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - pl_PL
setManifestid(1242612, "6025670612442680558", 201861)
addappid(1242613, 1, "736b74034ad04a7c6ea9f789a03da7f4011d32a9189829ed40bce644116e252f") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - pt_BR
setManifestid(1242613, "3135130981732956581", 175853)
addappid(1242614, 1, "3d407d6d8165d31cf48f5782c2032680cb8880e189735287763ed8b4db4ead02") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ru_RU
setManifestid(1242614, "5860368017169406036", 212121)
addappid(1242615, 1, "998c7ec70332931e03c530640fc9881e11c3488ae14761ec63e9dc4f7ed3d29d") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - sv_SE
setManifestid(1242615, "3041622873872796341", 174996)
addappid(1242616, 1, "8b54d895ee7bd768211472a6097701e9d8b0f46110c8355650d992b4280d9f52") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - zh_TW
setManifestid(1242616, "3549811072909537871", 175903)
addappid(1242617, 1, "2c22805745266e0c4952b11df8b4cd0c04f8b882bbcf5b982984a1115ccaa31f") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - zh_CN
setManifestid(1242617, "9028980526056834985", 198520)
-- The Sims 4 Cats  Dogs (AppID: 1235721)
addappid(1235721)
addappid(1235721, 1, "483dff514bd49bfb7ed68486c8f2f97834e6004126684107795cd576c12ba1b9") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - Content
setManifestid(1235721, "9086962343724239942", 2064616909)
addappid(1242580, 1, "b31829f51ea023d1c7a2835040c7ae6fa09c3327f2613c9b8173c000bf6af61a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - en_US
setManifestid(1242580, "8484619274161251026", 110367)
addappid(1242581, 1, "08de37fe5b88d9a4b60c76c79562a06d5ae157285158c1e50fa3cdc7ecb7fb2a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - cs_CZ
setManifestid(1242581, "6581605435672353838", 116685)
addappid(1242582, 1, "0691c52806cfa895467a0b75de948a7644f453e54511e37ff0415f86e41ffd64") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - da_DK
setManifestid(1242582, "6169970643601981009", 103209)
addappid(1242583, 1, "28f0cb2c70545a9a6247fe8e0584e708b3be82281a9b4c50b52d3579131d7a22") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - de_DE
setManifestid(1242583, "2664024488111822321", 112280)
addappid(1242584, 1, "8d0ec291f23725ee9f6491d7c74058e8bbc816abcf9f303ac2fdb50bb39b780c") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - es_ES
setManifestid(1242584, "6024856952031850200", 116615)
addappid(1242585, 1, "16d602d5159734e426121c1a8e59fd1c5d7a57b6fdbb0f5552b2339813d43cea") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - fi_FI
setManifestid(1242585, "492509312762640339", 105632)
addappid(1242586, 1, "72ea442535bf9d43aef53468cc69bb70f9b27faf048b309f137334e4a133b5d5") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - fr_FR
setManifestid(1242586, "272368889964694255", 122227)
addappid(1242587, 1, "0616f103dad25cd754ada16b1458d4804fa2ce91fea29073f265e667154f355a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - it_IT
setManifestid(1242587, "6868112341964486323", 114106)
addappid(1242588, 1, "2c0d2db0f52a2d694ad178546346b0c4fd0d9e273024a94495f106a9ee687448") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ja_JP
setManifestid(1242588, "1842094718638948002", 128413)
addappid(1242589, 1, "47ba97d4de79282c9e236f89f31bf6f4846b75f924b56a092d53a3381bfe2010") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ko_KR
setManifestid(1242589, "3607921350391850871", 119234)
addappid(1242590, 1, "4d9cce1be26628b33d4b2e7aa06e6a2329dc7d74aad8d2036e3b059fe2965502") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - nl_NL
setManifestid(1242590, "5622135489170566759", 109008)
addappid(1242591, 1, "6e1f356250bc32b6f079288a45ae4dd895f38c3156d52ed6467302d160462e33") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - no_NO
setManifestid(1242591, "4377690052289102787", 102415)
addappid(1242592, 1, "84f3524ca6c25b77092b70d8f5b649c2223e6aa4c580d50676965dc01f14d15b") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - pl_PL
setManifestid(1242592, "1283490465015792787", 121840)
addappid(1242593, 1, "35f1d37b8e256ade785397b026864364246b38668cff2403d46764793b70bc54") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - pt_BR
setManifestid(1242593, "7476867880952364178", 108380)
addappid(1242594, 1, "316f289d0b4e99cd3a36cc15f5ff0277bedd314fd7b9382bbb6e21178ae3e510") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ru_RU
setManifestid(1242594, "4168806290662854046", 136727)
addappid(1242595, 1, "5357003ca14ceb98c8b4312f5b2e5141e5ab90ccceaa3fd0fdc460d5fc560d1b") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - sv_SE
setManifestid(1242595, "3472199484053926615", 107194)
addappid(1242596, 1, "2c8ab95723e7cfed205a13b9ffae75993dedc7c9120124579e9b8decb8a6fcf6") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - zh_TW
setManifestid(1242596, "5601305376358742770", 107392)
addappid(1242597, 1, "caaa64c2a3ba798ae9cc7c10384ab47405ae0b471d8791118dcc92f2db6d9b61") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - zh_CN
setManifestid(1242597, "5933538540421236353", 110367)
-- The Sims 4 Discover University (AppID: 1235722)
addappid(1235722)
addappid(1235722, 1, "2545f32279adbfc9d01ae04b3f218c0a44a03f902bb0193fabbbd2742114f2bf") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - Content
setManifestid(1235722, "4161775297590235225", 1648297279)
addappid(1242560, 1, "b9cd7163c51538c85cd1184c755a7eab59c260455085c30e68e7a84190c9fafb") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - en_US
setManifestid(1242560, "6271724699101406804", 221016)
addappid(1242561, 1, "1f1d8d62b6cdbad96484e6ab498109254cadf1c22aab7bec4ad875c616080173") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - cs_CZ
setManifestid(1242561, "4538139317361157257", 256001)
addappid(1242562, 1, "6f34a99bdba362632647149f675d917e7a53de93eb28f7a6be51629279511175") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - da_DK
setManifestid(1242562, "7944025469788410644", 217865)
addappid(1242563, 1, "3d4291b91f19ebe58b7d7d7663cf515cddd014f08adcaff2f12c5b648dabc21e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - de_DE
setManifestid(1242563, "2338741138613953453", 244248)
addappid(1242564, 1, "8998da3a8d5a06310883b6d3cadbd927f6cb3cfc7e992dca2c822ae44da19e1e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - es_ES
setManifestid(1242564, "6947783648345496350", 245107)
addappid(1242565, 1, "093013a9c9629039b8c6384b9f9bc7f6d0857a09ff2e52e9440ebd8864463f9a") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - fi_FI
setManifestid(1242565, "5012611329462008093", 217177)
addappid(1242566, 1, "ce72c122e3d7a6e0f8069bd470e9e67c9a7ddf6173cfa0a0392e8b657ac5ca5e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - fr_FR
setManifestid(1242566, "842253432851676587", 242340)
addappid(1242567, 1, "6eb4cd371843458b15fc4e7709ff3144200291cd1539e3ef374dd3e756ad08a0") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - it_IT
setManifestid(1242567, "8187349436974426158", 242246)
addappid(1242568, 1, "bc05bb9448cab6d8989a33ba9b771e4c613864c582f6c058cdd08e66a6ba4d26") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ja_JP
setManifestid(1242568, "6759444856586355851", 245013)
addappid(1242569, 1, "f0c66dc164ef8f25ec5365943b55dc7ba7b218617ce55105b3f6ad7929410dc2") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ko_KR
setManifestid(1242569, "7103235641840852756", 236422)
addappid(1242570, 1, "1241ca2804c37090794ec587b0c96bda7e29471006d12ff7cc89a1d53c83693e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - nl_NL
setManifestid(1242570, "1592465266106020966", 229803)
addappid(1242571, 1, "07f120a282f98bded6d82988edeba01ec91b96e6f445903ea8d9f7ec4913c7ef") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - no_NO
setManifestid(1242571, "8128838377079220112", 224052)
addappid(1242572, 1, "d9717961f568b90efdb71b83a05d9fc0d9c816c001f9be43bf3020afa9286c61") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - pl_PL
setManifestid(1242572, "5863000441993125450", 254055)
addappid(1242573, 1, "82dd006270258cce2d65345d9cb7e7ca01822cc648636de74296795bf9e5b8a8") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - pt_BR
setManifestid(1242573, "8391514878759082649", 224513)
addappid(1242574, 1, "9eed9f834d80ed1063e5bc4768e00a4bdc9f0ceaa06833a68b8365b208073f30") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ru_RU
setManifestid(1242574, "6192739367161611732", 264941)
addappid(1242575, 1, "8a2f9f33a2a3ad963041546c7ada095ee3d24c4146857ad79ad0107cb426cf19") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - sv_SE
setManifestid(1242575, "4255632882519562763", 220995)
addappid(1242576, 1, "d13f25dc0273a49e5d58c85006cde6d7f7131cb78a3f6289396d3686ef76a047") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - zh_TW
setManifestid(1242576, "8325336312256928115", 227144)
addappid(1242577, 1, "7964888ea91e1727f2eba18024e36fee1b0649271d95da1b18bea53c589b450e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - zh_CN
setManifestid(1242577, "836622111375658928", 221016)
-- The Sims 4 Island Living (AppID: 1235730)
addappid(1235730)
addappid(1235730, 1, "5e8313df06231219c9c25f8af37432ad21a315d8789674b1393840aa8fd2c29f") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - Content
setManifestid(1235730, "6143932567917424002", 1475385885)
addappid(1242540, 1, "03d316e616ad469cb44cf76fd6b4adbe39455fe9f765d845dfffe850200496cf") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - en_US
setManifestid(1242540, "7369236675522932733", 116563)
addappid(1242541, 1, "fb3b5ecc31b8f312d7fa89c0c1778f5d09189dabcf6c05cb72a2c6b4999b8164") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - cs_CZ
setManifestid(1242541, "2862870517106319637", 141257)
addappid(1242542, 1, "93867a55f077acdc38a577f1ab7c8a5040dbe25112c61f7a6caaab418fe7524e") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - da_DK
setManifestid(1242542, "4938049338990592049", 117120)
addappid(1242543, 1, "cb3e5919ce5d590d23b96a9922906634ac868685be42da871407f5a786c60538") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - de_DE
setManifestid(1242543, "9086857771814998889", 132886)
addappid(1242544, 1, "cedfc7394ed20e68bf8e6e684319f5f359ad6641fa40dcfb1d11c2266135ebf0") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - es_ES
setManifestid(1242544, "5662266509352918163", 136571)
addappid(1242545, 1, "ed2104cdfc541248a8b980fb9477c581636160ca770150eafd213c1d48570d77") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - fi_FI
setManifestid(1242545, "6024525803345414720", 116071)
addappid(1242546, 1, "c6b9718eb6293793ecdde475351186fc47ed4eb229a7afae93e42bcc657a2c27") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - fr_FR
setManifestid(1242546, "2161586564892300476", 136900)
addappid(1242547, 1, "09968dd4e6b6edd7adb58a65a575709d3bb3ac40af9082ffc4cb0e3121b6db5f") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - it_IT
setManifestid(1242547, "7946494387624230065", 133565)
addappid(1242548, 1, "216ba5c03bc607009f5c9174a44df5760cd785497be4b6f01454e84a98d31ee1") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ja_JP
setManifestid(1242548, "1043579398519252919", 134639)
addappid(1242549, 1, "cc669e800ac637a46abfe39d50604634bb7e617c0e9d895a5165cdd93605fe01") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ko_KR
setManifestid(1242549, "2118060499878066120", 132158)
addappid(1242550, 1, "61f5808a718df45a54cfd1e1f3d75d056ad7febc27af35b4af08ebb0de471a89") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - nl_NL
setManifestid(1242550, "4209395812060076907", 126996)
addappid(1242551, 1, "3e7ecf63b29610ff473167a6cc8e0c917fae3e56a77d37b07ad037a244b21388") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - no_NO
setManifestid(1242551, "3668729064239050013", 113139)
addappid(1242552, 1, "016f8e211657d1c3cdf350144ba4f11165807ea45383041ab3a94d040e36ef23") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - pl_PL
setManifestid(1242552, "1418224608329251328", 143305)
addappid(1242553, 1, "eb9833c4063ae4fb7c473219a14908cfa883c940e1ec5f23bffe742a1cbd486c") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - pt_BR
setManifestid(1242553, "9192083283965584", 116855)
addappid(1242554, 1, "bde62fffe4097a2b87de0e67e44b6fd35c6dfe722c0ea44b098b546637fcf93d") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ru_RU
setManifestid(1242554, "2717787382833612414", 146118)
addappid(1242555, 1, "4d131733e81de463cee8f3586724bc7ed8d335fd4b275469f31fb4955c0944bd") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - sv_SE
setManifestid(1242555, "8340136860536011314", 117054)
addappid(1242556, 1, "349dd497f2d68bc3c6dd62237d09c6aed51210f45a77976e4faaa2beea5c930e") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - zh_TW
setManifestid(1242556, "4411472977851619696", 120457)
addappid(1242557, 1, "4e0dd93a490320ba7a337ce69420313f040e6b455a8ed9347bd2a345655acd3d") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - zh_CN
setManifestid(1242557, "7782509144900445149", 116563)
-- The Sims 4 City Living (AppID: 1235731)
addappid(1235731)
addappid(1235731, 1, "6d7aab23cbaec96118a4e48b93128cb763d1ad95c1bfd5c1cce3e6d5d6ad0d3c") -- The Sims 4 City Living - The Sims 4 City Living EP03 - Content
setManifestid(1235731, "8158890407416800855", 2661811216)
addappid(1242520, 1, "5f1533c8b0e89268f59e03a873b1bac518cfe6b6d44a74ba5aff8708d6132de6") -- The Sims 4 City Living - The Sims 4 City Living EP03 - en_US
setManifestid(1242520, "3768523129452294018", 191705)
addappid(1242521, 1, "3dee0b2e8737fc05ed6d505a5777a9d1a6d392eb026edaecad3b9c188187475c") -- The Sims 4 City Living - The Sims 4 City Living EP03 - cs_CZ
setManifestid(1242521, "3511000701135508140", 210042)
addappid(1242522, 1, "c88843e35deb5ac665644528237813e260dea0f76839b9d2ac83a12283ca1676") -- The Sims 4 City Living - The Sims 4 City Living EP03 - da_DK
setManifestid(1242522, "5695105673708565324", 190350)
addappid(1242523, 1, "8e3db3c5a8814013480b6f0fcce791d3939702186a68f4701b432665ae81acf6") -- The Sims 4 City Living - The Sims 4 City Living EP03 - de_DE
setManifestid(1242523, "6944944507742658307", 207083)
addappid(1242524, 1, "6b0d762043b55dc20a1d57c10e91f6946f8aad9fca82169bf603e989de3fe393") -- The Sims 4 City Living - The Sims 4 City Living EP03 - es_ES
setManifestid(1242524, "773444600102464022", 207132)
addappid(1242525, 1, "7987c0ec5c9630736a97fd7a40e94a9ea80a20c092158dd1e210042044569404") -- The Sims 4 City Living - The Sims 4 City Living EP03 - fi_FI
setManifestid(1242525, "2627509777706573273", 190670)
addappid(1242526, 1, "f35a35fdc3d81e3bf65d5ccbd5d9d6d3f33bfc28bc77cdfcb9d6d8515a6f5284") -- The Sims 4 City Living - The Sims 4 City Living EP03 - fr_FR
setManifestid(1242526, "1288329591593694361", 205774)
addappid(1242527, 1, "5fc267f6f983f0fc41416b6f9b9f3f620826b1b561af6fab7ecfea71d2a164c0") -- The Sims 4 City Living - The Sims 4 City Living EP03 - it_IT
setManifestid(1242527, "2203318620910022221", 204506)
addappid(1242528, 1, "7d99b15647b43b650f9118dd9be36d3f84631260430ae0cbffd7ebc54c4fbe6d") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ja_JP
setManifestid(1242528, "2639139179016129137", 211834)
addappid(1242529, 1, "61607aaee4a594e99ae54c5f3964a5bd85a5eb61d4ae5c1aea34af1951dec8be") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ko_KR
setManifestid(1242529, "1309628900044534989", 203958)
addappid(1242530, 1, "13222ba49ba7a42aaa1f3a7e43ada1088b014dbf6ac6290f6491a737a4731294") -- The Sims 4 City Living - The Sims 4 City Living EP03 - nl_NL
setManifestid(1242530, "7763502780943932170", 199065)
addappid(1242531, 1, "0c11ebadaa5b3078c720bea79128c7e2874dcae86d24210ac6069e5ce654a03f") -- The Sims 4 City Living - The Sims 4 City Living EP03 - no_NO
setManifestid(1242531, "2484992119815601085", 185562)
addappid(1242532, 1, "438855c72ef9f2679e27fedb05b78708674a6d74f004451656e4c221e36d4894") -- The Sims 4 City Living - The Sims 4 City Living EP03 - pl_PL
setManifestid(1242532, "8298742264149554746", 219408)
addappid(1242533, 1, "0df2f0bbf333fcbb1f65d8d4d31fd3bc0afd5a5d8929f201b747fcad2a5a4dd7") -- The Sims 4 City Living - The Sims 4 City Living EP03 - pt_BR
setManifestid(1242533, "2604249077208746265", 195425)
addappid(1242534, 1, "4412d858bade6fa72315ff27f8f8234a89fa90e82555d0239eff971b3e090ded") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ru_RU
setManifestid(1242534, "7884914245232242381", 236085)
addappid(1242535, 1, "d35c755226e8219a44930695c8de852b69bbf7af485c24b5c500c5f379c8ff98") -- The Sims 4 City Living - The Sims 4 City Living EP03 - sv_SE
setManifestid(1242535, "8854996162109434352", 189790)
addappid(1242536, 1, "389251124fbd8e802d28d030ad042d53c155ea30893f43a021e3dbe806c63329") -- The Sims 4 City Living - The Sims 4 City Living EP03 - zh_TW
setManifestid(1242536, "7158015139351666915", 195562)
addappid(1242537, 1, "5fbe2eecdea9c52bb8b6de52d5f11e2feabec1be35d759648323216ffa6b1d9d") -- The Sims 4 City Living - The Sims 4 City Living EP03 - zh_CN
setManifestid(1242537, "959187949599604399", 191705)
-- The Sims 4 Get Together (AppID: 1235732)
addappid(1235732)
addappid(1235732, 1, "8bc663d1862329d5e336025099a6283180bdd74641a56449c76eac28468ca2cd") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - Content
setManifestid(1235732, "5740741335545402792", 1767569433)
addappid(1242501, 1, "d58f23b65647bc328733eae187997ecfa33936ddd7aea09eb258b677f57f7977") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - en_US
setManifestid(1242501, "5817259516154196170", 98543)
addappid(1242500, 1, "934f95c36fb3f0efaee4cc715331294694119b0f41767f0cbd35e0b182c8a8ca") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - cs_CZ
setManifestid(1242500, "8218978204338890794", 107813)
addappid(1242502, 1, "3ef787252f49be7904a1d69000c937c2192e555c7b4709fb345003049d04cd0b") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - da_DK
setManifestid(1242502, "6567287168194482378", 96355)
addappid(1242503, 1, "9d3073126fcf43ebc6bcd8f64ee713bfd6e4d0a0a0dd68a0ac9c35c050b0c0e1") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - de_DE
setManifestid(1242503, "8409135777778642593", 104116)
addappid(1242504, 1, "3af973b39a580769e7358175398cb70b8b7e7ca7c3cfc012d39c9fd6cda50968") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - es_ES
setManifestid(1242504, "117431131698632604", 105802)
addappid(1242505, 1, "4ed4b2eb49caab04ff97e8db56fe49661f2addaa2656c627a5b2dba4d9c7a678") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - fi_FI
setManifestid(1242505, "286987497531929276", 95641)
addappid(1242506, 1, "bce117fd50204ab12af561a06be5307e1eb757462ef2cda046a259c098f7961b") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - fr_FR
setManifestid(1242506, "5490677066866060648", 104171)
addappid(1242507, 1, "01e387d2248626f86e28256fe1f8b015d84c6401e85dcc841a3d462979b8df27") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - it_IT
setManifestid(1242507, "8807678469386094205", 102812)
addappid(1242508, 1, "ce84fe991ba98a3190b1c269a13f602001990791b0c24e35bb7afd2479da45c6") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ja_JP
setManifestid(1242508, "6472535594125996639", 113191)
addappid(1242509, 1, "cff56860521df4b7cf1fa11c7f3db98ef569600b78f3354eabc593fdf17a4dac") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ko_KR
setManifestid(1242509, "7542733849775610347", 103583)
addappid(1242510, 1, "0b8676560a7b96b8571c14fc1528c0efb15d0b27c0f90936e73ad52c99fac9f4") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - nl_NL
setManifestid(1242510, "639634895547504020", 102363)
addappid(1242511, 1, "d0b44ded560bf148c636a96d85a138fe4bcb9e8448f5c86f9578372576412b52") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - no_NO
setManifestid(1242511, "8977753778643378834", 96457)
addappid(1242512, 1, "1aae5163b86cb73c2c6e6a7d02ec73987c176148b213d777436c7a87c315deea") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - pl_PL
setManifestid(1242512, "5098069454062282475", 110475)
addappid(1242513, 1, "8b788f23f74167ca0519244a5966cb8af44278ae0ac0fc34b9d99dbf4ea57fd6") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - pt_BR
setManifestid(1242513, "2578616218338255866", 99604)
addappid(1242514, 1, "c9a71e883489fed647ee549d6d684f8d4507e02941cb4bd26fc028b7a3ef362c") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ru_RU
setManifestid(1242514, "8020779058145008226", 125247)
addappid(1242515, 1, "8ffb76a4e64cbd3a9e3c2e648fd3ac333fb828252e228f6ba67e53271388134f") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - sv_SE
setManifestid(1242515, "297249876989966683", 96784)
addappid(1242516, 1, "04a7cb531d4f08c7900e4c6366b0d54ab4a066cf869bdee0cfa422669eaec696") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - zh_TW
setManifestid(1242516, "8524811292877319448", 100864)
addappid(1242517, 1, "cc1a1cff83c5a22a6cb99c0cfb3a59536b5bfb3c917adcec2846ee6e7edb88b9") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - zh_CN
setManifestid(1242517, "101615805909286570", 98543)
-- The Sims 4 Seasons (AppID: 1235733)
addappid(1235733)
addappid(1235733, 1, "af51b2f926d4bc8e82a0fcd3e1fdd584dd195a11b8f1ac833418a9caacdc84b3") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - Content
setManifestid(1235733, "7184087045981196752", 1435574088)
addappid(1242480, 1, "7fd9980d2e5e63eb951f1623930db503cc757e096bf70abe40fdc7b792df5921") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - en_US
setManifestid(1242480, "3748126240313561416", 100863)
addappid(1242481, 1, "2667e2fdeed7236bdb427c57402d9559b0cf515dba4082e763b57cc64c9eb956") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - cs_CZ
setManifestid(1242481, "2665815000527830810", 121303)
addappid(1242482, 1, "a17aa075b8d644536ca55642105716e565af7eeb57ecc770a14cad90fd63fe1e") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - da_DK
setManifestid(1242482, "9181123564175570139", 98734)
addappid(1242483, 1, "cfbc271f35a9ca1179907d6c6a5cfbbeb1e7389fc42275bd78c97ab61cc2dc76") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - de_DE
setManifestid(1242483, "7318408475755797745", 104927)
addappid(1242484, 1, "4154289dcc74fe2a1692575d351b62a534b8e6adbce712d4e885679784b07af7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - es_ES
setManifestid(1242484, "1821279756047980203", 108226)
addappid(1242485, 1, "888c22e5eeec6283f2ded4cc99994dd7c17a037f89ac209e4b04b8a13f8e0aa1") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - fi_FI
setManifestid(1242485, "8989082932498896267", 99150)
addappid(1242486, 1, "49834d70704b7363d7c1fd0b260379a46a433a4430eb41cae17b619b8be930cb") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - fr_FR
setManifestid(1242486, "3920000503190633545", 116493)
addappid(1242487, 1, "3301ce54343556bf1262c94adc28dff951bc47edcf09b4618eab00684e356358") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - it_IT
setManifestid(1242487, "7513532182688085862", 106283)
addappid(1242488, 1, "f483c7678b4d8f80d83fc1fe38840487de394536eeb8edd8a247d7777b9711cb") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ja_JP
setManifestid(1242488, "7088531467821465573", 115521)
addappid(1242489, 1, "2080b6794a8346cb9d4d933701e336441bde57b5ae1585967fe2208000406ed9") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ko_KR
setManifestid(1242489, "8912353938926839775", 114463)
addappid(1242490, 1, "ece50ee0ecbbf0aa652fe65467abd4a62c8b569d2c2b8248c5af221219e21f20") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - nl_NL
setManifestid(1242490, "5529376813464416079", 100701)
addappid(1242491, 1, "a1cb00bd18745c274be1eb3ba9609a99f745d2aeb2555163fd0a879c2e26ad1c") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - no_NO
setManifestid(1242491, "1516442967079899823", 97463)
addappid(1242492, 1, "3ee9f309b95c2c3427460c93e319aaa69b78b0b52d3a4ac400ce229803acdfa7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - pl_PL
setManifestid(1242492, "1963439231607963642", 113853)
addappid(1242493, 1, "70bcb9893e7889943329fc57e4e5edb178f98bc04133231e931e81ed05d305cc") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - pt_BR
setManifestid(1242493, "8418107858534656841", 101812)
addappid(1242494, 1, "2f4ed3ed8659a49fd5942a44adef2004c1b7cdcad9f28a1429627a7bdb46f0e9") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ru_RU
setManifestid(1242494, "5062030470795029152", 128858)
addappid(1242495, 1, "125097402c1413608a32f4d4b6cc493e4ae2113de325e85ee8ee6578d184d4aa") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - sv_SE
setManifestid(1242495, "8566029116214350554", 99327)
addappid(1242496, 1, "0859bfdeadd8c2b68502e1460be81e373f028b61d395cc1a50e326421dbe6e3e") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - zh_TW
setManifestid(1242496, "5553426232894606301", 101353)
addappid(1242497, 1, "923533be8d3da5bcdd85371b4d444cdd7ac69b8698b976d834bc72dbbc8ed3d7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - zh_CN
setManifestid(1242497, "7149985420126426966", 100863)
-- The Sims 4 Get To Work (AppID: 1235734)
addappid(1235734)
addappid(1235734, 1, "8dcebcd1ba1122e8ff0237500bb6707d7f86738ac4484321f7b09fec2ae4be57") -- The Sims 4 Get To Work - The Sims 4 Get To Work Content
setManifestid(1235734, "2713381862872370433", 1730149016)
addappid(1241890, 1, "c806939b2c0069b74813ee73c89f203207ff783f7074118b267fef8de493d72d") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - en_US
setManifestid(1241890, "3556391921354062734", 149990)
addappid(1241891, 1, "bfc4d3683d81a83f15b8b0ebaf8ad8181507e16023053a952294cf9706a97385") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - cs_CZ
setManifestid(1241891, "6893929121006992581", 166928)
addappid(1241892, 1, "e671aa4f3a7e351e1d14c9760c6b737eda6166b05df19f12e4f5772e46e5a47d") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - da_DK
setManifestid(1241892, "6817978428930705049", 147177)
addappid(1241893, 1, "18e39893a8289c96cf1b0994d9e3645419c1bb99d9dfde4aed6d77aa4aac5d0e") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - de_DE
setManifestid(1241893, "141383159973641638", 157599)
addappid(1241894, 1, "c82ca76a5e7932baf01caf209a62ea5613125353aae200b46f0646c8e5a15c74") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - es_ES
setManifestid(1241894, "5787613720219317255", 160457)
addappid(1241895, 1, "dbc9d0dc563f898c77655e48d19f33f57552752a7accfa7b20a33d28d06a93d6") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - fi_FI
setManifestid(1241895, "6668530418414779905", 148403)
addappid(1241896, 1, "4ce8e73ddd2dc1dd809dbb4c9437d7445ae2a31e6aca9beb0589881f1c81719c") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - fr_FR
setManifestid(1241896, "3700971388344941127", 164743)
addappid(1241897, 1, "ebb3f1c9c197b10e71312726cf2b7675893245c51d1424f806a49785c95e4e04") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - it_IT
setManifestid(1241897, "5655545902031995328", 157295)
addappid(1241898, 1, "aa1ee8c4b4c9a1646b9591e052d0efa1213b0a0ec1833c5281ca9d359c3f2a6a") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ja_JP
setManifestid(1241898, "1528007062364345789", 154708)
addappid(1241899, 1, "939f76eaa28302ec078c5eb4dd61d4040495bcd3ac3b3f8bcfc711167fd5050a") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ko_KR
setManifestid(1241899, "8308888116041748447", 155698)
addappid(1241900, 1, "539b1cc8408a7bd25e596d03f201ff6b51aaff85871bbe5454c3574e082c5422") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - nl_NL
setManifestid(1241900, "6941706494792825720", 158387)
addappid(1241901, 1, "c9e58204f73924284a6c5d15af4deefc4cdc32c22455367a0e3bd65056a239d3") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - no_NO
setManifestid(1241901, "8526751743386167577", 146685)
addappid(1241902, 1, "337e656c75f8bd43052510b9f5d5d18d88e87dad18b0949552e1168346613dc3") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - pl_PL
setManifestid(1241902, "9212806045817085823", 167812)
addappid(1241903, 1, "87bd42449aa8726f6b316f64d92e66996012fff78c3c06dd3358458f69a7315e") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - pt_BR
setManifestid(1241903, "4189617943535504703", 154570)
addappid(1241904, 1, "c180a0df0de6b9914bca37c7d66c17bcfb53ef31a7619f4b446788892916ac5b") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ru_RU
setManifestid(1241904, "7717345161073947601", 179381)
addappid(1241905, 1, "a6e6bc835088d989f990ca283099823919050bed19843056933366ffc846c36f") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - sv_SE
setManifestid(1241905, "1326694080148752850", 148905)
addappid(1241906, 1, "8cc02aad2ffc7dbcfe0f589d1ed68b35e7b3bb05efb99449254a85424558df49") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - zh_TW
setManifestid(1241906, "2268263808246885425", 152175)
addappid(1241907, 1, "4878197bf6a8e3efcdec2c963a50b2b92e67277e59f4ebcea91c2b76f5ecc3a8") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - zh_CN
setManifestid(1241907, "4499811720844801716", 149990)
-- The Sims 4 Spa Day (AppID: 1235740)
addappid(1235740)
addappid(1235740, 1, "046a6953baedd6038887f74573a2bb3bef55ed18df04f0e08f1cd11d1c06be34") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - Content
setManifestid(1235740, "2386240026451470713", 538995930)
addappid(1235748, 1, "2ef232496679e44bee1e4dd6ff4f0b7c0caf9ff4726ac5a983f85793f45eab92") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - en_US
setManifestid(1235748, "665315396103284252", 33463)
addappid(1235749, 1, "8a0550195480f372ecf5b53e1eae2b0fc00949f0ae0196994c36a4ab68720974") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - cs_CZ
setManifestid(1235749, "6095237893902853214", 37273)
addappid(1242461, 1, "23f7097ca66afc99aa1a3542946e6cfde9c7a859df6c4aa2a530cd33e90d47ef") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - de_DE
setManifestid(1242461, "7924529069853315046", 35558)
addappid(1242462, 1, "554e337d38cc7f07a9340adab0d6b93b0bdfa95bc3a1a5049d042f6071c04d7e") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - es_ES
setManifestid(1242462, "2873025231585727983", 35446)
addappid(1242464, 1, "6bf24132e86958bd2fe332b2ab3b08e0abcd63b245540415d33587675890f7b5") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - fr_FR
setManifestid(1242464, "2676377604810843768", 35336)
addappid(1242467, 1, "c0d34a0c772250c5dacc86ba33924d16a56d4fb7d6c3f6662cfb230cb7aeb41f") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ko_KR
setManifestid(1242467, "7368007721662065590", 35001)
addappid(1242468, 1, "46682f7482d8b9cdfe9aa650cd2f3fbd88e140522ba6ea3730cf127eddcf119c") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - nl_NL
setManifestid(1242468, "4681057910857543084", 33874)
addappid(1242470, 1, "5df1f74426df363694fb1009cb210db4d5a3bba3b4b950a89a0d0e4bb60023f3") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - pl_PL
setManifestid(1242470, "8132156154285048084", 37970)
addappid(1242471, 1, "7f3293c5f911ed171913e740b1c6c1a56b6e225a1697e2589d93557e52478bdb") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - pt_BR
setManifestid(1242471, "2488232212800474978", 34755)
addappid(1242472, 1, "d8139387657cc705947d83a1b3ab4ec2b1f0a9e86b6774b2bda0f2253100cec5") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ru_RU
setManifestid(1242472, "8344368605670679166", 39899)
addappid(1242474, 1, "82b20cff19442cacb8fe8edb07b4621da37eb3db094994a0607c380ca10a751d") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - zh_TW
setManifestid(1242474, "4919007009339646528", 34145)
addappid(1242475, 1, "5e37a17996eb1197d77d260ed148479ccfe30eb64482f57024ab86ef10ec10b6") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - zh_CN
setManifestid(1242475, "8362402602456690701", 33463)
-- addappid(1242460, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - da_DK (no key available)
-- addappid(1242463, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - fi_FI (no key available)
-- addappid(1242465, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - it_IT (no key available)
-- addappid(1242466, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ja_JP (no key available)
-- addappid(1242469, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - no_NO (no key available)
-- addappid(1242473, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - sv_SE (no key available)
-- The Sims 4 Outdoor Retreat (AppID: 1235741)
addappid(1235741)
addappid(1235741, 1, "d52ba28c7f9084f59080a16bc9f45d94fd1f949d876e8ab79f0a87157e548c2f") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - Content
setManifestid(1235741, "4595708316742675289", 706035404)
addappid(1242440, 1, "ffa8d2569708613c0a3a8754c9a1132d101f643660fee7f8b0587b56a567b6a3") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - en_US
setManifestid(1242440, "2019901858242018361", 39001)
addappid(1242441, 1, "fb20390884604d510f55d474c7175438f569c5d86600cae071552a68b6004c20") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - cs_CZ
setManifestid(1242441, "2462642952556563469", 43272)
addappid(1242442, 1, "a8b5b0a1a596eac1089dd8e9eb87a85b3a9511ee3051ffe3e03ac9fd92e42198") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - da_DK
setManifestid(1242442, "1158040603349471689", 37915)
addappid(1242443, 1, "496ee2e61acbae96ae5b8dd40605d71fe039284afdd2b6746308799d86d8b0ae") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - de_DE
setManifestid(1242443, "5935230670288050381", 40140)
addappid(1242444, 1, "380646b49b04df47fe67ed4f2c3ef7a2b865c351bae53a0a2d93f1f1d1367710") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - es_ES
setManifestid(1242444, "9212092113089271996", 41342)
addappid(1242445, 1, "30c407c0d1a771887b2a32da3c8ba69fdd2ec821a9eb28e989584a28390ca2c0") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - fi_FI
setManifestid(1242445, "1169595959212093528", 38390)
addappid(1242446, 1, "fba0d5d8daf28ed5770b23016bdda87932e00c0f7a53616faefdd66397e1b261") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - fr_FR
setManifestid(1242446, "6673122456653400031", 41722)
addappid(1242447, 1, "7af2973fdb84802348895a6f6f4d6dfa2ba3a49677689f4fe1ac605f27bd8df2") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - it_IT
setManifestid(1242447, "384811625999663867", 40201)
addappid(1242448, 1, "447d47855080ab2f6d1131f1cb0e8fed8f45c58a870fb7de7bfb3672d260e194") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ja_JP
setManifestid(1242448, "7912141113339462873", 40712)
addappid(1242449, 1, "cd2cb0c9894631f06fccff2439792f2fbe54e897d1280046ee9947eca2275f03") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ko_KR
setManifestid(1242449, "969155901761117398", 40167)
addappid(1242450, 1, "36e884d0e010c4586d5d8c4ad3da3dab752898ee3bdd33fe7f79042b36e74dd2") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - nl_NL
setManifestid(1242450, "6692116794656959415", 39841)
addappid(1242451, 1, "6d6a444b61437edfebcce5cda8207d1c29685396147f16fe3e1a417de1e2c1e7") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - no_NO
setManifestid(1242451, "5750256798499271711", 37879)
addappid(1242452, 1, "07d3c83b1848415860cf286e3d03ba5a1597c2a13b4eab44819ffb8ff25bbb14") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - pl_PL
setManifestid(1242452, "7551948771570558078", 42709)
addappid(1242453, 1, "1b9978cbf9bc88c4942391488d95b926cd76706b2033184c2712522bfa5f596b") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - pt_BR
setManifestid(1242453, "5595277987352426648", 39708)
addappid(1242454, 1, "0d9641c085c0ad448849a166647e8258776419db90271cab4c3b02656fcdd058") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ru_RU
setManifestid(1242454, "3787766392975893046", 45839)
addappid(1242455, 1, "63b71162d20e9f5fcdd6c65840cb6ad507e683bbb44954df491ee4967f255209") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - sv_SE
setManifestid(1242455, "40418072844316343", 38382)
addappid(1242456, 1, "f52d4424606dc11589946cc8042950764f5e4e7e0496f3af0e126dec3f97552e") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - zh_TW
setManifestid(1242456, "6644816496919540313", 39797)
addappid(1242457, 1, "e7ae8732614bbf08b35a543277c51f09ddcdc689c484950e61f30e7a42d5edc3") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - zh_CN
setManifestid(1242457, "4834311483121793661", 39001)
-- The Sims 4 StrangerVille (AppID: 1235742)
addappid(1235742)
addappid(1235742, 1, "3799b6a868ec9c3485d62a52f4820ab27eeeb86f1e99e3472863be2bfea2d92b") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - Content
setManifestid(1235742, "898172278340561720", 713623176)
addappid(1242420, 1, "67be7f118d8265ad41c7f7d8ac3f7c397b51677c9d301dc409f591a4842bef9f") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - en_US
setManifestid(1242420, "171559866185397094", 55223)
addappid(1242421, 1, "11d63621f7109047cbd0ba663fa4b7231a006b7e283a544140818d6704d48f65") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - cs_CZ
setManifestid(1242421, "4971979618000445955", 61657)
addappid(1242423, 1, "baef1066093469854f2730722bbd92a8a254f32586443bda3a9376431cca728a") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - de_DE
setManifestid(1242423, "1948243341918213082", 58004)
addappid(1242424, 1, "3a4449983e0bfa7853c6f682de0a912b50ae88af0f14a28bf47aeb5cea090057") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - es_ES
setManifestid(1242424, "7973307785361774747", 58294)
addappid(1242426, 1, "7bd48d70d7f0db9e5971a4cc5424307f411303cab3f2a151099d4e8fa1440b33") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - fr_FR
setManifestid(1242426, "7440303724459998126", 57768)
addappid(1242427, 1, "fdb7d14be227fded751f87e1c4df5fda28fb40286ce38a6bb06506534d075bac") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - it_IT
setManifestid(1242427, "1992194407201967707", 57790)
addappid(1242429, 1, "16337689578cadc7aca3388bffb373548c421f07ee4c46d4a756702662b79dba") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - ko_KR
setManifestid(1242429, "612369895819315553", 58301)
addappid(1242432, 1, "d7defa495615219bf083dbed31a191081bde580a40711b2ca65018e2d6576357") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - pl_PL
setManifestid(1242432, "6283434820175999710", 59584)
addappid(1242433, 1, "81d7490112ffafa28032372d79e9eed966c3eefb7f291eba2e223abc173bc62d") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - pt_BR
setManifestid(1242433, "1622385488530271611", 54772)
addappid(1242434, 1, "7ae23143a5a0c1bdf69688bc5e2b5c57c7e0591483dee896814e2eea847c570a") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - ru_RU
setManifestid(1242434, "1692678299470085251", 63313)
addappid(1242436, 1, "8cb6a7045f0171bcd1fa83c4b11d1f4d0d3ce486a462147aca7f53344dc1b888") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - zh_TW
setManifestid(1242436, "7235851219921576696", 54827)
addappid(1242437, 1, "ffe1b210ac7d6c10cce8828530ca8fa51c59940bee5e75e039dec4d43239535a") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - zh_CN
setManifestid(1242437, "1050637888323985724", 55223)
-- addappid(1242422, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - da_DK (no key available)
-- addappid(1242425, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - fi_FI (no key available)
-- addappid(1242428, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - ja_JP (no key available)
-- addappid(1242430, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - nl_NL (no key available)
-- addappid(1242431, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - no_NO (no key available)
-- addappid(1242435, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - sv_SE (no key available)
-- The Sims 4 Vampires (AppID: 1235743)
addappid(1235743)
addappid(1235743, 1, "bccad078d050f5b15d0cf21e579fb25316b34ae9ca0bd100d85bfefb1b6a582b") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - Content
setManifestid(1235743, "1387734458362901962", 722137192)
addappid(1242400, 1, "39adb755791854f4ba4985ceed56dac020bd593b2c5bd94570a0743bcc860c2e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - en_US
setManifestid(1242400, "111991454906429292", 51189)
addappid(1242401, 1, "7b9013be2b01896bf2781e80d4bb851390cece38d68789c437857a183248a11c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - cs_CZ
setManifestid(1242401, "6434804614232025969", 55614)
addappid(1242402, 1, "ba3384cc66c7bacd98a857f8e32eb3ee998d5b6ba30b98606a6a68605b77dc9c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - da_DK
setManifestid(1242402, "1304490350189955573", 49847)
addappid(1242403, 1, "f5c16424975d1ae5f6fe5a3fb9a1450bc3a52e11cff60477a1506a077aae6851") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - de_DE
setManifestid(1242403, "4066894017494123755", 54545)
addappid(1242404, 1, "82b04a05575316905c663c2ba341dd1c76627a3a9f9c64e7ffbfefb9c00b0c61") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - es_ES
setManifestid(1242404, "843393359772472950", 54927)
addappid(1242405, 1, "35e65ec257068a815681f88d07c1b7ac020b4d0ab9be4ee1196fc8daaa55977d") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - fi_FI
setManifestid(1242405, "5275542695551291007", 50161)
addappid(1242406, 1, "57e50ad790679709691994aeb1e6728d92ab5bfe22f9d8ae647fed2205922671") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - fr_FR
setManifestid(1242406, "5032173703019219927", 54021)
addappid(1242407, 1, "a03c6fb84c546c840d6c1f64560f6393e9b11a153c6fca60024ffdd9b362eb7e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - it_IT
setManifestid(1242407, "201866649727026545", 54004)
addappid(1242408, 1, "4a3dbed094c8ba5a81e9baa3155b840b9514f7879160f7fbccdcc7b989a1639a") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ja_JP
setManifestid(1242408, "8145545041305634164", 54864)
addappid(1242409, 1, "7e22b15a1d71d5795a7e4eff3294f9e43a9a39409ab40b80232c54da0b8d023b") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ko_KR
setManifestid(1242409, "9013460275262597003", 52209)
addappid(1242410, 1, "a4c0f3b12af21c700c4f826dceba7a4f10722fd9f228eee17a149a35e11d1ebe") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - nl_NL
setManifestid(1242410, "3365427591147910378", 53103)
addappid(1242411, 1, "7f40bb9f59dd99678d0aff0a61bd10bac4001dd1fb2623f7d66d4b29dd1980de") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - no_NO
setManifestid(1242411, "7101490460733307127", 49627)
addappid(1242412, 1, "d7482a6408de37affb28947d26a0dc2e7da8adc83c59d75fb555ae93ea54c9f5") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - pl_PL
setManifestid(1242412, "6876458194083731270", 57718)
addappid(1242413, 1, "5a21af566723b17790438891c998190c309152007fb3b132bbb1d97192a15eb6") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - pt_BR
setManifestid(1242413, "147156311829609094", 51918)
addappid(1242414, 1, "50995abc32a63611e39113f4a1d222f0a30efc12acee7ae365c0a4cc53b6f201") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ru_RU
setManifestid(1242414, "970183852469419396", 59274)
addappid(1242415, 1, "af176e23c65b750a17f49e9d6721525fd5db813701759331749d9b2b2b417b9d") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - sv_SE
setManifestid(1242415, "2141264550416294109", 50181)
addappid(1242416, 1, "731133d479cd78beebc3c226ca6c0d9df1fc8dabf173288faa9beb8f4413d58c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - zh_TW
setManifestid(1242416, "7528480769070279213", 52112)
addappid(1242417, 1, "998137ba93052015344782f47562f4f0f7b48489d7ad9f355a7d57f06f01335e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - zh_CN
setManifestid(1242417, "9147100279073626506", 51189)
-- The Sims 4 Jungle Adventure (AppID: 1235744)
addappid(1235744)
addappid(1235744, 1, "072c8049081ef4a4677d0ebedfc10a2dd9543f920e8e2dce09015f439b7d0e5f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - Content
setManifestid(1235744, "6875072033028861379", 959443720)
addappid(1242380, 1, "fc75a14a98da4dd176e1fbeed23e83491919bc505324b719b8ab1b4b2160e3b2") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - en_US
setManifestid(1242380, "2947383672760029261", 78826)
addappid(1242381, 1, "a0eb5f3fa73a387ded2ff51a1afa8fdcdac322b4819a5bb351d5fee8f189331d") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - cs_CZ
setManifestid(1242381, "4008319047866050224", 87043)
addappid(1242383, 1, "307a234ec5d3e1a906aefa05e6806c841c4cc16606ca324b110692962c44abf2") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - de_DE
setManifestid(1242383, "6427481609046858390", 83900)
addappid(1242384, 1, "8f3bb50a4d6d95c44529e22d8cc8b99a256fc1f79d4c1ee85ae29a07a3864d7f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - es_ES
setManifestid(1242384, "8196376354110965754", 83463)
addappid(1242386, 1, "977beac8a666b5ab1f2dbf1f4abdd2d7154b6e4b5edcc8928a6181825bda6584") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - fr_FR
setManifestid(1242386, "4744247494544138427", 83579)
addappid(1242387, 1, "4fdd614af5559658afd1906c78ccd7db787d156c35686f1cef34e4ccd9293031") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - it_IT
setManifestid(1242387, "4092452873350839483", 83948)
addappid(1242390, 1, "fe16b41de217b82eb0e90edbce80091f41d87d68fb0a9ac7e364689219453c5e") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - nl_NL
setManifestid(1242390, "2174081716526710386", 80625)
addappid(1242392, 1, "87dbfaba78f71d8b15ea467eb1fe4c82b432f479caaa43afcd10cbba2b3eb1bc") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - pl_PL
setManifestid(1242392, "8910467853074589623", 88884)
addappid(1242393, 1, "12961371b100a000b2a5620dc45f0e4123be17acd80f354df1a234832caa1cdc") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - pt_BR
setManifestid(1242393, "7934072257005176512", 79214)
addappid(1242394, 1, "2b4ac38980c5b60727b62c34210162633b67030051617c9968d2def85bf1136f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ru_RU
setManifestid(1242394, "379910398238456026", 100440)
addappid(1242396, 1, "709fdafc7790b68547a7de5815eed9f98c9ee78fc081c0630fcf0c4eee2d4c8b") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - zh_TW
setManifestid(1242396, "3450590756264154631", 80899)
addappid(1242397, 1, "d50719dc4294e9a0947f2641e344970c3c2a858946c62b6a6971189e9b05dbdd") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - zh_CN
setManifestid(1242397, "6443242862516145794", 78826)
-- addappid(1242382, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - da_DK (no key available)
-- addappid(1242385, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - fi_FI (no key available)
-- addappid(1242388, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ja_JP (no key available)
-- addappid(1242389, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ko_KR (no key available)
-- addappid(1242391, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - no_NO (no key available)
-- addappid(1242395, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - sv_SE (no key available)
-- The Sims 4 Parenthood (AppID: 1235745)
addappid(1235745)
addappid(1235745, 1, "b1e6d2e9faab7a55e326962f56d84c1602536645064ed5d7e1afb4600c150c2e") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - Content
setManifestid(1235745, "6946578202027560398", 475505746)
addappid(1242360, 1, "0e81c1891faa56030af5e8da531ee6318e6a843e2bd15e06ee182df75a4cb125") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - en_US
setManifestid(1242360, "3958365363340106518", 68005)
addappid(1242361, 1, "6000878a4fd90b184b92ad4b931b40b97d58f313a329ba5dc727c62750e1e375") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - cs_CZ
setManifestid(1242361, "5546393268612584578", 76493)
addappid(1242362, 1, "dad7f54c4d9dc12632c7a1e6ad041f1a362bf5b707cc1cb3c8890b8bd6bcb8b9") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - da_DK
setManifestid(1242362, "9059826949998769029", 65820)
addappid(1242363, 1, "cac85be23bb1feab89447cc40a5daad7ecaf19eb0df9f61d5c66cb2a85f1d6cd") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - de_DE
setManifestid(1242363, "6780914613713903256", 74106)
addappid(1242364, 1, "6357c0191fb589f767715b73726ddbca75b09499ca0fd8dd79875018f437be4f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - es_ES
setManifestid(1242364, "6410301695928478805", 73544)
addappid(1242365, 1, "421df882511fad9bd60c2eb7b6615e39299497de9b659c2af7d33ec3aec6f908") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - fi_FI
setManifestid(1242365, "7454767384041184720", 69746)
addappid(1242366, 1, "9febe0625c2c0f615aad39c09a47365e9c2a8890f58f2fdd5cfaba885ac1588e") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - fr_FR
setManifestid(1242366, "4601687221564513801", 73014)
addappid(1242367, 1, "9f6dc5699ed09f8401a35a741305e3f5b6b79d1fa0890f472d771c49b9ffbfaf") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - it_IT
setManifestid(1242367, "6673625822144225490", 73195)
addappid(1242368, 1, "f9b8b7d10b2b323c6ed672ad75d82652cf7f0246a703d2b0e4a315dc9ca47a69") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ja_JP
setManifestid(1242368, "8420978423919238950", 73703)
addappid(1242369, 1, "0d2e5b8e485d3e24fbf234004027cc24f456025e5b141bea7abd70014a13d079") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ko_KR
setManifestid(1242369, "7411484375839379972", 74071)
addappid(1242370, 1, "d26eabaf8a040ca96608ae8e3f4f1b5280214d166e2a4152afaa91980bac658f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - nl_NL
setManifestid(1242370, "3451765925247527553", 70075)
addappid(1242371, 1, "2e81b849f44eb227af77fa92cfd525f1380671f159793441ae4cc07d16075f36") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - no_NO
setManifestid(1242371, "3942542378379877409", 67126)
addappid(1242372, 1, "dec20d90e612dcdcd5f73216eda47e1312b168d12ed6b6178fe93305d263057f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - pl_PL
setManifestid(1242372, "9097629904321249013", 80492)
addappid(1242373, 1, "3f5cf66fd10a8b18af8e3ef50c215846933e4ba9bd77cb5b479a6a5c6d2553a3") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - pt_BR
setManifestid(1242373, "2094060257375822380", 70424)
addappid(1242374, 1, "c77fafcd1cb71da645a043f74db9ffbd4567b2a4f03adddb6622c9345502481b") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ru_RU
setManifestid(1242374, "3463599991551445979", 85448)
addappid(1242375, 1, "3ed1107995cf431a0e0af472044d54c32e2f8165c9330c7ad2b2585445c9945a") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - sv_SE
setManifestid(1242375, "3912332427596454552", 68152)
addappid(1242376, 1, "d9157fa3ae556e7c5a91859dad4b11d451b34c3d2a367bc0850d8865de8d2de8") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - zh_TW
setManifestid(1242376, "6271482784408278346", 69119)
addappid(1242377, 1, "dd7a0e826091c9a387b3cd19bcc9e86e744b87488e86cb9d1d116208e8e620df") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - zh_CN
setManifestid(1242377, "8631708220960636964", 68005)
-- The Sims 4 Realm of Magic (AppID: 1235746)
addappid(1235746)
addappid(1235746, 1, "40120eb998073f62f37746f631c0f9584736dff5a600169e7ebd48f1b63dfc4c") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - Content
setManifestid(1235746, "5266788072654066327", 934417601)
addappid(1242340, 1, "353009c37e681baa68377f046ddfe1ec50197b26d5853cfafaa0f03023969c98") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - en_US
setManifestid(1242340, "2722260540718690714", 51647)
addappid(1242341, 1, "edab6fa9c86f5e905e8bf6238fa3dff22cd48e19bcd4b62c388aa757b76a763b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - cs_CZ
setManifestid(1242341, "4413845333016049669", 57935)
addappid(1242342, 1, "0ff38ae9e936f0993fce8fd993aab67f5d547211cbe81e11cc836f4ae2943c40") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - da_DK
setManifestid(1242342, "2585738418148106644", 50588)
addappid(1242343, 1, "7e6fb691f8441e26e592cc50a73d2326528b6c09f1081422fcd2b16fb334e34a") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - de_DE
setManifestid(1242343, "8414281892828256426", 54731)
addappid(1242344, 1, "afc32d4e3e06e23fbfa9013ba1608d34184973fffb2dc2b256a76d0068be04ac") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - es_ES
setManifestid(1242344, "211500830150129412", 55703)
addappid(1242345, 1, "8eddec28149c328d7ebdc508312cb16894f30addda23ad0bb3080eb5136c77ba") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - fi_FI
setManifestid(1242345, "6328482497903188745", 51359)
addappid(1242346, 1, "6691a98cb13ca15a4e5fa3da61dcb5c43b1c249b6e62e398ab657d2ed6a1c90b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - fr_FR
setManifestid(1242346, "2940631648854128223", 55169)
addappid(1242347, 1, "8d333e90d55732e2ef19c57f80aabd23d2e4ef26cfaf5e65d420a6528c9d6ecb") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - it_IT
setManifestid(1242347, "5586804003763010118", 54438)
addappid(1242348, 1, "620868a47d39bb4cdfb4702879c5a939eccd185322079ff1b19d027a6f1cc22c") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ja_JP
setManifestid(1242348, "5535153375638473415", 55159)
addappid(1242349, 1, "7bf857ec793a02801a7e79b284912688fc5c405236ba98c294dbdc54940e1509") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ko_KR
setManifestid(1242349, "8443181007743482853", 53933)
addappid(1242350, 1, "cd1f8524001e46ce69f435bfa29c64c3b888267fec010c7f0c147fb60d072c76") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - nl_NL
setManifestid(1242350, "5932198594582393619", 52024)
addappid(1242351, 1, "71ea8662b956514e4a50cd7a7068cee6106da98f28c54cdb3d8020304b70594b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - no_NO
setManifestid(1242351, "2136840065121237340", 51472)
addappid(1242352, 1, "3fd4525d615e8d1aa234e1cc89700405b5a43df7eb40e5cd6796625cd9e35abe") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - pl_PL
setManifestid(1242352, "9022239040771419413", 57212)
addappid(1242353, 1, "a03dbcf04a340d2b1bf8e87a38e4689db91cec971e9802d819308d2d46f2802a") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - pt_BR
setManifestid(1242353, "6889367971418424256", 51980)
addappid(1242354, 1, "d589e52d6154d71ac6901893c56ea47d73c23ee2b0102e11bd11a4c39a4b6471") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ru_RU
setManifestid(1242354, "1406946568358308298", 59048)
addappid(1242355, 1, "5baebf8719a522ec6421a607dd3a10f0e1547caad34432fcb6239af5becd1071") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - sv_SE
setManifestid(1242355, "1285127635010465272", 51841)
addappid(1242356, 1, "8cc9db96924c2d5484989a391aeaa89820d81f80e518ea539b928f1653ccf360") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - zh_TW
setManifestid(1242356, "4392922838672954904", 52590)
addappid(1242357, 1, "e94140716d2153251b16e08377cf0ff141887f476dae5721de2cd634a67c7e5e") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - zh_CN
setManifestid(1242357, "8243710200404755296", 51647)
-- The Sims 4 Dine Out (AppID: 1235747)
addappid(1235747)
addappid(1235747, 1, "9fdefc05ac6cb4b5cf8dadaea3c861fae7d4a4ff3357b788a8e76d21d2344704") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - Content
setManifestid(1235747, "3226127706205642142", 476854339)
addappid(1242320, 1, "afb39cd95f1ec4b18808d70e280487926fa4be91f5f36256067c45c903e1110b") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - en_US
setManifestid(1242320, "5265127381582515343", 38895)
addappid(1242321, 1, "1c63d5afc9c62806d3b04c51b61ab482db186f704c878eca701cd3aec93e52ca") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - cs_CZ
setManifestid(1242321, "1285757983940889954", 43011)
addappid(1242322, 1, "7681c449652e8234a3be2adadf804c1e9875494f522a711b21ed95efdb4271e6") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - da_DK
setManifestid(1242322, "6878557540308589225", 38849)
addappid(1242323, 1, "373cfcc09f9817dc004820a3bbf6d338b1445e682334b618c8ef6d4b0bd5b861") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - de_DE
setManifestid(1242323, "935979855389455453", 39886)
addappid(1242324, 1, "b4fec8ef1c79e4141bd81ef22cee3e14817fe950f63b65c22d8ae58b9a9887b3") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - es_ES
setManifestid(1242324, "5441519860869347082", 42262)
addappid(1242325, 1, "cbd6e491cd82142f60a2d6aad597d0bd02cd9a2b7e77bab8e61e26475d8a11c0") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - fi_FI
setManifestid(1242325, "8772754420874986567", 39072)
addappid(1242326, 1, "3e1463ac74ccf9093d801e5a36bdb6a6dd0384a0834bdf14ac144a6f8482e149") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - fr_FR
setManifestid(1242326, "3705087469146514834", 42246)
addappid(1242327, 1, "1b7d8e81078c47d20febbc5346eb5e2a8b9933b115fb490a68031704ad7efcc9") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - it_IT
setManifestid(1242327, "6945500452574285348", 41387)
addappid(1242328, 1, "ad3f30375908e90e00a2388da13ff378202d9d6532a16e50c0914122793e8b1c") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ja_JP
setManifestid(1242328, "2882069785614170626", 41923)
addappid(1242329, 1, "13eceaaa34022c2ccb1b1371fe583a691a6becc9efc2a038fbf56baf6619b1ca") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ko_KR
setManifestid(1242329, "2940194943768292326", 39997)
addappid(1242330, 1, "7ae8a7f2298e12d67f1092565b675486102320048ff13fdb69bb2f430d91657a") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - nl_NL
setManifestid(1242330, "7720386794927869491", 40395)
addappid(1242331, 1, "2f09edd0aab5a5ebb1adde728b1671a4f93e1be28438bea3344e6320c4f74d1f") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - no_NO
setManifestid(1242331, "1666324328757298749", 38671)
addappid(1242332, 1, "0751f87508d20e2be8df0cf32f6b4765f23c7b32a58a6f5f1428ea286ca64774") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - pl_PL
setManifestid(1242332, "6148696609165180253", 43252)
addappid(1242333, 1, "646806902785aa56c7c2c9ba2839359969007a26bf348220a6e1f20a7c177eae") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - pt_BR
setManifestid(1242333, "5463878178984445907", 39886)
addappid(1242334, 1, "16f95eb7c7cc6bb4b8cbc2c4520413f314ac032b070e2d457befe3f6c86b54ec") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ru_RU
setManifestid(1242334, "869015862110863765", 46824)
addappid(1242335, 1, "6c496eac1a43a21db3c4d999a76070c63ec63e8db63ef6f4b165d0cdd819f447") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - sv_SE
setManifestid(1242335, "2124468023358408289", 39139)
addappid(1242336, 1, "82b9feba221d67f2556fe639ae77050d76eab57b5cdf6ee9c9f58f910309ddd1") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - zh_TW
setManifestid(1242336, "7308102945027764907", 40169)
addappid(1242337, 1, "4df32494235dfbf52519e859f02d36da28a085cf2a89884affc1e0da0ba93cc4") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - zh_CN
setManifestid(1242337, "1000048484310665438", 38895)
-- The Sims 4 Fitness Stuff (AppID: 1235750)
addappid(1235750)
addappid(1235750, 1, "f3b2fced0e2a886adfaf6153b53298703a4fe98e10d574b5b5861d4e6418aa9b") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - Content
setManifestid(1235750, "2931852777984375708", 165364428)
addappid(1242300, 1, "569ba30aeef20e2828a3e4eb9ea553c2edd2ee32ad4ad93733b0ba894f1499b8") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - en_US
setManifestid(1242300, "1707689733214515932", 9671)
addappid(1242301, 1, "f7d66aa69a4099d3689519b59344e9dbf676aaaa468a4491e1a739b5d098c77e") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - cs_CZ
setManifestid(1242301, "1005455936973860400", 10697)
addappid(1242302, 1, "62b23aded42cf6d2318e7719f213676a5f01e3175f1a570850bfb91ca673fa85") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - da_DK
setManifestid(1242302, "3037965185026778654", 9400)
addappid(1242303, 1, "64042f7ae5e3616c8a4f6a4f8ffa50c5f9c565defacddb865ee509d1d97ab23f") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - de_DE
setManifestid(1242303, "3118466215153993423", 10162)
addappid(1242304, 1, "2d7d5e8ff5d09f30233718d6056f6f5e9cf2e09fdcac011da7e535768d58412c") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - es_ES
setManifestid(1242304, "5336335361900749567", 10489)
addappid(1242305, 1, "c455aee02536d7ad500d74c1efaf66cc94c9bca80a703a50b5ec9860760ba724") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - fi_FI
setManifestid(1242305, "8611506912759429310", 9323)
addappid(1242306, 1, "2331ab71c43fde2f34459a855741dd1a1600b9c339475b38700d8eb9010b56b7") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - fr_FR
setManifestid(1242306, "5118192726656197994", 10557)
addappid(1242307, 1, "0a2d2b90cdf2d0ce4194691cb24da3d78b4060d89c9eafe5ef9734eaf42b5068") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - it_IT
setManifestid(1242307, "6075247692927296912", 10319)
addappid(1242308, 1, "21eafcebd37c6d53488776d747801f190057c4b81d22716bda523f3b7bdc86b4") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ja_JP
setManifestid(1242308, "8225266555077690760", 10542)
addappid(1242309, 1, "d622c85e461dceb633c05d2d67f24b8ed4e61af6c464dc82fbedcf8eb8d51d09") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ko_KR
setManifestid(1242309, "3852925013432178211", 9961)
addappid(1242310, 1, "435e17741ddcc7a419a59756ac252df2e847dcda9c0bf2c4718ca434a04d3eec") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - nl_NL
setManifestid(1242310, "235425531021732674", 10074)
addappid(1242311, 1, "c68aafaf637b90c1cab4ba9b0d7c59b0cd2d2e96da8fcc6b0142c557cc9a33ca") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - no_NO
setManifestid(1242311, "6132191207990456824", 9137)
addappid(1242312, 1, "56e3c8dd355cbcf27882ffee39ae6dbdccf2ce834b5bccbdd75e9dbfb2d74652") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - pl_PL
setManifestid(1242312, "3025141560016221640", 10771)
addappid(1242313, 1, "72b1ba12e0b354c41d114b3a973b69eaee88b15193a7bad811965ed01e367e56") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - pt_BR
setManifestid(1242313, "5189285081112955981", 9769)
addappid(1242314, 1, "329dbd222036e7a62bc974b74602dc3a0e8d6a0062d02aaee81042bd850ac8de") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ru_RU
setManifestid(1242314, "2093581839556416603", 11629)
addappid(1242315, 1, "a8a538004957d8765bcf2a66f7bdb4da225c5d27a1141127ba8fa2d33c926bfc") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - sv_SE
setManifestid(1242315, "8758311109255427464", 9472)
addappid(1242316, 1, "4dacf075e4a1c2662dd3bd7bda3f350174ff1db89265c9d84bdbf654965a6c0c") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - zh_TW
setManifestid(1242316, "3803510861859002667", 9686)
addappid(1242317, 1, "62a494e1de476fb6fa122472812be1a3f6fe5d2b8150f80129cb843cac243ff6") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - zh_CN
setManifestid(1242317, "6245218693992860386", 9671)
-- The Sims 4 Vintage Glamour Stuff (AppID: 1235751)
addappid(1235751)
addappid(1235751, 1, "57e9f90f6cbd1e76059e634c8774f422167062b9176b6285ea3108817cefc86e") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - Content
setManifestid(1235751, "3014601098507788314", 176754364)
addappid(1242280, 1, "63488492e367ad8ab255e00ec99768b75a3a9af57089d781e2ee83d113b60f90") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - en_US
setManifestid(1242280, "8440609248598545144", 11988)
addappid(1242281, 1, "1d818890218931929b69f6c3bc9baaf33fda7ec4f7611e40bda97fbf6ce3dab6") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - cs_CZ
setManifestid(1242281, "5971328061256404004", 13030)
addappid(1242282, 1, "8ea0215806d222a1e91fd76f8bc3021656924c8c6fbcf0ca604ce2045942b22f") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - da_DK
setManifestid(1242282, "7014789177463574390", 12184)
addappid(1242283, 1, "f02fc06e810f550a510aee0290366fcad4d81f50b1116f41211322fbb7b1df24") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - de_DE
setManifestid(1242283, "8491470203137260916", 12703)
addappid(1242284, 1, "4f2f57f5a748f4c105fe8b66812bec76899835ddf2a89983b5da357ecce3e78d") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - es_ES
setManifestid(1242284, "8487457355267433276", 13022)
addappid(1242285, 1, "8fa5c5875633cdb4918762bbc4e7cf772f7e9f43cc0af1b967f63acd98930026") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - fi_FI
setManifestid(1242285, "4341865973402798528", 11915)
addappid(1242286, 1, "09dfa8461636a5324c4f099e02ac51abf6f0aa80779e461726b69b269dc31155") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - fr_FR
setManifestid(1242286, "4391624262330507116", 12778)
addappid(1242287, 1, "d99293adfc74604c2e2a83faaa178a5c8ccaf6f5c0323e3ef38d4b09b29c7c19") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - it_IT
setManifestid(1242287, "6226962028922304774", 12806)
addappid(1242288, 1, "6ef189c9547a3689ff62d30270c4b27d8a65dbce483bd41037ff98959d3979ea") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ja_JP
setManifestid(1242288, "1289735406857207325", 13484)
addappid(1242289, 1, "99bd520c044052a265c86337802f26389bf0fea01b97edcbddfc97cd365fd086") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ko_KR
setManifestid(1242289, "8879094183575630178", 12613)
addappid(1242290, 1, "e40c8f8f6a6643ebebf352e4e62cf22f5ca3aa5b44c3e41f7dccf56411f44f4d") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - nl_NL
setManifestid(1242290, "4099524943821266579", 12403)
addappid(1242291, 1, "70349fd28642932fb225ae70ceb0661630b31e289b412977f8e3193d3a0badc5") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - no_NO
setManifestid(1242291, "8231742110598869093", 12078)
addappid(1242292, 1, "0db0b2bd2ca6f4d8909851edbf58ae63a3a3d614e3cf1da69eef13d54ee96229") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - pl_PL
setManifestid(1242292, "3903808676839534604", 13877)
addappid(1242293, 1, "40862083b4957fda4f102dc07802785c4816bb6327b88482266ee48a9a4f4c35") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - pt_BR
setManifestid(1242293, "2468385892843688407", 12381)
addappid(1242294, 1, "59769f9739acac8ebf59d9d12ecb49273f26b155cb76ea1d30ebee44816b57b4") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ru_RU
setManifestid(1242294, "2194220721902248760", 14545)
addappid(1242295, 1, "c117cc9a14a50603cebc683f78e563c99856a5d656d4a6616db2950c0652472e") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - sv_SE
setManifestid(1242295, "8106786418177092213", 11810)
addappid(1242296, 1, "c22dd3f89f02047e267c3658ee5c01b169e0f0e078c2fe92b07066b6c153b662") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - zh_TW
setManifestid(1242296, "564199860091818218", 12342)
addappid(1242297, 1, "4a3408c946748e25718ee457b5790d8f7a96b45010868f49ac690073674052c1") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - zh_CN
setManifestid(1242297, "7044854321715897653", 11988)
-- The Sims 4 Perfect Patio Stuff (AppID: 1235752)
addappid(1235752)
addappid(1235752, 1, "f24a455d56e4ff5709317bf583092885075065e9bb74d8a5f806e09da39fb20c") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - Content
setManifestid(1235752, "2227524142397274093", 99504022)
addappid(1242260, 1, "1e5fcea21c4169b77f5f3717523f4f30538bff2179fe2dc702de19727e3f8fa2") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - en_US
setManifestid(1242260, "6713150965313498205", 6376)
addappid(1242261, 1, "23fcaf84fe2af140afb1d51bd89cee2e3819dac2cee3400a8d1a25fbc1c0ce30") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - cs_CZ
setManifestid(1242261, "5629609702802102049", 7225)
addappid(1242262, 1, "40183b943f4f3be0d3bd527c0c0cb165e8d303ed8f7cf2ed3693531668745744") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - da_DK
setManifestid(1242262, "6462208667782983049", 6559)
addappid(1242263, 1, "c6c3f17a7377efc4cf11673ed9501d2422ab1754cd1e3c29a3bb9e298dedc719") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - de_DE
setManifestid(1242263, "1200026267276371012", 6903)
addappid(1242264, 1, "950a23fd609f093dfe47cefc1695aedc00ee928ed1fd2c95ee9df2f9857a2917") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - es_ES
setManifestid(1242264, "780684771770552526", 7032)
addappid(1242265, 1, "193f213275bf4d354803e822f0114f3b039b1b19899eabaa4b38ca44504bd38a") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - fi_FI
setManifestid(1242265, "6380597329033780147", 6069)
addappid(1242266, 1, "9a00e06eda341e6d6ff2631aac1bd231b6494fa4c5d67be1b7a9dfae9e819a48") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - fr_FR
setManifestid(1242266, "4025157865437151153", 7189)
addappid(1242267, 1, "d61ea0f5480b7f9a98df944a4db316ab562bd7f6c0380f1621eb93d4ade2a092") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - it_IT
setManifestid(1242267, "3600544827731750006", 7109)
addappid(1242268, 1, "9d6e5f3428a0f80c3bc917db49840ba3c07fb84f8bb0a2a6d0f521b895da8690") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ja_JP
setManifestid(1242268, "7461863163262350469", 6886)
addappid(1242269, 1, "709e5c5123662a388f551c0fc70306a010ce6c01f222ce535e0f2c52c55186e8") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ko_KR
setManifestid(1242269, "7307884393296311758", 7186)
addappid(1242270, 1, "5991f065b7c12f9bd42d863c378d114634c931ef62711b4e991668938c81f201") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - nl_NL
setManifestid(1242270, "174152019594643248", 6667)
addappid(1242271, 1, "bce5e045a8933d59dd50942c2791424b55f4a8f2a76822cee36a606ffb0ca7b0") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - no_NO
setManifestid(1242271, "8577878829179406187", 6579)
addappid(1242272, 1, "e2362367ba581609fa210275e9187b380868214c7f2f5b97d6be59af5d734181") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - pl_PL
setManifestid(1242272, "5864422100118041110", 7589)
addappid(1242273, 1, "b33bf42dc85c2fb9eea178cc33328ef833e0099a8df43a6ded84de8b800732e5") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - pt_BR
setManifestid(1242273, "8304762519694096534", 6696)
addappid(1242274, 1, "6459adfd4eba8cb92a0402746aa8ffabb01c58e4470b756536d1ceb4a2ed62af") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ru_RU
setManifestid(1242274, "6013764545534905948", 7899)
addappid(1242275, 1, "01f72456b88ec960f9ee5af7ce8963a94f9618041d52c571acfd9592e02d7d5c") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - sv_SE
setManifestid(1242275, "5380139368615239363", 6513)
addappid(1242276, 1, "d5a18864a0649f7c173974c926fc5f5d4066dabb481bf890750290edaa43f708") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - zh_TW
setManifestid(1242276, "6703068797337337441", 6821)
addappid(1242277, 1, "7fcfcdc5503926b875f2330bf1d4f52ffca28bbef16fc1e08b41fd276b89e797") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - zh_CN
setManifestid(1242277, "8420375702070064821", 6376)
-- The Sims 4 My First Pet Stuff (AppID: 1235753)
addappid(1235753)
addappid(1235753, 1, "11f55c1b2b2ffae5e4133cf0833c45107709ba59de2bc7055ee68f1eacd18e82") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - Content
setManifestid(1235753, "2856314461743296426", 173196174)
addappid(1242240, 1, "a3f1e151cb176a3153907a456bb0132c23f3ffaf583460efe294e51de1be5479") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - en_US
setManifestid(1242240, "2812741365533914687", 10705)
addappid(1242241, 1, "4cbfc11ff0fa7f394132c758ed1bafc874787804a7d7ecaf603a2ced67772c1c") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - cs_CZ
setManifestid(1242241, "3353342357355460998", 12225)
addappid(1242242, 1, "2e6bc3a876ff391ab7e665a9fe91cff046bbdaa76b96404188e69ca09b6241d5") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - da_DK
setManifestid(1242242, "5468159065787125385", 10330)
addappid(1242243, 1, "c4119417997869eaff4b8481fbb7e8106d30014ae110a01fbd4242f4ec77b322") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - de_DE
setManifestid(1242243, "1071457493729410502", 11525)
addappid(1242244, 1, "8abf9d4cadfc767ea4353aad8efff6e604e4820a1ff5d8ae56ccea3e80479677") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - es_ES
setManifestid(1242244, "5092492410606676129", 11692)
addappid(1242245, 1, "06c68dbdaee86844b44e3365ad29c237a708196e7d2409b33d75f5657691bf3f") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - fi_FI
setManifestid(1242245, "7643072716308310822", 10328)
addappid(1242246, 1, "69a7f0f2d481e96379a7edf7f75af99615f9146a557c566c95bad35a840955f3") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - fr_FR
setManifestid(1242246, "9102437690648279758", 11506)
addappid(1242247, 1, "44f8465d28f586209b89484cee29068d14d02913f61dc84d415dab53b54751bd") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - it_IT
setManifestid(1242247, "311518400229168069", 11630)
addappid(1242248, 1, "25f7747003e9f5be88078b769d3509afff61f0f2e4496d338f2e23ba8874a8b2") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ja_JP
setManifestid(1242248, "8623263219981704509", 11865)
addappid(1242249, 1, "335d9815ee121f8c87f3fe3cd56e35cbd683de5514f5c5345d71123b63a5a5fc") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ko_KR
setManifestid(1242249, "4298690051485976047", 11093)
addappid(1242250, 1, "6166a6a7ee24dc460a57b76ea7e0c6360e9246bcd3b2630452d988e0fdca36b1") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - nl_NL
setManifestid(1242250, "973303809204603241", 10973)
addappid(1242251, 1, "128416e91fdd72a9a6cd9b2022fb865ed30f70500f1087f582a81d6850a659e6") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - no_NO
setManifestid(1242251, "7876156876894205873", 10411)
addappid(1242252, 1, "503571290c5cd25a2a28b74c4ee33822d21e77503840abccbb0008764543dc58") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - pl_PL
setManifestid(1242252, "8671278489888217717", 12087)
addappid(1242253, 1, "344c213473213e2188031b1b38d18f4495b6f8a755da4cd0266d90eca786fa8b") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - pt_BR
setManifestid(1242253, "3188870776776911339", 11070)
addappid(1242254, 1, "7dc7f7a2e3a14a947a5ab5cc5b72a1e981c34dd933db91c38cf96eb8ff3a0a06") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ru_RU
setManifestid(1242254, "258133022681009660", 12589)
addappid(1242255, 1, "c7b8e82fd86e949e705ac321a5df36ef421d4286758132b04cfdab87d4c217fc") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - sv_SE
setManifestid(1242255, "7892929965410202517", 10646)
addappid(1242256, 1, "5bfadf785d819672fa9513f0a5729028e7bf3de5cb0640c73f087983344a67d1") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - zh_TW
setManifestid(1242256, "6568686635837599976", 10983)
addappid(1242257, 1, "e8cfce0a35badf4a3409297b57b723e98a216c24daabfc5697d89028e284aca3") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - zh_CN
setManifestid(1242257, "5107794058971732960", 10705)
-- The Sims 4 Luxury Party Stuff (AppID: 1235754)
addappid(1235754)
addappid(1235754, 1, "7aa8a0384924f70690672a790c8dcc0bda83b72289db9c4042e62d0400d48be2") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - Content
setManifestid(1235754, "3998214247328346997", 122680714)
addappid(1242220, 1, "aa8dee9f289cddbbc377168cad0b10b7d8fb61c802efdbf72bcf3a58884490d3") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - en_US
setManifestid(1242220, "8956981354641894795", 4877)
addappid(1242226, 1, "5ed6631456ef9f1f95fc3f77ad59417a70e6508d7c146fac886831934c93a69c") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - fr_FR
setManifestid(1242226, "432370601791938355", 5465)
addappid(1242232, 1, "526141e42a3dd57740da5553eca1e61a0962e15ddc3a40f3857e6d12bd6c1c98") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - pl_PL
setManifestid(1242232, "5027012876064061715", 5542)
addappid(1242233, 1, "424334ee8a1cc8002d7ab0efd373cecd6a2ba28e4ef7b4e61e70a68e626dc334") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - pt_BR
setManifestid(1242233, "7555821129144288317", 5117)
addappid(1242234, 1, "64b1cf2559d937d99106162977f4d28512636ccfdb5189d467a7ed968986dfb7") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ru_RU
setManifestid(1242234, "1389157791226005071", 5797)
addappid(1242236, 1, "735d44b33ae22e82b3fcd8a525ca388f1b8fbcfa91f521f687818df008622ee7") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - zh_TW
setManifestid(1242236, "6913986089737881517", 4909)
addappid(1242237, 1, "a77fc4d5437e76c50c2e3ec4cf29c61540767c872b035a3a8e1b52379f3876e5") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - zh_CN
setManifestid(1242237, "4270394135206561723", 4877)
-- addappid(1242221, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - cs_CZ (no key available)
-- addappid(1242222, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - da_DK (no key available)
-- addappid(1242223, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - de_DE (no key available)
-- addappid(1242224, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - es_ES (no key available)
-- addappid(1242225, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - fi_FI (no key available)
-- addappid(1242227, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - it_IT (no key available)
-- addappid(1242228, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ja_JP (no key available)
-- addappid(1242229, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ko_KR (no key available)
-- addappid(1242230, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - nl_NL (no key available)
-- addappid(1242231, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - no_NO (no key available)
-- addappid(1242235, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - sv_SE (no key available)
-- The Sims 4 Moschino Stuff (AppID: 1235755)
addappid(1235755)
addappid(1235755, 1, "f43fa48516505fa06c7ca71371295b051f4522302dd4521c4d10b0be523c7f26") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - Content
setManifestid(1235755, "356403641101584400", 139006933)
addappid(1242200, 1, "1e4faeba323189cfad294385f9901b815011fa9fa6e9f151a9903aa0cd8015b2") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - en_US
setManifestid(1242200, "3962039533948140132", 16059)
addappid(1242201, 1, "c422cead6c6e0db743677b389b6e52b835953910cd6584f2de1f1022a991c911") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - cs_CZ
setManifestid(1242201, "8526529850047691178", 19153)
addappid(1242206, 1, "a295c6a7cea24f4ded674a50b480801252147c82f7e0af60a0155e4309241257") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - fr_FR
setManifestid(1242206, "4457847908478963343", 17631)
addappid(1242212, 1, "c78fa572c2125d1a1650943c1740ef1c959cdd0e0c78109dc1b2770a422b6562") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - pl_PL
setManifestid(1242212, "8083473002978607098", 19090)
addappid(1242213, 1, "ebabe801a62dde99904ae05d3cb164466ba931acfd8ce70d79e9e26820c3ea58") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - pt_BR
setManifestid(1242213, "453916551569612515", 16624)
addappid(1242214, 1, "d22effec4fe68c534589f862df2ffd094ec4ec1c2c81437c515f0facd9c89fac") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ru_RU
setManifestid(1242214, "2128634786141140913", 19321)
addappid(1242215, 1, "4420879e63ccfcc25b9a1045ef75182f5e3a2e379473fab1a05b8d3b183508e5") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - sv_SE
setManifestid(1242215, "2693617950167834301", 16228)
addappid(1242216, 1, "0a833239f0c08e827bea95762e1d3f6aad58d668326b4ca803dcf6e5d5e095d5") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - zh_TW
setManifestid(1242216, "3165815738730078254", 17102)
addappid(1242217, 1, "10b94e0f026ef1ee4acfb2b43285064189c75b5efae7586864ea933e4bfc9ad8") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - zh_CN
setManifestid(1242217, "9184730078883560046", 16059)
-- addappid(1242202, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - da_DK (no key available)
-- addappid(1242203, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - de_DE (no key available)
-- addappid(1242204, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - es_ES (no key available)
-- addappid(1242205, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - fi_FI (no key available)
-- addappid(1242207, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - it_IT (no key available)
-- addappid(1242208, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ja_JP (no key available)
-- addappid(1242209, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ko_KR (no key available)
-- addappid(1242210, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - nl_NL (no key available)
-- addappid(1242211, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - no_NO (no key available)
-- The Sims 4 Cool Kitchen Stuff (AppID: 1235756)
addappid(1235756)
addappid(1235756, 1, "2625e691cada411ccabb251f1ffc80195ab864db76d7a00e6954a9762e6b89c3") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - Content
setManifestid(1235756, "4399484549736153634", 154178635)
addappid(1242180, 1, "6ed7855d76af0e383dcd8ee422046382dbd4a6cf8913a80bf835d81aed78987d") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - en_US
setManifestid(1242180, "7884056186663613978", 7288)
addappid(1242181, 1, "1ab59088384416e95919a5822f2932790d77068ebba60d402e4d3fcffce8efcd") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - cs_CZ
setManifestid(1242181, "6047158543092227930", 8203)
addappid(1242182, 1, "1bfe9f0005a70d1c58ac5db00a92e61df1a5caaf12c7614a5a2f93a1bfa46227") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - da_DK
setManifestid(1242182, "6580566739954737609", 7136)
addappid(1242183, 1, "54869b4be883199323b39aa157c3be2fbc8d7ac5477e88424b51fa963923fa7a") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - de_DE
setManifestid(1242183, "342712411380720297", 7802)
addappid(1242184, 1, "03d56dcc0393b1b34bd533248db6b36a097ca79e7489e5fee78a30ab3c9440c9") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - es_ES
setManifestid(1242184, "7181171355233955928", 8008)
addappid(1242185, 1, "7b400bf3f115c0f7e65bc366355219d1fb6a4747de9146f564cac2f6d9a874bc") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - fi_FI
setManifestid(1242185, "4414981200921860398", 7291)
addappid(1242186, 1, "f9e319a930b1d8d4d93f38d7acfa938683c53f4bad1446f6ab980ba747a7ddbf") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - fr_FR
setManifestid(1242186, "714114901603758078", 8459)
addappid(1242187, 1, "7952982940e04afafdf4c6db7a5b3cd462a1e9193b9048243f9109f4b2b8814f") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - it_IT
setManifestid(1242187, "5421241156307247778", 7739)
addappid(1242188, 1, "139be2f7dc0eace902b3ea6c39928b23a08203c4e6a975b2e996597f2ffe4451") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ja_JP
setManifestid(1242188, "8410543547499538494", 7864)
addappid(1242189, 1, "6f1dd19aad0a9c82354095e47ef8034f6a9171db4500e19c4eda26431e327175") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ko_KR
setManifestid(1242189, "6221100576658497460", 7880)
addappid(1242190, 1, "d4fcf2b4bfdf02e90d130e886cf08ef0ac2800db7da14ae46b69eab579a68bf2") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - nl_NL
setManifestid(1242190, "7764503313549134665", 7566)
addappid(1242191, 1, "e3d70e77a1a3ef786d2f200db3c623ee85ea2b996f30bae12b9f386f2ab4b5e5") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - no_NO
setManifestid(1242191, "5568659210855980014", 7295)
addappid(1242192, 1, "07a9b426f3cc9ba0a0e095aea96bc92e151e94a9a42636731b87238182a9d026") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - pl_PL
setManifestid(1242192, "8647897931742911427", 8157)
addappid(1242193, 1, "835a819fefcf3f969d12a57a13cbe449939977d54d396b8fd0dc3175b4900322") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - pt_BR
setManifestid(1242193, "1280914844543087738", 7642)
addappid(1242194, 1, "c65a10e9bff5988b5cc470eb659a1cfebfd558034ba448680f9e5c8b6932d43c") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ru_RU
setManifestid(1242194, "1300884128956719208", 8758)
addappid(1242195, 1, "cf1b3d7675a1bc15aebe1ccf35c49ac654175c35b8468489744340b9165748b9") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - sv_SE
setManifestid(1242195, "6822899569374686598", 7342)
addappid(1242196, 1, "5c7eee4c352d29cf32ea5307ee9f87257925ea47f6472226ea1fe02e66013626") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - zh_TW
setManifestid(1242196, "4838701664477856229", 7290)
addappid(1242197, 1, "b18d8d304bc69e6aab30df9632d3c1361452495ae91d3ee52d493a9b25f4a2a7") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - zh_CN
setManifestid(1242197, "4042309057164074468", 7288)
-- The Sims 4 Bowling Night Stuff (AppID: 1235757)
addappid(1235757)
addappid(1235757, 1, "6bb80b7887c1d94dc4bd79e1bfd5a2fedc61d5c268f21901d97564f29e72a8ac") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - Content
setManifestid(1235757, "6452647828488617350", 204110267)
addappid(1242160, 1, "952fe929ec30f191fec4cef63c21890464c171de5de6efd48b3b59d98baba70e") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - en_US
setManifestid(1242160, "3590455369050280054", 8356)
addappid(1242161, 1, "203d04926b94b516f1afc0d8b8fd93ff65831e0d7157b9cc4ede9908001a8464") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - cs_CZ
setManifestid(1242161, "5230976452491234406", 9190)
addappid(1242162, 1, "b1976d97ee9af072d7fd14c4a492b4fc96a8fe2ce31b09fcb46fee1ea25c6384") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - da_DK
setManifestid(1242162, "2152607318248541964", 8199)
addappid(1242163, 1, "824d248353c60a63075481b7d0782de23b28db3a2d51f0cb0f5498c2f0109eda") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - de_DE
setManifestid(1242163, "8777499540042130694", 9098)
addappid(1242164, 1, "12d0423943401e36e6fdd0bcf2c2204581183596d9aca06440fb6cdf89710ab7") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - es_ES
setManifestid(1242164, "766231585762873247", 8928)
addappid(1242165, 1, "d9d1d6a6a3e95ba4e744bda1caa311ac947fb88d3d9a64403f7490852f95a583") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - fi_FI
setManifestid(1242165, "7400134234227942254", 8322)
addappid(1242166, 1, "ffe1a53a5f7ebfad4f5b8f49dd1664ca78370d2a8facb18247fd0994d2b99d62") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - fr_FR
setManifestid(1242166, "7483527995110718830", 9260)
addappid(1242167, 1, "71f9016e86a71a728d4c927c66ef4baf48a0aaef98272eb0b00406ef935534f1") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - it_IT
setManifestid(1242167, "8099633812171940044", 9040)
addappid(1242168, 1, "7a8075ed6907653b29c68f7c51df5ac828855d85076af712b14254c698a2b22b") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ja_JP
setManifestid(1242168, "2175897629423478440", 9027)
addappid(1242169, 1, "02b387b767873aa516ce13806195e0a4645f20e27448dd22ee38a5da1715e5b6") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ko_KR
setManifestid(1242169, "9151566196603048796", 8906)
addappid(1242170, 1, "859038de9b769c452048e3207e3d4ad1d682744391586f91413546be874f1795") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - nl_NL
setManifestid(1242170, "2472528529551996763", 8484)
addappid(1242171, 1, "fd046f289738197d3d10b42bbfe9cb6563413acf0a8592ca72f9a258d3aff6e0") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - no_NO
setManifestid(1242171, "7628594700938483365", 8481)
addappid(1242172, 1, "5f5dc21a961cea60e2c2392490587327f5800b01eb4fbb109abd835d1d51a2a5") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - pl_PL
setManifestid(1242172, "4068214671754921415", 9499)
addappid(1242173, 1, "ef4e0561e5809f1a226d498f185611ec7eebad936b99e6cf89d16e9a7458f66e") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - pt_BR
setManifestid(1242173, "6273711240118132458", 8813)
addappid(1242174, 1, "2d9e1a6950696774e70ffeecb00c05b1b4031c09b2528dd56954d1c7aad62d14") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ru_RU
setManifestid(1242174, "7804286628123261397", 10052)
addappid(1242175, 1, "4dcfd68bf7ac9b209649fec02d069426738b9fc2a619997e6a7a670322dfd5c4") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - sv_SE
setManifestid(1242175, "766620459006269604", 8459)
addappid(1242176, 1, "2a5bc5adfe5a595c7c83288cf8d39289b8649a3e6249f4cd05c7552cf4d905b8") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - zh_TW
setManifestid(1242176, "3120038856993942986", 8836)
addappid(1242177, 1, "19837f94caba2f5223796a91c565da35927f6f8025718ca8181bf4125e6420ae") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - zh_CN
setManifestid(1242177, "8740927349033361012", 8356)
-- The Sims 4 Romantic Garden Stuff (AppID: 1235758)
addappid(1235758)
addappid(1235758, 1, "fd86ca3e321d5a746127ec26dd6fa088e9b3c47826d3d282d44441d9d1f6d5b0") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - Content
setManifestid(1235758, "1282481650129003579", 216939402)
addappid(1242140, 1, "19d1ce2e30642812ad159059db7b5d0ad782b9a7e3835fdc1cd1177170ab1c54") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - en_US
setManifestid(1242140, "5960606349242619630", 16464)
addappid(1242141, 1, "b98e01bad1fdf36352e4ef2ac94e68aa08494c9edf4c15005c6ea41e0992e239") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - cs_CZ
setManifestid(1242141, "1878417920114847830", 17750)
addappid(1242142, 1, "366145957def453fcb17901dd70559fa1d79b63437aad39093413dcaaed0121c") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - da_DK
setManifestid(1242142, "4679015073808035455", 15903)
addappid(1242143, 1, "e50b08acbf762a9d0551efa39622ee35dcb1c21cf6e13aca093b03e6a34ea28e") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - de_DE
setManifestid(1242143, "4879825139433030474", 17443)
addappid(1242144, 1, "5b217ebb3e7ed9470172a020bcf3c9852aa080b7a2ac6ba91b9935d932b7f6a1") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - es_ES
setManifestid(1242144, "6619076601109107261", 17778)
addappid(1242145, 1, "032524f744d78bb2b95c36e9a6ae0a419e1f03835d85243db25e4d0400f7b45b") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - fi_FI
setManifestid(1242145, "7839943360490615977", 16445)
addappid(1242146, 1, "df9f6ed35f708780693fd412fa27e5ed581cc475f230ee3765d445e564014e59") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - fr_FR
setManifestid(1242146, "2427979177770536975", 17595)
addappid(1242147, 1, "a70c5cc151dae0ebb97cb7ec77aaa9926a88626e1ca1fe87f535dff60d3a8a72") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - it_IT
setManifestid(1242147, "5190247008985820112", 17169)
addappid(1242148, 1, "d5bcf093c0206f065e20159bec2b65b049a6a39bd783ec6159d3651172b66c5f") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ja_JP
setManifestid(1242148, "5748540422165419812", 17578)
addappid(1242149, 1, "749d9ea302efec49faf2573e7aa0e28023d1c480cc08045865074f9e1b5e3678") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ko_KR
setManifestid(1242149, "4736675481762914510", 17556)
addappid(1242150, 1, "354e0a14299bdb7a5da5a5ccf3395e81fa5207f58982376d1db114589e4552d0") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - nl_NL
setManifestid(1242150, "9105458279363440560", 16963)
addappid(1242151, 1, "65f77b7e55b005adf77da4fcb4e756dbccfa1e4104e3684ace79eff891a8e0cd") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - no_NO
setManifestid(1242151, "4176691111203365461", 16360)
addappid(1242152, 1, "6460586ffb02e4ea203cdb6838a9487b9c4e0428f5209e593894d3c2e678973c") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - pl_PL
setManifestid(1242152, "1802599043908426823", 18747)
addappid(1242153, 1, "636381064a8920948780a97c77eb65ef7d0f619eedf0506e367e3e570a33043a") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - pt_BR
setManifestid(1242153, "8846049464020272235", 16741)
addappid(1242154, 1, "9f20417f5027c7720dc03a2280370b1e7601b010b3390585a902797e352f6fe2") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ru_RU
setManifestid(1242154, "6075312417604626490", 20045)
addappid(1242155, 1, "dd171ee60855c108cc05e581ac1ee06be2264077dd77d052cd82ed36da3e8217") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - sv_SE
setManifestid(1242155, "6001001791953716480", 16332)
addappid(1242156, 1, "b3253455b82652969997f408908aec3ab6ff8a1db391d5556cac0a83dd7b158f") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - zh_TW
setManifestid(1242156, "7771418013569534550", 16808)
addappid(1242157, 1, "d5fda8e63da383c6fb566ca351c654af5be282ea898a03945dd03aa1c89dd7ec") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - zh_CN
setManifestid(1242157, "151293907235828613", 16464)
-- The Sims 4 Spooky Stuff (AppID: 1235759)
addappid(1235759)
addappid(1235759, 1, "2aafcdce1a4406bc20732069711a0b852be5f19a1fc8a2ac81f9f448d642a1f3") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - Content
setManifestid(1235759, "5679134401725234186", 175420318)
addappid(1242120, 1, "f9600393300ff31bb49f49a2f9b64b8601612c9fa94b2a57c8f3edbe4a3ed4a5") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - en_US
setManifestid(1242120, "3983474120086242237", 8153)
addappid(1242121, 1, "cbcedd08942cd3b1b1e371aa301111418c5a283ead5c6d39648ef727099a5e32") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - cs_CZ
setManifestid(1242121, "7369846631898614559", 9117)
addappid(1242123, 1, "9210523a60f12cba6c513c9c22a1d90e1332069a860b71ac30a4559273e14458") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - de_DE
setManifestid(1242123, "1799145384527106464", 8762)
addappid(1242124, 1, "e0f3167688d2ff6c39a3a3a3807a64f66cf4a9dcedcc924ab6e04cdac5642788") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - es_ES
setManifestid(1242124, "7495387766165950439", 8770)
addappid(1242126, 1, "a67c862281e7b42d155b73cab7e2d40828edae539f49572914b4356b24ffd525") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - fr_FR
setManifestid(1242126, "6664664452224706337", 8802)
addappid(1242130, 1, "8c632755f956d93545711fbb62e438d531de4fab313a819c09598ea1db05453b") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - nl_NL
setManifestid(1242130, "5175488616142422907", 8283)
addappid(1242132, 1, "9c741a64bd6c91052b6d8a2eb4e157ab6367eb25ad6a973f7e2854d25e6e72a2") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - pl_PL
setManifestid(1242132, "7751489568160015280", 8901)
addappid(1242133, 1, "5888af3a8df48ca42fd00fdda6e971fd25e9e931c7962bccd7bd6304c8aa0546") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - pt_BR
setManifestid(1242133, "6016485663973469287", 8400)
addappid(1242134, 1, "d0df8bee4c3357cc7a16f5634c1522326d18f5937f847cece53499be17e750d7") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ru_RU
setManifestid(1242134, "4573591335755122599", 9366)
addappid(1242136, 1, "9c15c3d0feb09fbe25a6deaca570f26ebace4876968a53afc6d2dae4097ac3a3") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - zh_TW
setManifestid(1242136, "5019849388618360455", 8377)
addappid(1242137, 1, "3f0a507b60a89fa699df0f7ef6be76ff3bf00cfcca2e36b7ae0f1ecaa65580a8") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - zh_CN
setManifestid(1242137, "1674682441089547192", 8153)
-- addappid(1242122, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - da_DK (no key available)
-- addappid(1242125, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - fi_FI (no key available)
-- addappid(1242127, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - it_IT (no key available)
-- addappid(1242128, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ja_JP (no key available)
-- addappid(1242129, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ko_KR (no key available)
-- addappid(1242131, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - no_NO (no key available)
-- addappid(1242135, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - sv_SE (no key available)
-- The Sims 4 Backyard Stuff (AppID: 1235760)
addappid(1235760)
addappid(1235760, 1, "de560f5a41cbe450aefd2021baf2319462f8913ca8f050f530fef74e1179ce01") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - Content
setManifestid(1235760, "4636022692568614533", 183034879)
addappid(1235768, 1, "7fef112aeb7bd2000b4776da4b83c0763232450c022db99fbbeb03af6042da92") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - en_US
setManifestid(1235768, "3117647189291029330", 8871)
addappid(1235769, 1, "f498a3445149ae6c8b8a9e8ab49f06faff4b339a021959b569674b0baa08d7ac") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - cs_CZ
setManifestid(1235769, "3637470483736920141", 9699)
addappid(1242100, 1, "af79ff5458495fc2a525df96d29a9d84e24d4ca1dd8caa84db38278c7ed99f2f") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - da_DK
setManifestid(1242100, "2956095185932390578", 8789)
addappid(1242101, 1, "1ffc9fb0ca3f22330afc76169b41be90f7b9e414a6ec9428e8bead7456aa2904") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - de_DE
setManifestid(1242101, "1566112799421275895", 9253)
addappid(1242102, 1, "b6c9b2947237ed7526ae24f38688b8223277ac70a2d0de3752d0efc7ed812e2c") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - es_ES
setManifestid(1242102, "322127710603836645", 9328)
addappid(1242103, 1, "9d070357be3404a9c7d75d5ea2d81c949b473c02010f27deed6a26b01913e138") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - fi_FI
setManifestid(1242103, "799062968705713738", 8342)
addappid(1242104, 1, "59a31efa8754168c4582a012aaa22f5ce459493587cc116315538938360382de") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - fr_FR
setManifestid(1242104, "8040536579598645540", 9521)
addappid(1242105, 1, "ec1af767e068d90883c130c7e7f2be10b36fdb351d7d34ea463845114f043f8e") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - it_IT
setManifestid(1242105, "7642407739390050930", 9395)
addappid(1242106, 1, "5ad968b27c97204cd2277369024d1fa3ed89a117bbcc36af970ed13bce1b95f1") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ja_JP
setManifestid(1242106, "6842012887711426449", 9277)
addappid(1242107, 1, "08d0e37a6fc0363eee0b6b50e38fec3627ebf9877dd763809c639b17af78d711") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ko_KR
setManifestid(1242107, "6121927787301173654", 9305)
addappid(1242108, 1, "5630d6a3a8abe6a7c137b5e5acc7b312d2aa43dbb29f7ef8209f31c27baec9b4") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - nl_NL
setManifestid(1242108, "1496966601278432165", 8958)
addappid(1242109, 1, "529809d021147e63f34f2336f3d7fb0fd4760187e24004451dcf919f337adb57") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - no_NO
setManifestid(1242109, "6987349868388013852", 8337)
addappid(1242110, 1, "3cd161e74e31ef9ba3ebe0ac774d756c741acabcc097bbab384563628afa9715") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - pl_PL
setManifestid(1242110, "4190045723220307601", 9864)
addappid(1242111, 1, "ec40dd2d52ace017116ef82e6d000c44e34ebb89df6d0af050d13f1da5deedac") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - pt_BR
setManifestid(1242111, "8195054585417720648", 9108)
addappid(1242112, 1, "50d594e441df651b18db0facbd553d8e1854dd564db04e298fa2caac6702f8b6") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ru_RU
setManifestid(1242112, "1443732204923208133", 10656)
addappid(1242113, 1, "92f7ddeaf4a79224f3ca701548bfce9a0a97e95ef85aebed57e7a8deab527751") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - sv_SE
setManifestid(1242113, "6317773276598536319", 8811)
addappid(1242114, 1, "c2277dc3cb32655c86ae3406778654011e6592570f93c9434232f5894a347e6c") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - zh_TW
setManifestid(1242114, "909078760300638810", 9030)
addappid(1242115, 1, "fdc68fd51c54f245965ad08508e148abfcda48a40fd80b7fc528f4b8f95e17f2") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - zh_CN
setManifestid(1242115, "8640448922111061112", 8871)
-- The Sims 4 Laundry Day Stuff (AppID: 1235761)
addappid(1235761)
addappid(1235761, 1, "5069421aeb0da6c9302aa412853473bce3813a6e010d1b7231a83ac2eb7294be") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - Content
setManifestid(1235761, "5859621191022818362", 163510547)
addappid(1242080, 1, "3c139023565065583700445340e21d911982c6e2455a144e7edcd0326e1ec2dc") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - en_US
setManifestid(1242080, "2413009059003732731", 12657)
addappid(1242081, 1, "111c2e9451a2b9de00b7c00c64856d7267846903e787784d4ab202d005a3b461") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - cs_CZ
setManifestid(1242081, "1086082308555810245", 14237)
addappid(1242083, 1, "fc86e929bc011f83fd4ab7d7a68545e068ba23cc93f6cd2dd85a55f80a578465") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - de_DE
setManifestid(1242083, "4361940079800379833", 13376)
addappid(1242084, 1, "d7200f94248c6c8fda845de84c0384e9e4e952430b9d3f41392dfc723f5857e3") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - es_ES
setManifestid(1242084, "2954820759451528211", 13784)
addappid(1242086, 1, "193252afc1531b1604ec628a02a4f3b5b5b95942cbf9149f965168f7f9536575") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - fr_FR
setManifestid(1242086, "4672841705346353404", 13312)
addappid(1242087, 1, "6786ac8a7826337736a778b8b447f232faaf062fa9d21001ece511e873d31b3f") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - it_IT
setManifestid(1242087, "4291855721043473891", 13692)
addappid(1242088, 1, "ceff036ffa217d8eceb58abc87340895d3ac49d3fc356e8a2b99015c60aedd14") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ja_JP
setManifestid(1242088, "918369129461152108", 14041)
addappid(1242090, 1, "2030a779413a412603668cbdcda3d7c8f7cbcabbbc2c5bb1bc01949967d0227e") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - nl_NL
setManifestid(1242090, "5237273284638145765", 12873)
addappid(1242092, 1, "df28dd62cf9b460016bf82c2f5ed00b3a6202d62ae29c3d4fb08da077a35f47c") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - pl_PL
setManifestid(1242092, "7627759892326511197", 14559)
addappid(1242093, 1, "ef6e641cd213e2b4d14ff239c1f123b545d013729d4d09e77d34922f946fe48b") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - pt_BR
setManifestid(1242093, "3316774060667813414", 13088)
addappid(1242094, 1, "cdaf9b426d80cd9a4c6e95564e55793dfe17c915011ee26c589c6fec063c21e2") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ru_RU
setManifestid(1242094, "4152539229753966107", 15248)
addappid(1242096, 1, "9f2cea352f9f77a92b014e3e193aff52dba7dfd73a1b42f45ba5b64a4af491e9") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - zh_TW
setManifestid(1242096, "2384918165196870308", 12917)
addappid(1242097, 1, "13f87fb55e31352e7bf3a5336cf009b50965d68f878564fe239c3db5d56e724e") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - zh_CN
setManifestid(1242097, "2510342742969221555", 12657)
-- addappid(1242082, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - da_DK (no key available)
-- addappid(1242085, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - fi_FI (no key available)
-- addappid(1242089, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ko_KR (no key available)
-- addappid(1242091, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - no_NO (no key available)
-- addappid(1242095, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - sv_SE (no key available)
-- The Sims 4 Toddler Stuff (AppID: 1235762)
addappid(1235762)
addappid(1235762, 1, "3ff64685a83f07516b8d1976a9dd3504ca915107d2454fde4df863dcd2a01a46") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - Content
setManifestid(1235762, "2467430671654209380", 168442646)
addappid(1242060, 1, "84a84976e176a8dbefde2631cfc0ea2aa7d2bd82b6cd9b1b10ce5d7630cd0cf4") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - en_US
setManifestid(1242060, "9158706299182388006", 6804)
addappid(1242063, 1, "7b001c2c903b359b4859caba3d679ec4fa29e603fc83965e17e6d72d1fc57165") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - de_DE
setManifestid(1242063, "3624871711801819279", 7272)
addappid(1242064, 1, "fac3fcc3bfa233b90587b899d5f691d837d664101d927fa670c50b20a48d687d") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - es_ES
setManifestid(1242064, "8945671072548617515", 7647)
addappid(1242066, 1, "addd710d2587cbed3e9d8afc5771c51adcae64dc354443cbd9e629374c5364df") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - fr_FR
setManifestid(1242066, "6107769552587184117", 7734)
addappid(1242067, 1, "8cc8aec46a66d456a39130e2c4d2f206e793c6aebafaa083120927eb03304e5b") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - it_IT
setManifestid(1242067, "8001237763440927133", 7575)
addappid(1242070, 1, "ac608b00cc91e9b2d11cf581a698de4d6419a469214b5cbc5ed3b38013372608") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - nl_NL
setManifestid(1242070, "5788304348245795229", 6967)
addappid(1242072, 1, "48c256e78d0e18567ac8ed04a65d2848f4f82456f09daa28185780e129fb16f5") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - pl_PL
setManifestid(1242072, "6830970893257250980", 7977)
addappid(1242073, 1, "745e6a6fe38ffd2c48f63c5240c29bef30ccc1d0149ba50d73141685f8a9eac8") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - pt_BR
setManifestid(1242073, "268174374392347785", 7112)
addappid(1242074, 1, "5e13ef1eb46e5160df1eab9bab040d103dd60af50e8fa797880f9aca210d6bb4") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ru_RU
setManifestid(1242074, "2397755369109857350", 8123)
addappid(1242076, 1, "7e622f4154e55d7196a45bdaa670bbd90c80bf0f28d2a05ee0b0b81eef20a68e") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - zh_TW
setManifestid(1242076, "898121787562998571", 7282)
addappid(1242077, 1, "5393af73f00817c49f11105fa4d0f1d1240b5932fce257e1c531f60c33d6af0e") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - zh_CN
setManifestid(1242077, "5167652041367514831", 6804)
-- addappid(1242061, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - cs_CZ (no key available)
-- addappid(1242062, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - da_DK (no key available)
-- addappid(1242065, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - fi_FI (no key available)
-- addappid(1242068, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ja_JP (no key available)
-- addappid(1242069, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ko_KR (no key available)
-- addappid(1242071, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - no_NO (no key available)
-- addappid(1242075, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - sv_SE (no key available)
-- The Sims 4 Kids Room Stuff (AppID: 1235763)
addappid(1235763)
addappid(1235763, 1, "9aeadafea38c37dd3bf1252d227a7fbb61ca715bf3f9e0a12659a036696ddbaa") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - Content
setManifestid(1235763, "8779928363234404261", 163266101)
addappid(1242040, 1, "5a478f6ac9ed24b7d4cb07db4e4878743715b7cfc2c8b59bc197a8ffc9adf272") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - en_US
setManifestid(1242040, "4761946961684361190", 17067)
addappid(1242044, 1, "f073e0d3efee063c14805f51e328555385cb29068d4de70ec04bdc20a7d71842") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - es_ES
setManifestid(1242044, "7389127140442029923", 18641)
addappid(1242046, 1, "4dfd13e430b286cf17cf48c32cc6597276bf307180211853f4830666edadf5f7") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - fr_FR
setManifestid(1242046, "8286016636162641062", 18520)
addappid(1242047, 1, "4ae16c988fc8b7e455c1de48387445b9c705e5501a09bd4dfe0c3c9f6baabf6b") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - it_IT
setManifestid(1242047, "7321835174393082173", 18044)
addappid(1242050, 1, "1f3a0b7ce650ff0c453de543977e9d64b1ee389346ba7b5c158ad0b7c949e057") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - nl_NL
setManifestid(1242050, "299681735132381319", 17145)
addappid(1242052, 1, "f4368b30d0a67454e75c6d844ad88c488319fa0ba43a03eeb0df143ba16b420d") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - pl_PL
setManifestid(1242052, "3221211762801316644", 19434)
addappid(1242053, 1, "1cd22a4e5446b82679d278fcccb3b7c45df0cbdf7ec48f29cde1ff204b6dd286") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - pt_BR
setManifestid(1242053, "262038492770459603", 17011)
addappid(1242054, 1, "15b7ca649feb4476b305e0a0b11f4015b4aba988c8ea8e9c554a7364ec81d21d") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ru_RU
setManifestid(1242054, "121508748788041614", 20169)
addappid(1242056, 1, "6fcf3fb4928411738737ddeee01b4189c761641ee024cc3b8fc5565dad108e65") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - zh_TW
setManifestid(1242056, "6754146748772549218", 17644)
addappid(1242057, 1, "c867d6c0f6c2178724e5a89f3188888307984492925289f4e07b4f0ff2c08a21") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - zh_CN
setManifestid(1242057, "268990804290654435", 17067)
-- addappid(1242041, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - cs_CZ (no key available)
-- addappid(1242042, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - da_DK (no key available)
-- addappid(1242043, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - de_DE (no key available)
-- addappid(1242045, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - fi_FI (no key available)
-- addappid(1242048, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ja_JP (no key available)
-- addappid(1242049, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ko_KR (no key available)
-- addappid(1242051, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - no_NO (no key available)
-- addappid(1242055, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - sv_SE (no key available)
-- The Sims 4 Tiny Living Stuff (AppID: 1235766)
addappid(1235766)
addappid(1235766, 1, "efcf0dc7b24eb7a88f94e85e76a86cec9b8e67f158c7be8a364ce66277e6f888") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - Content
setManifestid(1235766, "1804222058465831257", 225725752)
addappid(1241980, 1, "8963ea5f2caa283bb0ce38311855ff940485c7f1ae0e361bd2e548e4ac96a34c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - en_US
setManifestid(1241980, "5969268171133967144", 9140)
addappid(1241981, 1, "9e1166f635ac698900d3ebc5579d353889c9843ca1fde92a465ce134bef0c2d7") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - cs_CZ
setManifestid(1241981, "4096768486659030739", 10614)
addappid(1241982, 1, "1599519675edf82cdbc34d6e852f81e21bcb78b4ee55a62878c2040f11fcec18") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - da_DK
setManifestid(1241982, "7697933291477830035", 8909)
addappid(1241983, 1, "2f89df032148229f02ad9eab1c87921fcd35b8852ef91e7bbda71a6bb5211827") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - de_DE
setManifestid(1241983, "5317114376852221200", 9714)
addappid(1241984, 1, "79002c3ccacaf12ad89bd60ee6211d6d85d2bca984041bce9569a2837d0ae3e3") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - es_ES
setManifestid(1241984, "2550222507074985578", 10073)
addappid(1241985, 1, "cf2a415d28647d14a2d880c4bbfd60fe77f9587e5db4cf0ef85d3a4ac58a54a3") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - fi_FI
setManifestid(1241985, "7923607267645698019", 8928)
addappid(1241986, 1, "483cd18b3dd8d23cdb91b26a3d56814a45945acae70c56100b4f342516973842") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - fr_FR
setManifestid(1241986, "7711414855857446480", 9948)
addappid(1241987, 1, "ec2423b31d4e6975aa7330291b8110000720da25fcbd7bf1cb4ddc9a56cd0ec0") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - it_IT
setManifestid(1241987, "1460028360526248257", 9983)
addappid(1241988, 1, "551cb489f867764c45fcff4f0a8ecf1c50cba78efb8074122f38f7ced0bb7d3c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ja_JP
setManifestid(1241988, "2095808071155450436", 10181)
addappid(1241989, 1, "1c38333540322eef8382df34881b3e63a02c18fc2253adc33303a861bcc59c30") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ko_KR
setManifestid(1241989, "156282115830625458", 9832)
addappid(1241990, 1, "f4be7b3cb637188f2c81b18dc2f399c38c28353e72124be7d90af535cd0e0fca") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - nl_NL
setManifestid(1241990, "6316169403877007943", 9315)
addappid(1241991, 1, "bf39757ffbb78948245023333591c1acc2050a2ac272fd37ace909a8fe1e6b36") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - no_NO
setManifestid(1241991, "7072590029045422652", 9032)
addappid(1241992, 1, "d8ae20cd2b2661315c7ce6ec0ea9fd2e5890c809bc5a0a970b47b8a7071ae013") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - pl_PL
setManifestid(1241992, "8854372835465257989", 9444)
addappid(1241993, 1, "ed3c668284f105736bb739793b24513d8f4314515d56cbdb32e4911d7c6f7c0e") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - pt_BR
setManifestid(1241993, "5802122424363990677", 9251)
addappid(1241994, 1, "c3c4d69a0f449932e29e38555369f4788a9deb922276e0eed570741ae2486360") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ru_RU
setManifestid(1241994, "6373634460871741050", 10766)
addappid(1241995, 1, "eee0d9d132429a14e55f0dd2cbf782a85a56317955f2688989c030622262176c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - sv_SE
setManifestid(1241995, "8090396690762462571", 8976)
addappid(1241996, 1, "4499d725336f7813f496bff0ee544034f7d2d8603ef667af98e1ad00bfd4ae66") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - zh_TW
setManifestid(1241996, "8795742531202288513", 9473)
addappid(1241997, 1, "d6122e2895c598acd345095c6cb76327a96db1a5aee328c775baa648b585e611") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - zh_CN
setManifestid(1241997, "6454486510686620147", 9441)
-- The Sims 4 Movie Hangout Stuff (AppID: 1235767)
addappid(1235767)
addappid(1235767, 1, "406954c37bc4e86fe902b7bbee18b417ab24a49bb25080c8a37d0f18f91bdda3") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - Content
setManifestid(1235767, "5292363071621063080", 231792958)
addappid(1241960, 1, "76d99a5ee110917e0d063f66738f467f4d6bd4ce22ec4179ea1a716570bd7ce9") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - en_US
setManifestid(1241960, "2622264068999773788", 16209)
addappid(1241961, 1, "0ea7828d25fedf5c78fcec43bd7d41bdbbeb6de64c7af2c2e26e149f0871f9e8") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - cs_CZ
setManifestid(1241961, "4367832844284040190", 17658)
addappid(1241962, 1, "3f393a6ba6788a7df2586afb13a1b441ddbc823769e27637f43d505e0e901b9c") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - da_DK
setManifestid(1241962, "733844563950424994", 15780)
addappid(1241963, 1, "bfcf4da651cb456aeef6d748c09996e7021d27be73bf3cf605f3b18685478886") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - de_DE
setManifestid(1241963, "5762302828009603290", 17576)
addappid(1241964, 1, "1d07962c808ea176cc079e2058a5f759fd89f1ba52f836a153fb70e94b5bee2a") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - es_ES
setManifestid(1241964, "3761196500102557806", 17547)
addappid(1241965, 1, "8d1193b8091e5d40458b7ce1e345405ad1608f99ae768c393e7dbe7330017086") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - fi_FI
setManifestid(1241965, "7580601624621483241", 16370)
addappid(1241966, 1, "6302e2d34517493cdb4864a2023e389b7ab9aa58c05816c55217f7bef0f2b7af") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - fr_FR
setManifestid(1241966, "4116516796426989460", 17466)
addappid(1241967, 1, "3ea53386ad284dbfa5e0ec3b3b5a1e3e5c9e0519c8e0e8322f9dcd36aeafba78") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - it_IT
setManifestid(1241967, "8153753728460650023", 16774)
addappid(1241968, 1, "1a10131d41e060781953c2115724635722138e5abf0f9630262e295bb9240354") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ja_JP
setManifestid(1241968, "5403297347092652166", 18157)
addappid(1241969, 1, "2f5d1ce7ce55719b6a718df5564fa30187a0e4a484e2cab4fcdbd355388145f2") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ko_KR
setManifestid(1241969, "4696044168190358378", 16533)
addappid(1241970, 1, "6bfa4290076075bb4ddfe07837491f6a8b7f772df0d768b3b2ed20a9498f20ec") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - nl_NL
setManifestid(1241970, "3811481117031340427", 17362)
addappid(1241971, 1, "7fa0558edd8ef6608cb9e1b1c03457d1c96baa15e3582980844d12e8b6f30c3b") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - no_NO
setManifestid(1241971, "3591176874941402886", 15804)
addappid(1241972, 1, "9d2b302dcdb049e87e4da0576ec30ed031172faefc46c633b16d2c441c9ebc9b") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - pl_PL
setManifestid(1241972, "4282971391611172850", 18573)
addappid(1241973, 1, "383aba4fb5d79ce2f901605b757b1c690bf1ca37084a4dfbb6d36cb754721fbb") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - pt_BR
setManifestid(1241973, "4159252444476810848", 16204)
addappid(1241974, 1, "11def70d63d2eb9c5a95a8b5758053bde74a25d90e3b00a255cfa824c31362bd") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ru_RU
setManifestid(1241974, "1951177935823038919", 18889)
addappid(1241975, 1, "017b9c2c1e0522b084eed7977f3c652dd957113adfd2fa53f864969afd24b300") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - sv_SE
setManifestid(1241975, "6772958072290820872", 16109)
addappid(1241976, 1, "76c87c9b6d203344e83f3f8790b8a4d730856018826738f5877c5b3f2aba98b7") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - zh_TW
setManifestid(1241976, "8624583872033065595", 17052)
addappid(1241977, 1, "51a46510c1d41948bd7281d9e6f2caeeddfdaf095593fe26faeeb1be3e61b040") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - zh_CN
setManifestid(1241977, "5766113617914915694", 16209)
-- The Sims 4 Digital Soundtrack (AppID: 1271130)
addappid(1271130)
addappid(1271130, 1, "65b09123aaeb364c31b839838e2d9dcc4a54e5345c0ef1074d6495879d83f773") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - Content
setManifestid(1271130, "7815763109556229206", 57247640)
addappid(1271134, 1, "a5efc3c655724516c9768230846c02e1d424d871dc9a7d7fe576efaaf05ba9a2") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - en_US
setManifestid(1271134, "6317439271323513227", 402)
addappid(1271135, 1, "d6793dc08449897375caa52712cdcdcc143f501d888fdd4112f0c9b87019dc9f") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - cs_CZ
setManifestid(1271135, "3881645692638709930", 402)
addappid(1271136, 1, "6d9af6f7453573e3b025f52d7b585b1d588b6c590eff4b035b457c84fd2f3402") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - da_DK
setManifestid(1271136, "3232832021771077776", 402)
addappid(1271137, 1, "5bef13a6fb82157fa8d0afaf01ac12e91ed51e120c85b67f49aea45d6e975911") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - de_DE
setManifestid(1271137, "3783175336027759965", 402)
addappid(1271138, 1, "c66ab1186d2d945d237f9dd00de6f74cd290338cc563f58f3fff68b00a184723") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - es_ES
setManifestid(1271138, "2830085197532496237", 402)
addappid(1271139, 1, "49d7d53756c107e9b87587f78ab8e41f457d09c3a17faf30a8b22a33502a107b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - fi_FI
setManifestid(1271139, "7802607241627515810", 402)
addappid(1301190, 1, "9ae4fde90114f83c4685971283b2526a53b1ee94366b1ade09611ed2bb0577fc") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - fr_FR
setManifestid(1301190, "5532500839968484771", 402)
addappid(1301191, 1, "29b8ae792ba2781c26a1b5b4d780f3914a19fd22cbbd234856679cd5a739e253") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - it_IT
setManifestid(1301191, "7289108159037066952", 402)
addappid(1301192, 1, "1b4f988a0a642c32714e2096202bc4268a5e5cd5c74d24b1fe2eaa8cd1f6a089") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ja_JP
setManifestid(1301192, "1133198910699620672", 402)
addappid(1301193, 1, "31af35a6964c82c70c96bdf39a46a7b9c7412d67dc8d5d91420a5eed24d40b2a") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ko_KR
setManifestid(1301193, "8765487576288556757", 402)
addappid(1301194, 1, "0178d47c0eae18d2d3e81013323300dc73eb89f37ff81a9a36b82f3ab7fdcf7b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - nl_NL
setManifestid(1301194, "8242299837807217081", 402)
addappid(1301195, 1, "858472e14966b33c7cca2d3366bb8a01ee160c67454cde8bd409308e2d835a5c") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - no_NO
setManifestid(1301195, "1920034128079275251", 402)
addappid(1301196, 1, "c05319bb0c046f164c7950bc4db07bfaa421f06ccb1213f2166a67ab4bb22166") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - pl_PL
setManifestid(1301196, "1526225006056909948", 402)
addappid(1301197, 1, "1db3cde6be9cb6c38932250b7fc5bc40f74d50f52c62634141601c9abc91e974") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - pt_BR
setManifestid(1301197, "996658610877793470", 402)
addappid(1301198, 1, "e2578362cfe5018e4bae70ffd44789477d80c1622b5cd5c45d080e6f9dae8c12") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ru_RU
setManifestid(1301198, "6363098253443263067", 402)
addappid(1301199, 1, "a5eb70d608010f36bace2a79c80f499617b5dee66b6dd402e879bfd551ba15cc") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - sv_SE
setManifestid(1301199, "1232398104660320194", 402)
addappid(1301200, 1, "b2f9ecab245e15c1a3ee973f5b4388d8ff850047c86695f660dc04d9f55654ca") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - zh_TW
setManifestid(1301200, "9198578045495941041", 402)
addappid(1301201, 1, "8d32fab3e50d78d62a02116ee4eef9d62d2080ff6ac48f06685236d75ef3f77b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - zh_CN
setManifestid(1301201, "3954382600983178116", 402)
-- The Sims 4 Eco Lifestyle (AppID: 1301020)
addappid(1301020)
addappid(1301020, 1, "e539edda978a6777debc3a267022920caa8b27fcc1bc448ea1ef8504d797d6d9") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - Content
setManifestid(1301020, "2456194892744940875", 1523173174)
addappid(1301022, 1, "7d559751990df0008bc4019ed3eec7dd2135ec2c8fa6bea0428714cc8280b256") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - en_US
setManifestid(1301022, "6619863893092513508", 118103)
addappid(1301023, 1, "7fb26229a1d8f23265b3b0d16c446bf8b5548dfdf650f61697181747afcbfa67") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - cs_CZ
setManifestid(1301023, "7896376233208152213", 150072)
addappid(1301024, 1, "7463c409c859360f87c9caff544f45e0cbda9fac140baf5a9c60e468ae59a82b") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - da_DK
setManifestid(1301024, "1076822785954640508", 126808)
addappid(1301025, 1, "554e4d95b48e663cdbbcf14dee12fdea072703b77c02c52b165e385efc7abc5f") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - de_DE
setManifestid(1301025, "3941282140523197816", 137277)
addappid(1301026, 1, "e1162bf5b7e94d6f09978d0e89e1aada0ec257f07e4439f4caf64c0321276560") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - es_ES
setManifestid(1301026, "8465668818363684755", 139311)
addappid(1301027, 1, "8268108e6398daa1d452bdc640bcb381409835375e1c13b6ba027a949ee860d2") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - fi_FI
setManifestid(1301027, "6299286058436212370", 126493)
addappid(1301028, 1, "e306618d739c67fd4613284b0e24646188e22ee32dd72e3cd9bcc1d3a94c8d12") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - fr_FR
setManifestid(1301028, "4841835163651305191", 141027)
addappid(1301029, 1, "9e9151370fd289e1b60e934e2e28926c2e711a33fc7c9ec2d3717784aa0a0151") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - it_IT
setManifestid(1301029, "7477720723445116807", 138608)
addappid(1301170, 1, "18c6daaa60295c6c6620a1bd2b954d2f0cfb62e4b04302fe60aec7270bafe17c") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ja_JP
setManifestid(1301170, "5269879543424252101", 140248)
addappid(1301171, 1, "94134dde0791e8d91ae8e6e5d4c94d9fece4cd52eebda30ded3341ad65eaf5f1") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ko_KR
setManifestid(1301171, "5410343091752793557", 136657)
addappid(1301172, 1, "445f19f11b3d678b8e738e3ea734a7693e5644fc18e2f02551e3288db35181ca") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - nl_NL
setManifestid(1301172, "7949947434169309264", 131133)
addappid(1301173, 1, "3c2101c4d79caa94c70c4c6af614e27a28f68a6bc9be117dbd4ffc0c30c55f0f") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - no_NO
setManifestid(1301173, "457778860801853092", 128347)
addappid(1301174, 1, "6254a24c2ac11c3c8f01ab5b6170dc843ebe287bd9e95db8748b66e4cca574be") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - pl_PL
setManifestid(1301174, "7004592633093888414", 143609)
addappid(1301175, 1, "4ae0e7b667e08dc79b0e9b8bc3ad560b26e58aabb60e363ae75caf7724f2c9f7") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - pt_BR
setManifestid(1301175, "4278768245394058403", 130897)
addappid(1301176, 1, "4612df155f65683e8328e4d4624b0e9d2a29375d9b92e778209d723240322028") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ru_RU
setManifestid(1301176, "2150697677266969583", 156735)
addappid(1301177, 1, "10eaabec31414739b6b2a4a9fd785659cf66c77b7d2db7d2061de5ce8fe64865") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - sv_SE
setManifestid(1301177, "4273295610916253626", 128682)
addappid(1301178, 1, "0e65ea84b4d41ce5dfae4b49c69cb32860824edaf5b3c8ec82c7ca470ac46f7b") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - zh_TW
setManifestid(1301178, "7541971099032925420", 124881)
addappid(1301179, 1, "392fd1c9fb87a68d47454241afd87296e9b2aa86c7e8fc247ed993122f14355d") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - zh_CN
setManifestid(1301179, "4720155257949091800", 116126)
-- The Sims 4 Star Wars Journey to Batuu Game Pack (AppID: 1301021)
addappid(1301021)
addappid(1301021, 1, "7fe53f4931975351d980dcb6a12230dd180f71c187e7c73a9d4b6e6930c3a00e") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - Content
setManifestid(1301021, "5181768117119294794", 1471490438)
addappid(1301150, 1, "53fc29e4979b9c1b7f3e0f19b2f05aa39dd138d7d78db2aff461d454f0bb6a52") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - en_US
setManifestid(1301150, "1027278803354490801", 144935)
addappid(1301151, 1, "624afe285a5e85c0cf9ee096577d2aff61573318f7a0a76bb8c6179fec5de292") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - cs_CZ
setManifestid(1301151, "5974668365561340991", 167524)
addappid(1301152, 1, "a686f6b96ddb19888589d0b34a4fa772ab44db866b3b7256cd5f05f2df524e7c") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - da_DK
setManifestid(1301152, "3835300688266630294", 144455)
addappid(1301153, 1, "c238b5b15f8a135b43c8d3e277ad5d2b602578b9fbc78524e642c695d55727c2") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - de_DE
setManifestid(1301153, "5060709533964459665", 160165)
addappid(1301154, 1, "b8d64d87a5157d0ec3adb29c38cda2b1291838ed31eeb25ad60aa4a11d33a9e4") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - es_ES
setManifestid(1301154, "2336590865135684005", 156684)
addappid(1301155, 1, "3ca277e3ee68982f5a3cb0fe368492fce049c061d5695fd40dbb7c0f1d202d72") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - fi_FI
setManifestid(1301155, "8096087192260472636", 150434)
addappid(1301156, 1, "4daf823fbe0133ad6508195c046e698b160ad5d25fefec1d3e3158a90858a853") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - fr_FR
setManifestid(1301156, "5637099537761564738", 159147)
addappid(1301157, 1, "f55cd229d08bd7295512b412854d8e6e796909a0d941d2d31dac1866a69a88a6") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - it_IT
setManifestid(1301157, "5275874066381824105", 154935)
addappid(1301158, 1, "efcd79e1c916843f040e2449d562016b5939df7c61387a7f7fdf883899ca592a") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ja_JP
setManifestid(1301158, "6702942923172447153", 161291)
addappid(1301159, 1, "0f0fda415dbf0aa0245db62bfbd5dfba33f36d27106fbd04011afffc081276f5") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ko_KR
setManifestid(1301159, "756955418950264099", 158388)
addappid(1301160, 1, "5aa74103d1112e817e2ecbd950b6d6aad6b3570ea351a4f17fafe91027aaa9d1") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - nl_NL
setManifestid(1301160, "1966159134802265727", 152100)
addappid(1301161, 1, "8c9fa1103fc9318a9662fece7e9b70889fc295172d5d636300a8b9ae787440b4") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - no_NO
setManifestid(1301161, "7995911484924565537", 148567)
addappid(1301162, 1, "4b882398c93e75936cbdda77c6c6b6099c9fc7f7459be5d258b0919e555f90d1") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - pl_PL
setManifestid(1301162, "5006887085269383618", 161506)
addappid(1301163, 1, "2f3d0360f5695d37afbd15126086bb409749aee8f2e9e2896a509b601fd881e9") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - pt_BR
setManifestid(1301163, "2877651316524337390", 149269)
addappid(1301164, 1, "f81e28bc49accacb52e6c9e1fc0088d48f53a8dc23c65b8f7eb5c19c5b1aa20b") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ru_RU
setManifestid(1301164, "683496015957865063", 179555)
addappid(1301165, 1, "429a3cc739fb92c55d59f04b92c2c1793de3e695b7c57338b3c2a703f8dad807") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - sv_SE
setManifestid(1301165, "3715114126369917608", 146581)
addappid(1301166, 1, "509e1543003de001f951d3d81cedb10b4fe78aa0181d1571afe8716e847e1b2f") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - zh_TW
setManifestid(1301166, "8555745429883564877", 154923)
addappid(1301167, 1, "fad9ba1aab67aa4f9f993d475fbe4ad74f4e373ddfe1445e457c86888150db9e") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - zh_CN
setManifestid(1301167, "117972553202763301", 143492)
-- The Sims 4 Nifty Knitting Stuff Pack (AppID: 1368570)
addappid(1368570)
addappid(1368570, 1, "d35ed1839c643cd948ccc4faff06aa33ae75b05a43242601f9315723f4a7fc7d") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - Content
setManifestid(1368570, "3777348435253184677", 265103530)
addappid(1368573, 1, "570fda4c4f60a9635003ad3d2702aa79d7fcc11a99881db6f7c0cc1472510bc4") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - en_US
setManifestid(1368573, "4587048074879294319", 17739)
addappid(1368574, 1, "8dea31443e0f9edbb3b2da6a1eba31cf0efd42e88239b248ccbbec387a83c5bf") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - cs_CZ
setManifestid(1368574, "2589552624256423406", 20500)
addappid(1368575, 1, "bb59a26c138d6281ac84dec72d749a6ac7808b42032a3da11f99ccc50a7e2953") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - da_DK
setManifestid(1368575, "8139170644856065001", 17668)
addappid(1368576, 1, "393906ef46fc02ea66180b7be18a41d95c758b3adba543427502325072d66930") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - de_DE
setManifestid(1368576, "7939566230839858656", 19029)
addappid(1368577, 1, "3a32f66334ffc70a609e11b0bd7a6f2905ae4b2e47da32529e43db3163da762b") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - es_ES
setManifestid(1368577, "6898991660960066843", 19132)
addappid(1368578, 1, "93d0e55eedc7f2cdc3d3b08e0cbb908fbe7c51712f645c0e82050f22f816cc91") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - fi_FI
setManifestid(1368578, "498997160394250683", 17883)
addappid(1368579, 1, "505a30e4a6f95188a115dab5a8ca369ee20cb549d7083c6ecc058459b109d958") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - fr_FR
setManifestid(1368579, "5046613085918898157", 19234)
addappid(1369590, 1, "fcf1462f8f8b3ee52321d1a756a03437dca66813027e5f63eec912d6471f59dc") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - it_IT
setManifestid(1369590, "1057148470775575227", 18882)
addappid(1369593, 1, "a8c4a98d90711d5254dff43abda527d77f835eae1f04139fce23a7e606486d03") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - nl_NL
setManifestid(1369593, "8084615537210798075", 18212)
addappid(1369595, 1, "0755e203b244edea5429801ce42282def827815d90c43b7681c8b0e5af07e3af") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - pl_PL
setManifestid(1369595, "4042614880805103283", 19717)
addappid(1369596, 1, "cce15c752b9513fd29c9de8339c29e214060f253939282b0eac2fad5c83b00a8") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - pt_BR
setManifestid(1369596, "8529615864492814153", 18502)
addappid(1369597, 1, "e4bfedbb2dd47e8dadbf6d671eeec6fe3d6d6f58aa7f1f5ca0dd8c389c7eaacd") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ru_RU
setManifestid(1369597, "1386931357300465153", 20996)
addappid(1369599, 1, "426e3c350d694d5dd02f45f87f22509d85c9a5d80dbb71228eb5707421d549c0") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - zh_TW
setManifestid(1369599, "1561492269837424218", 18421)
addappid(1369600, 1, "71078da38605290958df77e0112594ef5f7e2bba6b5da8ab705a2107e38b28ac") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - zh_CN
setManifestid(1369600, "8699876168432971455", 18084)
-- addappid(1369591, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ja_JP (no key available)
-- addappid(1369592, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ko_KR (no key available)
-- addappid(1369594, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - no_NO (no key available)
-- addappid(1369598, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - sv_SE (no key available)
-- The Sims 4 Paranormal Stuff Pack (AppID: 1368571)
addappid(1368571)
addappid(1368571, 1, "849729a55c7573e72905d6de64304e59c7ae397363f8f91f711589d66ce90c31") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - Content
setManifestid(1368571, "421034828886148929", 245488271)
addappid(1497410, 1, "d137718d1b396316c88d8828f16b659e4d3feacd07d8bd8f1d06b1c817f9a6b8") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - en_US
setManifestid(1497410, "6636960055701196168", 29308)
addappid(1497411, 1, "a802fb953dc2b9df22231f7659a9e13a421bda37b188e64b77c3e984ed20f1e5") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - cs_CZ
setManifestid(1497411, "3931381615767244326", 33524)
addappid(1497412, 1, "4edafb301e9b767d19f94ec7f68cf082524f6c8cbb80c643094df01590268125") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - da_DK
setManifestid(1497412, "4195345581100456167", 29082)
addappid(1497413, 1, "8ca8f6ac48ee7e5e508992bc6ceecf8017fb729dfa92f319988fea58a9d6db80") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - de_DE
setManifestid(1497413, "4891084024957038899", 31530)
addappid(1497414, 1, "e6c0206bcbf663632bbe28957978577200b3f8997ff4fd4834a0a157be53df9a") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - es_ES
setManifestid(1497414, "674776152031639993", 31786)
addappid(1497415, 1, "2bb92ef4f7a1f52432a798c656bf9d2fae7c126030234074327a0459204ec0ef") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - fi_FI
setManifestid(1497415, "6453161386319531084", 29773)
addappid(1497416, 1, "fb212dfb4133931b5ffe7c41afe35e0569652153096d3f4bc645244cd36c52c3") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - fr_FR
setManifestid(1497416, "1672320251703322132", 31733)
addappid(1497417, 1, "ca4edb18fc6cafda238c0f8c0f07f28f894c3830ecfc47cd0e6932da78fbf701") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - it_IT
setManifestid(1497417, "376385880551769569", 31181)
addappid(1497418, 1, "0c7c294ed1c8bcc8fc235e2e99adf66eacaef3ace934e346afdb77abd9e516da") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ja_JP
setManifestid(1497418, "2522113690434384036", 31161)
addappid(1497419, 1, "9e217c19ca7ef9b4dc20e1e0dd9e9c95f879db4834707b07a0abc4f8e5390f7c") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ko_KR
setManifestid(1497419, "3995351805926355482", 31436)
addappid(1497420, 1, "df7036bf55ee969203c674cfa5b208321cb994c85991048d2799ebea19655e3d") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - nl_NL
setManifestid(1497420, "5298418368279654312", 30114)
addappid(1497421, 1, "dcb8bb21c122f1e30a16b0750f289e1991106bad8291f84cfe674bea33b78858") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - no_NO
setManifestid(1497421, "6985632557148926856", 29830)
addappid(1497422, 1, "7c087349865f524c71d8d82eb80e7f1f4653d6474fa2318ba8bf04829f9ebeea") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - pl_PL
setManifestid(1497422, "6545983517398345352", 32404)
addappid(1497423, 1, "970ee94ed6fd6fcf9f001c52927cacfa9c21f9187a966c142217f851dd38a665") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - pt_BR
setManifestid(1497423, "2339207991378326574", 29814)
addappid(1497424, 1, "8cfb1f04bfd9fde1bd306733be7e1a35b58bd657c2195017c505b80eb3dc8207") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ru_RU
setManifestid(1497424, "3068259777679217349", 34184)
addappid(1497425, 1, "299189ff6761465037a781c44641c0c7074e2ed7544356a26e4ee30484c8ce32") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - sv_SE
setManifestid(1497425, "4868647577723183211", 29486)
addappid(1497426, 1, "915a9b05d436073aaf33176496f8af2d080ca58d41ffafabf65de8e36ff1bf53") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - zh_TW
setManifestid(1497426, "3140798763051086174", 31188)
addappid(1497427, 1, "8a8011a749f370f1135b3d367f8539b3d2549e1aa2e20ddeed91c0f7428d1647") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - zh_CN
setManifestid(1497427, "1795146033022133186", 29056)
-- The Sims 4 Snowy Escape Expansion Pack (AppID: 1368572)
addappid(1368572)
addappid(1368572, 1, "ce8d5290e87af0a8e0d85c1332b86bb99ed3abe038ee1fe994eaedc89f37fc00") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - Content
setManifestid(1368572, "353366211042366474", 1638586046)
addappid(1451590, 1, "a1b00f3a0d6604a2af9c505280be15f3e3a99abccbfdce7d4e1b04259e194fa0") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - en_US
setManifestid(1451590, "869865880586793112", 143956)
addappid(1451591, 1, "7ac2c8f6370d7e443ff6a898995734a0c7c67d42bef660bccf0160d925107a45") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - cs_CZ
setManifestid(1451591, "7841225003890649052", 167847)
addappid(1451592, 1, "189a2123dda57c3faa72a9c52472ddbb2e674a8cf6f234695fe884152d8699b0") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - da_DK
setManifestid(1451592, "2568950487868642822", 142845)
addappid(1451593, 1, "0fdf6907b340753512776e9902e831ce0bad6540422f24d8f49148073655ed87") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - de_DE
setManifestid(1451593, "6688442964459701078", 156319)
addappid(1451594, 1, "296fb5bc6c582b3b75a6831c349ab7e6559163fcec8a5e5072547ad76660a323") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - es_ES
setManifestid(1451594, "5280949588376634444", 155591)
addappid(1451595, 1, "a6b579de1d0f8bc8114cbd8ec2a1d2e92e8758262dae10acfd5790fc3e486287") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - fi_FI
setManifestid(1451595, "6305325393882932014", 145630)
addappid(1451596, 1, "1a73ade768a1f892d9b02b5c7c43688bfe11054ace0dedbd503e12bd680e20bc") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - fr_FR
setManifestid(1451596, "8212130213490165875", 159032)
addappid(1451597, 1, "e55389bf52a74a362cec24448e70b1da69de8765830bd30867a830c44b2075ba") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - it_IT
setManifestid(1451597, "4530274026386956792", 155196)
addappid(1451598, 1, "3d577d9737db5b8316653833ff23365e655a650f9b391e400190dbec29d2564f") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ja_JP
setManifestid(1451598, "3823511172110898679", 152372)
addappid(1451599, 1, "35c39fcf471c915c12e649ab94ca43c6fdc2f99776b6019efbeea1512215d5de") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ko_KR
setManifestid(1451599, "9172696904597557597", 154447)
addappid(1451600, 1, "9e8dbba6258e6fde17fb09ead2e170ec845432609c35b805182b7947299f923a") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - nl_NL
setManifestid(1451600, "2147212971471762913", 147319)
addappid(1451601, 1, "a186893e97f3b892f3ee02e25a82c98b1796ba4e38ca78106bdab7d7933bb51c") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - no_NO
setManifestid(1451601, "1657047139754924610", 144251)
addappid(1451602, 1, "729457410b198d3cd757fe19aac736ba1d6336187b393f58ac0167fa54b1f354") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - pl_PL
setManifestid(1451602, "8376233879147108574", 161751)
addappid(1451603, 1, "590c1d2344fdcc9b0178779e86bf37d0b8160b6e2223ea60261d900164119ab9") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - pt_BR
setManifestid(1451603, "626336279957485484", 145952)
addappid(1451604, 1, "645dc909aadb5c76bc5a54db3c9a5536212eb011146fbcd37459354000aa1bfa") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ru_RU
setManifestid(1451604, "8769135358877631039", 175156)
addappid(1451605, 1, "fd8e8bb299374bd3104a19c55df09345158a2f9d7c9ea18a4a669c75392d3024") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - sv_SE
setManifestid(1451605, "4845336021556669102", 145549)
addappid(1451606, 1, "5394ff19e6ef73fd1a1810ce11d72d3681a1a02571d440fe346868acf23ebf6b") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - zh_TW
setManifestid(1451606, "7036718861903230555", 152998)
addappid(1451607, 1, "4d4f1842f0b0b3515f33da793bff9acada5e60423d414e0736b199ab521988e8") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - zh_CN
setManifestid(1451607, "2674277461224903516", 140152)
-- The Sims 4 Cottage Living Expansion Pack (AppID: 1458150)
addappid(1458150)
addappid(1458150, 1, "f9934097f977b2d842c58012e6ad448adb5822fcf6195574741d2653a49b904a") -- The Sims 4 Cottage Living Expansion Pack - The Sims™ 4 Cottage Living - Content
setManifestid(1458150, "2475783503368640958", 1718993870)
addappid(1458156, 1, "03e8eb17ec62baa02b2c511d298fe38e7444b72d2850410329cb5a9a5d8e6469") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - en_US
setManifestid(1458156, "134270943836588691", 159191)
addappid(1458157, 1, "fe6769c0499eccd96623e6e86273c86f8ae8f8352e9498e35b4f024b223e3cd7") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - de_DE
setManifestid(1458157, "271273330832597193", 169274)
addappid(1458158, 1, "6d887fe7633efe5b478dcbcd0edd323d1d3b9bfa1361431603764755304d5e7c") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - fr_FR
setManifestid(1458158, "8915391099199843868", 173373)
addappid(1458159, 1, "66a4d49b1273b15e7ec18bee51e6958f56c6fe37f843e595faf8af494a86ae17") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - it_IT
setManifestid(1458159, "8845902113022557423", 170436)
addappid(1497370, 1, "a7eb2f99fbe253df3aa03d56ec19390b545f9370729a0ff20a18ec24cdfd5a2e") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ko_KR
setManifestid(1497370, "5289386261417317854", 169400)
addappid(1497371, 1, "52d1cd107399161a63cf32d5fd8ce689c63d992c4c90d034539b169fe757d405") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - es_ES
setManifestid(1497371, "6301286888464732288", 169561)
addappid(1497372, 1, "31d2357798d00a3542594517f0c12d4e24cf7031af7f7b2280a21aa6056f5091") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - zh_CN
setManifestid(1497372, "7058954439561006592", 157739)
addappid(1497373, 1, "8c940ccbda8a44d493352d67661d0cfd7fb049c5453972cdcb2c01c392f8b2d0") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - zh_TW
setManifestid(1497373, "131061920944702588", 166945)
addappid(1497374, 1, "374e5db242713a7f487a762b194cc2a2553182e6d5258474ef6a20daea68e862") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ru_RU
setManifestid(1497374, "6229907997914204165", 190672)
addappid(1497375, 1, "3927bfe87b0624658eb197c2f3659e63d765356a39a5f8d6d76f15775dca965a") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ja_JP
setManifestid(1497375, "5047428659039092286", 178056)
addappid(1497376, 1, "20a063b44ec23d8585be69dbea8a8e4d4df710a1b54aea08cfac25e49a9cab75") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - pl_PL
setManifestid(1497376, "5560023777845442650", 177496)
addappid(1497377, 1, "9a85cf3ee4d27242aa6bbbb11e6cb7056691ba568e96585355d359c90bf0e7ff") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - da_DK
setManifestid(1497377, "7879249847656083737", 154077)
addappid(1497378, 1, "56216140832b72cec435bd8a0c3beb6d9a80ac8c400fa46bcd1fd50768ed59c5") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - nl_NL
setManifestid(1497378, "6995872830648717143", 158768)
addappid(1497379, 1, "cb1729a2fc697d47912eb1ace5562e3f42cedf8a14c5bcbb97733789fb41c25c") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - fi_FI
setManifestid(1497379, "2004327305102905799", 159521)
addappid(1497380, 1, "4ac1ae1cd23e93c1eb270289150a416571d5243d4d7eb547d35478755873db44") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - no_NO
setManifestid(1497380, "1391798189144405377", 156436)
addappid(1497381, 1, "d1bed1b8d38fe6527fe0cdef15e4a03f1f3ce42df08d9bb7220b5ca590c60534") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - sv_SE
setManifestid(1497381, "1193170009414976924", 159971)
addappid(1497382, 1, "4ac82123b51bfdef68b6397a17a6f527d0b7d7ba06df811a44cae57a781541c9") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - cs_CZ
setManifestid(1497382, "6174362929505376002", 182064)
addappid(1497383, 1, "aec941fb973a8c338ba1529cd8f19cb2aa74555c2f55489b5a3a74b8f5ffcf6e") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - pt_BR
setManifestid(1497383, "8965043530490009994", 164093)
-- The Sims 4 Dream Home Decorator Game Pack (AppID: 1458151)
addappid(1458151)
addappid(1458151, 1, "ffd37d4996390c8c988758e9a5190d3fdadaa40fd050947793f5761552a87b65") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - Content
setManifestid(1458151, "6574518570237531470", 696124998)
addappid(1497390, 1, "ac76fea33f9d26cf01401a732d99c2d8300ce6011ab57093b7a2960e59091faa") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - en_US
setManifestid(1497390, "4421689695965108932", 53478)
addappid(1497391, 1, "c0a16eee4e180fbc745311b96ef96d6c21f922b94dd5e734503033f316816ad2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - de_DE
setManifestid(1497391, "1492994134459837480", 56846)
addappid(1497392, 1, "fdbce02dafc8ceb1960cf1d01ec3e7fa6d82bfdd7fbe95c00cf5a2a535f851f3") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - fr_FR
setManifestid(1497392, "4483821307516103734", 57482)
addappid(1497393, 1, "6eca3b14629eba6a166b6b15479e849e68200e8594a3e66943b203069cfdb22a") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - it_IT
setManifestid(1497393, "5161478778742104452", 57323)
addappid(1497394, 1, "486335a51d9008e1c0b5edb6cdda4235c4d46a86c0c26e0715db0248daf02e5e") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ko_KR
setManifestid(1497394, "7613623374303031115", 57903)
addappid(1497395, 1, "15a5e762810a381d54d1a80c77dafeccce47c896235108a5481004f9a1311f09") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - es_ES
setManifestid(1497395, "4464080490121105060", 57268)
addappid(1497396, 1, "e608ff3c8f2c61bd56f023fde6a251bb88ee3501964ddec264ba685a7ec735cd") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - zh_CN
setManifestid(1497396, "377855002635858733", 54122)
addappid(1497397, 1, "15cb6dd33dbed378f7345b1a0330d3e1ac7813747a2993cc4eb0f8aa1e17b8fb") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - zh_TW
setManifestid(1497397, "8179888822838110970", 56828)
addappid(1497398, 1, "ecaebdb9b4ee1bd1ef36820862836dd5d4bc0c65af93cff9a484a50a69c1bbd2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ru_RU
setManifestid(1497398, "1686165573233180433", 62844)
addappid(1497399, 1, "31938cd38c41cdb8ceace01b6065f5a0ef03cfb3c827db5b8b981727602c06bb") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ja_JP
setManifestid(1497399, "4464633226640030967", 59965)
addappid(1497400, 1, "09917bfda89b9568e0a7f318dca86c385be108c2435d14d92ba2ce56c1141d13") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - pl_PL
setManifestid(1497400, "4708170486873944751", 59791)
addappid(1497401, 1, "e94327cbb8ea0941374a5b4effa53db30cc38b1624f7e883095488037874495d") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - da_DK
setManifestid(1497401, "1546673333144447994", 53275)
addappid(1497402, 1, "574c4e612bf55c3897af79dc5fb0b53b61f6e881f4a293e9ff10318312732dd4") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - nl_NL
setManifestid(1497402, "7961045218938571172", 54588)
addappid(1497403, 1, "9bb0803a0e9a6302e5c5ff2b6569ed169d0b226cf05c6fb093422d8638b014d0") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - fi_FI
setManifestid(1497403, "313567582138420390", 54489)
addappid(1497404, 1, "6705f6f7ad9f4fc3b60fec763a1773f51883df2c60e320ff00cc055c4319a38c") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - no_NO
setManifestid(1497404, "9143435941428324664", 53371)
addappid(1497405, 1, "cbd778f808510d69bc133522144e485e17158a708e7e5425378f9a0d21f42b21") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - sv_SE
setManifestid(1497405, "4662792762696073654", 54656)
addappid(1497406, 1, "1778570260629f14bbaaf8b5c127e2e6ae3c8609d42409ef6f521debe60ff1d2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - cs_CZ
setManifestid(1497406, "5039399840019398218", 62331)
addappid(1497407, 1, "430af2e4a05f72b39de667af537728bb47d91466b5744829d6eeff6d2facd199") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - pt_BR
setManifestid(1497407, "7722037985840908025", 54385)
-- The Sims 4 My Wedding Stories Game Pack (AppID: 1621460)
addappid(1621460)
addappid(1621460, 1, "28046ed8b2323d2d16d2579f6d3323cf6d2d46454d37794c3f2cf424b918a70f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621460
setManifestid(1621460, "6108252659477375314", 956414138)
addappid(1621461, 1, "7e31e7558c7dc87b0ac4db95c4b2e6a959784fea034a37826529c702f3618646") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621461
setManifestid(1621461, "4978911916106724934", 59583)
addappid(1621462, 1, "f24a201cc2af9985b0dab298810506fe08bd6cd11c0051abe1b8ffb77feac167") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621462
setManifestid(1621462, "904675166077980423", 63959)
addappid(1621463, 1, "065f63aa0c61303316da44a94da51d5ed5666de1c45cdf6a8d069325d4b5e3f7") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621463
setManifestid(1621463, "8374915658816100678", 63534)
addappid(1621464, 1, "e9eefce6097f97f652dcf52931a119ae2ae376953a087d4eefcaf3e0242dc57e") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621464
setManifestid(1621464, "7806180315825084326", 63052)
addappid(1621465, 1, "c80f2d9c279e32e779b1f8e4318d128630422a626cf55e884968a6ce98fd6070") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621465
setManifestid(1621465, "8916312397689980296", 63800)
addappid(1621466, 1, "dd414190bc7ced1383e5e2fb0759accca67ae43646a5cefadd65170df182d59f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621466
setManifestid(1621466, "1760438942103940450", 63949)
addappid(1621467, 1, "bdfd89e82e34dacd4a5c705da9ab31903d70709c7697a989a89a087d1deb8d4d") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621467
setManifestid(1621467, "1223426738484134498", 63426)
addappid(1621468, 1, "0c71e07783dc6a70cb613ba7399d13d195f02cec6bec43b4d27342222150671d") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621468
setManifestid(1621468, "1906095156965683546", 64811)
addappid(1621469, 1, "0d3d8af04741c93af8adcad1ffdd01c519d0b3c8c2415089dd349105f5c8d16c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621469
setManifestid(1621469, "7739244526920355190", 68898)
addappid(1887460, 1, "7f7b4dd63f5fb8420949b160177bfa4ea279b7394d5c5cca66e9d4907e15d078") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887460
setManifestid(1887460, "7897091518620714194", 65089)
addappid(1887461, 1, "e2837d562ea6c2087738246131ba6ebc0cfb1c3076c3560113d9ce7fc973611c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887461
setManifestid(1887461, "1472218380850188397", 64662)
addappid(1887462, 1, "18982b0ef7b419eca156c6d67572e1fc58fe98167b3181d04bcf9ddc9d5252a4") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887462
setManifestid(1887462, "1410545604744242455", 59086)
addappid(1887463, 1, "0d2519d51abab2f1fef228be9f65e17120c0d6ecb1428b434ae09a15ee434513") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887463
setManifestid(1887463, "8657949340388751055", 61234)
addappid(1887464, 1, "24991f82f1b91f3d57bd78689e9c065defc6ef79b4e46aee10f0f90d72c8c22c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887464
setManifestid(1887464, "4889710664579561410", 61763)
addappid(1887465, 1, "15d5cb185a208f1ea0225f8de67211d0876f041d09aa1cda4d4309bc20580b2f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887465
setManifestid(1887465, "5662057219002568338", 59499)
addappid(1887466, 1, "fad899341bfbb5f7e64f88f0487b7881200c9f588dc7660ad01ab1bc137e83f4") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887466
setManifestid(1887466, "3995336524656356754", 60557)
addappid(1887467, 1, "053afcf3d1030073242ac2c33e6683e013b41e9bf941ba0b8c150e218c8bfe94") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887467
setManifestid(1887467, "2205205503715849006", 68012)
addappid(1887468, 1, "df386664e8cbcbc12f5a10af21eb1369ba749dd077cecbeda681a5c1a67a4125") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887468
setManifestid(1887468, "1601423817669600189", 62005)
-- The Sims 4 Werewolves Game Pack (AppID: 1776780)
addappid(1776780)
addappid(1776780, 1, "581647324a77ddfcde726021db1659f00427fedfc80c62c10ee326bbc22095a4") -- The Sims 4 Werewolves Game Pack - Depot 1776780
setManifestid(1776780, "8035319235340258346", 987501634)
addappid(1776781, 1, "af14d1368191f66458cee36dd613f5bacce0f83e138cfeda0833dd219eb5621d") -- The Sims 4 Werewolves Game Pack - Depot 1776781
setManifestid(1776781, "3996630660420387444", 112506)
addappid(1776782, 1, "ab76fb18e704719a7a016d6d56af2f66f25280ca8d2d628bdcb72f6fbfa3ce8e") -- The Sims 4 Werewolves Game Pack - Depot 1776782
setManifestid(1776782, "74997119665354601", 134386)
addappid(1776783, 1, "285c10016631a147917528b0fd27f0b6b49101615a5fd93167eb0623d953117e") -- The Sims 4 Werewolves Game Pack - Depot 1776783
setManifestid(1776783, "8382364317354525901", 134247)
addappid(1776784, 1, "05c9ef8d532a2d29e8501228fb9ca6e136823883b147bd3ae9a7de13e5b9ac9e") -- The Sims 4 Werewolves Game Pack - Depot 1776784
setManifestid(1776784, "6773976434275962254", 130935)
addappid(1776786, 1, "2e4b478c603c7241afe0473572582253464a6c06ec2cd71807919b06197b3a2f") -- The Sims 4 Werewolves Game Pack - Depot 1776786
setManifestid(1776786, "4795559948880979224", 134226)
addappid(1776787, 1, "e32cc1612e4a44aadd7cee3a0c69507079158fea474fb6cefedac44d3f1d60d9") -- The Sims 4 Werewolves Game Pack - Depot 1776787
setManifestid(1776787, "8482482516293622275", 114286)
addappid(1776788, 1, "289d849006fa543cfc2c325af9a7e4fdd21f8b730945e431d90069e332cd7880") -- The Sims 4 Werewolves Game Pack - Depot 1776788
setManifestid(1776788, "6833678326956257065", 120644)
addappid(1776789, 1, "39fc1b17e808063ede225647f39f0bcdbe5ec0b9f2661e8421b48d14fa4c075a") -- The Sims 4 Werewolves Game Pack - Depot 1776789
setManifestid(1776789, "4614599553820782163", 151334)
addappid(2009981, 1, "5ded80576ddab62f4b9517f7330ef5719575dd2a12320d9ebe39e3aee1fa1626") -- The Sims 4 Werewolves Game Pack - Depot 2009981
setManifestid(2009981, "2190555410699598502", 138845)
addappid(2009983, 1, "e06304016e18f9fe6d18bb4d632a8b7ee05a16ea300b5ccefc916733bffb5279") -- The Sims 4 Werewolves Game Pack - Depot 2009983
setManifestid(2009983, "4650199754700354930", 121597)
addappid(2009984, 1, "f733316909e5ad6e18f5b7176a4d22909c2e131981ed87a62d6cb77ba9e5ec4e") -- The Sims 4 Werewolves Game Pack - Depot 2009984
setManifestid(2009984, "5923907060903077917", 116275)
addappid(2009987, 1, "090f76513474925e36322d95edad835860f7319ba6a404f05baff899cb27580b") -- The Sims 4 Werewolves Game Pack - Depot 2009987
setManifestid(2009987, "1366079391754511581", 142074)
addappid(2009988, 1, "aa14c1267fab491768e0aeee17ea86a3ad52d1e6cc04051f80c90adc40cb3b31") -- The Sims 4 Werewolves Game Pack - Depot 2009988
setManifestid(2009988, "6993872201117716261", 125904)
-- addappid(1776785, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 1776785 (no key available)
-- addappid(2009980, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009980 (no key available)
-- addappid(2009982, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009982 (no key available)
-- addappid(2009985, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009985 (no key available)
-- addappid(2009986, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009986 (no key available)
-- The Sims 4 High School Years Expansion Pack (AppID: 1816550)
addappid(1816550)
addappid(1816550, 1, "fac953358c31f7117fbdcbbbe788235f57d94d0d8a2404e18effa46e4e200209") -- The Sims 4 High School Years Expansion Pack - Depot 1816550
setManifestid(1816550, "6106969796910051033", 1885606672)
addappid(1816551, 1, "444a2ddd006be4a9e433a8660ed7234d54f16f764c8f30030584e06994377506") -- The Sims 4 High School Years Expansion Pack - Depot 1816551
setManifestid(1816551, "5770678443457103475", 186354)
addappid(1816552, 1, "1ca8d407f53f48dfa54e4c620b5c942ccdbc7d5d8aaff5cb5a5bcdc39c4c2285") -- The Sims 4 High School Years Expansion Pack - Depot 1816552
setManifestid(1816552, "2240731810917532702", 207250)
addappid(1816553, 1, "afa2f7322142fecd39b23f1a9a05f675ce877eb4e7110f6d9cff14769b00a326") -- The Sims 4 High School Years Expansion Pack - Depot 1816553
setManifestid(1816553, "9158345717837728629", 208836)
addappid(1816554, 1, "959e56ef92858841d61d9ad311a88fd07cd09317fd175973bb9502e6d8e94fa9") -- The Sims 4 High School Years Expansion Pack - Depot 1816554
setManifestid(1816554, "5425037882748849067", 202536)
addappid(1816555, 1, "cb4296d1943075dceea6ef4941407873dfeb27356d8de938ae03f0e3f43f7a88") -- The Sims 4 High School Years Expansion Pack - Depot 1816555
setManifestid(1816555, "1644607339325523626", 207625)
addappid(1816556, 1, "616b5284a3ce5ea8f1f0436c5fe157174a089c9cec57e9b73e6ce3bdc3e6536f") -- The Sims 4 High School Years Expansion Pack - Depot 1816556
setManifestid(1816556, "6762287675196226830", 206526)
addappid(1816557, 1, "c75df932914fb2f3331d9b7b77cb4683d3500e13b81ddfa112dc90867a9b471f") -- The Sims 4 High School Years Expansion Pack - Depot 1816557
setManifestid(1816557, "1465475253290495472", 193979)
addappid(1816558, 1, "0146049a3c4dd0be433c3361e53e0b766ccf445dc63ba8335a3de55a5a5c8b5d") -- The Sims 4 High School Years Expansion Pack - Depot 1816558
setManifestid(1816558, "3503746974856929509", 204321)
addappid(1816559, 1, "87ce2619c97bbaa5c9f57167c9dc7027203bd976830c4e4455ebab5394f5df08") -- The Sims 4 High School Years Expansion Pack - Depot 1816559
setManifestid(1816559, "2811471468985013364", 234357)
addappid(2082021, 1, "36b783d21fe6f6dfc8c879683d1d99646eb1f1eb9c6ff9b018b68e0fece4c56b") -- The Sims 4 High School Years Expansion Pack - Depot 2082021
setManifestid(2082021, "809417982817319624", 217250)
addappid(2082023, 1, "d46f82e82d82546c4dc695b1c138398b19ac6988b6efede8dc891a5409c13af3") -- The Sims 4 High School Years Expansion Pack - Depot 2082023
setManifestid(2082023, "102626722701220579", 194121)
addappid(2082027, 1, "fdf8f96b05793e2ce0cfeeb1ea3b720e323bad61a3749e8610149525387bd67d") -- The Sims 4 High School Years Expansion Pack - Depot 2082027
setManifestid(2082027, "3854887825906373079", 219934)
addappid(2082028, 1, "f3de462f1718baa3143667ac0ead33a1f3579e5c79988a90785aa1acf4d56b88") -- The Sims 4 High School Years Expansion Pack - Depot 2082028
setManifestid(2082028, "7760590412914401339", 196640)
-- addappid(2082020, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082020 (no key available)
-- addappid(2082022, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082022 (no key available)
-- addappid(2082024, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082024 (no key available)
-- addappid(2082025, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082025 (no key available)
-- addappid(2082026, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082026 (no key available)
-- The Sims 4 Growing Together Expansion Pack (AppID: 1904392)
addappid(1904392)
addappid(1904392, 1, "35720e27381fb46832b003eb33785dc8e27b6f5076ae22b5901fb0ddd628518d") -- The Sims 4 Growing Together Expansion Pack - Depot 1904392
setManifestid(1904392, "4468230005761982789", 1430823496)
addappid(2112480, 1, "b861c595b9ad8bfb551c777b9cbe224f8601ea03ea9d566b01047585a43366cc") -- The Sims 4 Growing Together Expansion Pack - Depot 2112480
setManifestid(2112480, "1799033147138312932", 182096)
addappid(2112481, 1, "198ac53b99c5e62996f48ee9de53bc6a820a086f569ddcbab4e8d49bb74b007f") -- The Sims 4 Growing Together Expansion Pack - Depot 2112481
setManifestid(2112481, "4489717170218661000", 202703)
addappid(2112482, 1, "564487fe7faa30ef2f01382c9966e91a979ed837039a1b36cd685866c6ce2016") -- The Sims 4 Growing Together Expansion Pack - Depot 2112482
setManifestid(2112482, "3878524153179209919", 204903)
addappid(2112483, 1, "95887b3f16f61dbb9f3a9feef20dd10ff23918607bd860dafaebab6ce0cc9e03") -- The Sims 4 Growing Together Expansion Pack - Depot 2112483
setManifestid(2112483, "3252552788342759626", 199816)
addappid(2112485, 1, "a2c64d288bdeb3db95a29072bf397469bd5ef3e2d0b38515e7ebd02cf0ef3eff") -- The Sims 4 Growing Together Expansion Pack - Depot 2112485
setManifestid(2112485, "4750851173171152198", 201097)
addappid(2112486, 1, "129fef3ff7d919d113058cc79e5f70ff4b0cb884ce28bf83c7f6cd6ffa577ca2") -- The Sims 4 Growing Together Expansion Pack - Depot 2112486
setManifestid(2112486, "8218160856655348199", 196659)
addappid(2112487, 1, "171d729c39e69b34df5b42649dd2ac25cd6e756428867f2eed64319c43a412a1") -- The Sims 4 Growing Together Expansion Pack - Depot 2112487
setManifestid(2112487, "8923027845480508353", 200000)
addappid(2112488, 1, "ce519dbcd061b6acaf28cb6f0587775b4010abcdf1cadf5073a2e77cb27fe32c") -- The Sims 4 Growing Together Expansion Pack - Depot 2112488
setManifestid(2112488, "5252394332050389708", 225630)
addappid(2112490, 1, "c087a295833d94a764e8a79a9760d68ed3229b7191ed4cac36de1f89fad9127d") -- The Sims 4 Growing Together Expansion Pack - Depot 2112490
setManifestid(2112490, "7496155112872765449", 213573)
addappid(2112491, 1, "d44c47406a666b5e849e6f66e83f3ed00a3513e9889c854f96c8ff1faf40aee9") -- The Sims 4 Growing Together Expansion Pack - Depot 2112491
setManifestid(2112491, "8294913893373408412", 183842)
addappid(2112492, 1, "7e951281425f8b72e0716a000bc6cd359f61b6c095ae96a53a9825dbbfe0e1b6") -- The Sims 4 Growing Together Expansion Pack - Depot 2112492
setManifestid(2112492, "4779256713055391840", 189034)
addappid(2112495, 1, "1cb85c1a58493adfeef28a7e5de5433478b4b83d804d74b660ef08888e090e1c") -- The Sims 4 Growing Together Expansion Pack - Depot 2112495
setManifestid(2112495, "2314594374354202036", 185862)
addappid(2112496, 1, "59d35928f45faa995c6ca2c904e63a70c8aa731a5e69f305ad70c33a17fdd2fa") -- The Sims 4 Growing Together Expansion Pack - Depot 2112496
setManifestid(2112496, "6947063460565045415", 218562)
addappid(2112497, 1, "6172bd16c311880c44c892ba4d0860129e3ea2f3489f0eca04ebab4a9ff0b3f6") -- The Sims 4 Growing Together Expansion Pack - Depot 2112497
setManifestid(2112497, "6519554777889779039", 193377)
-- addappid(2112484, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112484 (no key available)
-- addappid(2112489, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112489 (no key available)
-- addappid(2112493, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112493 (no key available)
-- addappid(2112494, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112494 (no key available)
-- The Sims 4 Horse Ranch Expansion Pack (AppID: 1990600)
addappid(1990600)
addappid(1990600, 1, "4760151948568879e2ffe7cfb1aea04c9155a3878510ab6cdb494d1c37979f9f") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990600
setManifestid(1990600, "8174830575527578719", 1906918061)
addappid(1990601, 1, "5ee8664c02741b666faec03233083a7fda5a4e3a72acd4d3a6d0fa8a464fddda") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990601
setManifestid(1990601, "5975636439949893784", 123914)
addappid(1990602, 1, "62579ba907e33ff0af465a9ce21db1c9325fe5ac47a1911795c9e12776c41e57") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990602
setManifestid(1990602, "8233045793521830261", 137893)
addappid(1990603, 1, "998860097a3daa31d3a4fd16832783809ff553652dbff1014ec97299186a3c71") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990603
setManifestid(1990603, "2575872375231914302", 140918)
addappid(1990604, 1, "8eea42a8a046e7cd1ca481091d1c841a087e3c92adad01e6186d17697d2201d8") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990604
setManifestid(1990604, "6917142306489964064", 136320)
addappid(1990606, 1, "51f0234995c61d9408ab0b68e0b6b5e17fc954a5eed143f7faa1b5fb9d2a4414") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990606
setManifestid(1990606, "7041994858044071697", 138666)
addappid(1990607, 1, "30d210200e8b4c6b7ecf59b118f75625f85fc886fce4cbd51155a5d9f683c1a0") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990607
setManifestid(1990607, "4025652300848709174", 131232)
addappid(1990608, 1, "d89938a74d6b65e09781d17e9dead1b733d4d4bcbf7b08f93b8a84e15462ba95") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990608
setManifestid(1990608, "2596987413987385390", 133856)
addappid(1990609, 1, "3c86bb41ebb7c78851b171bf967ddb86c9d3ab45f78c5fc14af35b83d8cc11fb") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990609
setManifestid(1990609, "4215573397585232259", 153959)
addappid(2393691, 1, "fca8a5a62f00f8c72656c7bef0c2f15a9d2fc32d4fd0d646768a1bba8051b7f0") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393691
setManifestid(2393691, "4173578490065551405", 142555)
addappid(2393693, 1, "36e44947f2a12bee0e001f17309d3d42f5176b8f5be0c21df8fb6bf0a5ebb90b") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393693
setManifestid(2393693, "3731534992681646716", 130965)
addappid(2393696, 1, "27dad64ea1785c1030b646c963a819ad247d722768899bb893dec9b35eb02c03") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393696
setManifestid(2393696, "6923902689551610468", 127962)
addappid(2393697, 1, "cd0ca8a240f0a846690436edf72134b9174eb271c344af8f982162560f26d43f") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393697
setManifestid(2393697, "496562970580916885", 149963)
addappid(2393698, 1, "032719a1bff90b52944a72ce3625e5e96b50c0359e7b77f019c7d97e02ff5713") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393698
setManifestid(2393698, "8285010579656617921", 133661)
-- addappid(1990605, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990605 (no key available)
-- addappid(2393690, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393690 (no key available)
-- addappid(2393692, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393692 (no key available)
-- addappid(2393694, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393694 (no key available)
-- addappid(2393695, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393695 (no key available)
-- The Sims 4 For Rent Expansion Pack (AppID: 2140610)
addappid(2140610)
addappid(2140610, 1, "673d782684a8135dbe163ae91fd4e4640e003e7b00ad116138f363a327ab26a2") -- The Sims 4 For Rent Expansion Pack - Depot 2140610
setManifestid(2140610, "1041847880107497897", 1568219275)
addappid(2140611, 1, "15d488f644f90e269447758744d69c2152ac57c70dc841587ae5060b97c6ae08") -- The Sims 4 For Rent Expansion Pack - Depot 2140611
setManifestid(2140611, "5313617031004891573", 154722)
addappid(2140612, 1, "079d3442ab7a5387cc258dd12b48ccd369e337d727af80769a409292ea97e6b1") -- The Sims 4 For Rent Expansion Pack - Depot 2140612
setManifestid(2140612, "901505141424385880", 172568)
addappid(2140613, 1, "dfc0beaaafe0327b74aeaaba3c105f2647f404192b22caa8158ce6ebb341def3") -- The Sims 4 For Rent Expansion Pack - Depot 2140613
setManifestid(2140613, "8476089036188018329", 174010)
addappid(2140614, 1, "fed89307ccc4b71f3298af079a7cac5d40859b730c38008585316ff7d0e76f3e") -- The Sims 4 For Rent Expansion Pack - Depot 2140614
setManifestid(2140614, "2636242706999506543", 168123)
addappid(2140615, 1, "9de626fdf04354908a5c50542599ac1e24935b8365a0690e39310600b3618e93") -- The Sims 4 For Rent Expansion Pack - Depot 2140615
setManifestid(2140615, "6678472022547230474", 168919)
addappid(2140616, 1, "518993a2b489deea0c25922c7163f4025f7f1e6a9034fb0877619f869e31149a") -- The Sims 4 For Rent Expansion Pack - Depot 2140616
setManifestid(2140616, "874011716013809413", 172989)
addappid(2140617, 1, "ebf5c98670c44cdf0384ba63af879ebfe5d7920d8547cdc71cacfd5cb3bbef9e") -- The Sims 4 For Rent Expansion Pack - Depot 2140617
setManifestid(2140617, "3182743348157895209", 155794)
addappid(2140618, 1, "8020ccf231bb389f28d7c4ab2c38e4cf34c56ab984abd8b97fe14e540f8a0ed6") -- The Sims 4 For Rent Expansion Pack - Depot 2140618
setManifestid(2140618, "6096842503828788476", 155562)
addappid(2523851, 1, "9a60c7f733c6a690b06c3ee9aea14f10d46a46cf9594907c290d31e6298822a3") -- The Sims 4 For Rent Expansion Pack - Depot 2523851
setManifestid(2523851, "9221432072426732248", 173490)
addappid(2523857, 1, "df87c224bd0523aec172d12f21d56f051eab2fc3a570467badf2d853d0128327") -- The Sims 4 For Rent Expansion Pack - Depot 2523857
setManifestid(2523857, "1661360007622938149", 182225)
addappid(2523858, 1, "1754770a2c793e1732fe303b098a94a7a70db2cf100b7a63a2197359a0fea5ac") -- The Sims 4 For Rent Expansion Pack - Depot 2523858
setManifestid(2523858, "256321667817604869", 161124)
-- addappid(2140619, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2140619 (no key available)
-- addappid(2523850, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523850 (no key available)
-- addappid(2523852, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523852 (no key available)
-- addappid(2523853, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523853 (no key available)
-- addappid(2523854, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523854 (no key available)
-- addappid(2523855, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523855 (no key available)
-- addappid(2523856, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523856 (no key available)
-- The Sims 4 Home Chef Hustle Stuff Pack (AppID: 2304400)
addappid(2304400)
addappid(2304400, 1, "7da8766d3138210a0874a4d396388318316db594e9578995506ecdeabb8d670d") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304400
setManifestid(2304400, "2235609315470202227", 266180056)
addappid(2304401, 1, "8e7cb9b178868487cd33f1e0a6b168bf99d0df6474cccf48368d8eaca36888a5") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304401
setManifestid(2304401, "2682914858600745814", 17670)
addappid(2304402, 1, "0eb71635155df32ea5bdc5eb2aa9feda2ce26fa2853378cb7ee1eda53ce77f2c") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304402
setManifestid(2304402, "7801375157190011819", 19547)
addappid(2304403, 1, "d2ba4cdc49398fe3effb4662e58130791573df6367a3544722514d716b4501d6") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304403
setManifestid(2304403, "3508381459638652706", 19708)
addappid(2304406, 1, "992ff91eee06b31677bb50b8d0ee8833918c3ecb4a9cf863426f37a191bc3b66") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304406
setManifestid(2304406, "1126687653762001954", 19470)
addappid(2304407, 1, "bf404f6bd8a2e7303b940045879668cbd9bc56384a8288f8341a4adf8d17aee9") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304407
setManifestid(2304407, "1512442614642442853", 17953)
addappid(2304408, 1, "753e7677f605d872223fa85ee8dcabb791d648c39593be72fbb441c1cb356fb2") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304408
setManifestid(2304408, "5448450280138220557", 18170)
addappid(2304409, 1, "430b767df09786b7421c25e889c78a36cfd5148991ad3d395472843c42dc580a") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304409
setManifestid(2304409, "4409625400427348608", 21572)
addappid(2523831, 1, "5eb3cdd899c2077f32af89c86e65f560f671640e4a79d7f249d0a943cce7733c") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523831
setManifestid(2523831, "3226069231923272471", 19795)
addappid(2523833, 1, "1ba6f2330071330b2feb8647821cfdeb92ca7cf5f2eae7544781a045978f8c8d") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523833
setManifestid(2523833, "6203036226921829228", 18556)
addappid(2523837, 1, "0137a2a21a9df5c9c6de4dae19933224410a45bf751a85ce8ae66d14ce5a151a") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523837
setManifestid(2523837, "2077681202829184619", 21155)
addappid(2523838, 1, "5e76e89e6dc148d8e3578fc0a14450b2a81f631adfca8eec8085e9dd99093649") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523838
setManifestid(2523838, "271891994014260952", 18889)
-- addappid(2304404, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304404 (no key available)
-- addappid(2304405, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304405 (no key available)
-- addappid(2523830, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523830 (no key available)
-- addappid(2523832, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523832 (no key available)
-- addappid(2523834, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523834 (no key available)
-- addappid(2523835, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523835 (no key available)
-- addappid(2523836, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523836 (no key available)
-- The Sims 4 Crystal Creations Stuff Pack (AppID: 2727400)
addappid(2727400)
addappid(2727400, 1, "401d8579601f6ea05bff0a77254bfbfc9174c67887926451025926cd3da3cfd6") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727400
setManifestid(2727400, "3731443671446317303", 303817982)
addappid(2727401, 1, "12851d9b7f95a41fe20ef3b71a3385a34ff1d248715b389707e18a1b73b5db14") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727401
setManifestid(2727401, "1153452561986139279", 24582)
addappid(2727402, 1, "ac552fbe641c51e6e5ec7e6367c9cbf484e0012f90ae2845026a0df9702cd78a") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727402
setManifestid(2727402, "1394529955950433035", 26997)
addappid(2727403, 1, "27cc61c5a2e077c815b802967ede8f19e6365d2d323136b0398555438634700b") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727403
setManifestid(2727403, "574943741483060839", 26859)
addappid(2727404, 1, "1dd302b15d7693f33734c40345047c50bbaf27d28384bbacc21147825245da4a") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727404
setManifestid(2727404, "1002034060659402399", 26097)
addappid(2727406, 1, "9786dfc701d651548749b96461dffd77d597cf5036ae5fd61d202df7a2013525") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727406
setManifestid(2727406, "1477726302091202385", 26439)
addappid(2727407, 1, "519d2893237ef17c305ea74cbe153c6e198a76c1739bb46a5f09423f9e2fbbd1") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727407
setManifestid(2727407, "84921073300645882", 24841)
addappid(2727408, 1, "c7bd005f955e6bcf83fca2327405e64cb04ce0b688178cdbb08c823bac121713") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727408
setManifestid(2727408, "6398090338454063830", 24694)
addappid(2827091, 1, "1c3cfca693910cbff90f36e88dfbeaaa6c4579c9c6d1dbe9b7701877e0316cd9") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827091
setManifestid(2827091, "5830706761320590573", 27796)
addappid(2827097, 1, "2807f2010af3933fd92ca88c68e315e59d36e1c745548b44df84353ab269a7e1") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827097
setManifestid(2827097, "4429715735143882890", 28816)
addappid(2827098, 1, "6e4b7d22384bccef70b38a3f390ccc88843ceee9ed35dfb6bad94461fa69365e") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827098
setManifestid(2827098, "3639179858454523963", 25442)
-- addappid(2727405, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727405 (no key available)
-- addappid(2727409, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727409 (no key available)
-- addappid(2827090, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827090 (no key available)
-- addappid(2827092, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827092 (no key available)
-- addappid(2827093, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827093 (no key available)
-- addappid(2827094, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827094 (no key available)
-- addappid(2827095, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827095 (no key available)
-- addappid(2827096, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827096 (no key available)
-- The Sims 4 Lovestruck Expansion Pack (AppID: 2815270)
addappid(2815270)
addappid(2815270, 1, "dec415124770e020244e3b0d8c81e39002d8a96c6ef018f34c3ad426084f1182") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815270
setManifestid(2815270, "6008965598713971091", 1753477164)
addappid(2815271, 1, "4b91e10c583f71bff4658237d0f4cc4db71f7b508105606b80d506433b29c868") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815271
setManifestid(2815271, "891909382085674867", 126771)
addappid(2815272, 1, "6d8a9a02e859f552ae64ca77d71ce12ef0f90aa616b7a65821c32305d6bae831") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815272
setManifestid(2815272, "4532678096748774521", 142703)
addappid(2815273, 1, "8366a31c97ffc3c860d289e0477ca399d2419f816b4d1abc42b9f9aee5ed86a9") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815273
setManifestid(2815273, "5024284857066184432", 143065)
addappid(2815276, 1, "099c760b178f75baa606d02a6c884616b410a3509e69db5f80f6e3c8d8ec35e6") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815276
setManifestid(2815276, "8559974542342371794", 138868)
addappid(2815277, 1, "771fbf7bfc3ac64615b2e6947328c98576e7e6fa24f1c6eeafc52a37bd08464a") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815277
setManifestid(2815277, "550839643414462382", 128923)
addappid(2815278, 1, "8ce6c4b314f27ef0f868eae13e3e75abd89a45cd77d4dd161d45488820a3352f") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815278
setManifestid(2815278, "735009510679509762", 128767)
addappid(2880021, 1, "b09d66499400aa55d56fcc3e80857f8a78b85720fc07b3677292374bea869dd6") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880021
setManifestid(2880021, "7695708945496380109", 145336)
addappid(2880027, 1, "94851775e32f8bca00667e5df4bdc925bf8ef3895e028d06f766bf51c508d736") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880027
setManifestid(2880027, "3279893493367834723", 151240)
addappid(2880028, 1, "fba6e2a82de8d2fe668adb17cbb863ba4c32e23793f0154ab4e1f6e24987171c") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880028
setManifestid(2880028, "3861829940338449305", 133482)
-- addappid(2815274, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815274 (no key available)
-- addappid(2815275, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815275 (no key available)
-- addappid(2815279, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815279 (no key available)
-- addappid(2880020, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880020 (no key available)
-- addappid(2880022, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880022 (no key available)
-- addappid(2880023, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880023 (no key available)
-- addappid(2880024, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880024 (no key available)
-- addappid(2880025, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880025 (no key available)
-- addappid(2880026, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880026 (no key available)
-- The Sims 4 Life  Death Expansion Pack (AppID: 2815290)
addappid(2815290)
addappid(2815290, 1, "2f4a48527c683662434a82e983a940f0ec5b86fca4fc693745ac8a03b5d4b6cb") -- The Sims 4 Life  Death Expansion Pack - Depot 2815290
setManifestid(2815290, "5150710437008728859", 2154367192)
addappid(2815291, 1, "cc1bb9046ec0c6620ed042a9bca4f123e1d4112739ef63f0078f2873d3cd56fd") -- The Sims 4 Life  Death Expansion Pack - Depot 2815291
setManifestid(2815291, "5181453809415824313", 275965)
addappid(2815292, 1, "2e1e66a55d08a9f90c8e3868341a9de4871db8d32c552eca63e7f687c1fed08d") -- The Sims 4 Life  Death Expansion Pack - Depot 2815292
setManifestid(2815292, "4730884333799120941", 307657)
addappid(2815293, 1, "4ecb48afeab9ae3deb9b928ee4ead5f641ba8a0059a5d160a5137e275c7c3056") -- The Sims 4 Life  Death Expansion Pack - Depot 2815293
setManifestid(2815293, "6208223663597491972", 303960)
addappid(2815297, 1, "6c4ab2a78baac554d707f33bd46f3c5a86edd9da064e680dbbda6b492b3975a7") -- The Sims 4 Life  Death Expansion Pack - Depot 2815297
setManifestid(2815297, "7851327978629473813", 283245)
addappid(2815298, 1, "ea9022bed7a97dcaeee189af9fc55715f988d8bd39f8c558c8599f0d60abc2cb") -- The Sims 4 Life  Death Expansion Pack - Depot 2815298
setManifestid(2815298, "8974720547849717131", 293395)
addappid(2815299, 1, "6ea085db3d1d08c3e7de64dc93e120709afcfa09ec6b5feb1857330b3b02ad9e") -- The Sims 4 Life  Death Expansion Pack - Depot 2815299
setManifestid(2815299, "8439924901508740289", 327881)
addappid(3052081, 1, "52275152d81670eacdc07994269d4691e36fc3ca43b09fdf7995f8473d355bbf") -- The Sims 4 Life  Death Expansion Pack - Depot 3052081
setManifestid(3052081, "2593865843883638409", 303021)
addappid(3052088, 1, "a1199cab52304fe2e809472f9733f2b0f2b7d484e8be754b4ef252ac4970a4ab") -- The Sims 4 Life  Death Expansion Pack - Depot 3052088
setManifestid(3052088, "7701349043002761824", 281901)
-- addappid(2815294, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 2815294 (no key available)
-- addappid(2815295, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 2815295 (no key available)
-- addappid(2815296, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 2815296 (no key available)
-- addappid(3052082, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052082 (no key available)
-- addappid(3052083, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052083 (no key available)
-- addappid(3052084, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052084 (no key available)
-- addappid(3052085, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052085 (no key available)
-- addappid(3052086, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052086 (no key available)
-- addappid(3052087, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052087 (no key available)
-- addappid(3052080, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052080 (no key available)
-- The Sims 4 Businesses  Hobbies Expansion Pack (AppID: 2815310)
addappid(2815310)
addappid(2815310, 1, "151dc71ffb125ef837c26533c0b7ba710dcdb34937a0a63338437152c199edb2") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815310
setManifestid(2815310, "7888750986993921051", 1547446251)
addappid(2815311, 1, "2dfb4e345a5cdbe824f6d6ea756437fd3c47353c9e63a165e791815146f25312") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815311
setManifestid(2815311, "4028391890679824619", 138605)
addappid(2815312, 1, "1f2d916450cefe8b187628b393ce2d8a6d5eb8d52381410cf5924ef6bf21f5c5") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815312
setManifestid(2815312, "3986808613631928751", 155984)
addappid(2815313, 1, "445c5bcf19185ec9a25ae0a1030693cde89bf89354089b0a1a6f9c40e4d4f9a7") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815313
setManifestid(2815313, "5963435564108307234", 156503)
addappid(2815316, 1, "576dc62a86e6c7c8c663bf1afefde738ab6628218f78bbb6c2596ec036d58470") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815316
setManifestid(2815316, "6193327048330348084", 154486)
addappid(2815317, 1, "6e295b75631169bc22a46bb59afa497a85c8b4b8d5fbfb3322d839fd58105b8b") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815317
setManifestid(2815317, "3352313271908523742", 142942)
addappid(3171041, 1, "441e8578e4b3591820187622e0f5db6248c4eba2840a865db042c231392ac99d") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171041
setManifestid(3171041, "6775274089434341441", 158301)
addappid(3171047, 1, "9ff08187595cc6d786178223e04b8868c793d4a8256e70477c9e37ae3a7f6f3c") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171047
setManifestid(3171047, "438296953913949726", 165988)
addappid(3171048, 1, "d3f46aa4037b7640328c806d4b60d6b0ba4aef323f4c5929c8de0266845c995c") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171048
setManifestid(3171048, "2392993002272448559", 146037)
-- addappid(2815314, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815314 (no key available)
-- addappid(2815315, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815315 (no key available)
-- addappid(2815318, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815318 (no key available)
-- addappid(2815319, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815319 (no key available)
-- addappid(3171040, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171040 (no key available)
-- addappid(3171042, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171042 (no key available)
-- addappid(3171043, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171043 (no key available)
-- addappid(3171044, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171044 (no key available)
-- addappid(3171045, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171045 (no key available)
-- addappid(3171046, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171046 (no key available)
-- The Sims 4 Enchanted by Nature Expansion Pack (AppID: 3199780)
addappid(3199780)
addappid(3199780, 1, "19bb76b39fe66921f1d2f79df8e10c921f8e2076dd202f613a2d13dcffe89451") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199780
setManifestid(3199780, "3671820788923412402", 2119658348)
addappid(3199781, 1, "45f72b0457d34c219a7f20692bad14e6ccf06b54b56165f71b4f2d42a1cae46c") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199781
setManifestid(3199781, "3133205366042173076", 173751)
addappid(3199782, 1, "508159f88f6c002fe27f84aee2fbeafd440222cdbcdad17e01f56f3046d3e588") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199782
setManifestid(3199782, "7651685350000145867", 192612)
addappid(3199783, 1, "ea0dec3180a9961b7f81c6207a5fa337746dc6faead1558783bc0bd712a5d241") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199783
setManifestid(3199783, "7282913110554754882", 191244)
addappid(3199786, 1, "bc321d12ae3909a1c573f4e8bf5df633d89a1904952788601c593ed07bca6d6b") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199786
setManifestid(3199786, "5309195146055068595", 189745)
addappid(3199787, 1, "d1b61de94204bd0a3351d13427e7c3f4e17384edb0b4fd75f52ccd770fa25f22") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199787
setManifestid(3199787, "6525526003422378720", 179138)
addappid(3199788, 1, "ff20035c040e3f4ce85e6ddb84d84610e0beb2ba4df10bd3435b45e7a0e2e033") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199788
setManifestid(3199788, "174939551437329683", 183046)
addappid(3500101, 1, "c55723203c0b709c8771f460a52f744ec6066a8f03c4882a7bc70f4427489f16") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500101
setManifestid(3500101, "8154102722572635826", 195954)
addappid(3500103, 1, "9f72f1226b7e95e1010d0b997ff9d178bf047590f3df4ccaf91cf74fbe19a9e8") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500103
setManifestid(3500103, "6502319728284853132", 179051)
addappid(3500108, 1, "c4040b9824cd0e42025a75a0df4fa5405ce94ad44b37d22acba02d69e3585e8c") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500108
setManifestid(3500108, "7126415536108906366", 181860)
-- addappid(3199784, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199784 (no key available)
-- addappid(3199785, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199785 (no key available)
-- addappid(3199789, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199789 (no key available)
-- addappid(3500100, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500100 (no key available)
-- addappid(3500102, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500102 (no key available)
-- addappid(3500104, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500104 (no key available)
-- addappid(3500105, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500105 (no key available)
-- addappid(3500106, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500106 (no key available)
-- addappid(3500107, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500107 (no key available)
-- The Sims 4 Royalty  Legacy Expansion Pack (AppID: 3548690)
addappid(3548690)
addappid(3548690, 1, "02843214db8730444f1ae4955b69fe64f97e09234a83588ce7e04b2a53857867") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548690
setManifestid(3548690, "6209288974954895178", 2604547046)
addappid(3548691, 1, "43c48c9860dc8f54b9317a012f95cb9decee64c8159bf32b101a1c277053a256") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548691
setManifestid(3548691, "3947756536033026081", 194558)
addappid(3548693, 1, "ee66f19436bfbe0034a93c1d6b645530f4553af4e9684bf8e590890fd41a51f3") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548693
setManifestid(3548693, "4214656471298771173", 219006)
addappid(3548697, 1, "88d5357ea4a4bb6e49b1d4c78edf11dd863b6168c7063223b181f84d252f04c4") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548697
setManifestid(3548697, "2273867050512558123", 204269)
addappid(3548698, 1, "2856257bcb489ef0309770b0b48292ed8dabdb50eb41dce54e7bb2a34ba7fc6f") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548698
setManifestid(3548698, "7324280256055934728", 206313)
addappid(3719731, 1, "0f044f104df15ec6e08a270e8f3578bbb3dbaa32b3c88d0621e15f91ac3ddbe2") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719731
setManifestid(3719731, "5513662698944195673", 216348)
addappid(3719738, 1, "37651427f0b03b9fe893e7dde8cefdc3af90663bd14e3334299b4dbf9108efec") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719738
setManifestid(3719738, "8563309438858815122", 205343)
-- addappid(3548692, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548692 (no key available)
-- addappid(3548694, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548694 (no key available)
-- addappid(3548695, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548695 (no key available)
-- addappid(3548696, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548696 (no key available)
-- addappid(3548699, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548699 (no key available)
-- addappid(3719730, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719730 (no key available)
-- addappid(3719732, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719732 (no key available)
-- addappid(3719733, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719733 (no key available)
-- addappid(3719734, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719734 (no key available)
-- addappid(3719735, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719735 (no key available)
-- addappid(3719736, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719736 (no key available)
-- addappid(3719737, 1, "MISSING_KEY") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719737 (no key available)
-- The Sims 4 Adventure Awaits Expansion Pack (AppID: 3548850)
addappid(3548850)
addappid(3548850, 1, "5df5284298b6d3c1065cd3f76e47d7187f60eaabe6a5e3685715a0464c50324c") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548850
setManifestid(3548850, "5632534031643581949", 1594438790)
addappid(3548851, 1, "3d481afb9278d25d525b5b8f8fce3b7d8db2a354bb5dfd2787d925fb2748014a") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548851
setManifestid(3548851, "564971608454374143", 221199)
addappid(3548853, 1, "a17b4ab19c7947499c793714efff263663d19979c98f5c5ab5aac7a1709eda0d") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548853
setManifestid(3548853, "4486041486373604010", 246393)
addappid(3548857, 1, "cad39c5dededd065fa1b789a1aad0e2177e8d93165891c47de3c1a11fc0739f6") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548857
setManifestid(3548857, "4907847714046530908", 232302)
addappid(3548858, 1, "dcd809f19c9294b85593cabb3dc2c4d0d84662a796348ca8a805f35592f5aaeb") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548858
setManifestid(3548858, "4305526659896586707", 230078)
addappid(3719711, 1, "3a9798f6336b3a8fec444c82789002cc886d10d2921932103ae26a90a41a24fc") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719711
setManifestid(3719711, "3496857629388382097", 246596)
addappid(3719712, 1, "88392d869eb78bdf65d2543007ad2680a111e5207940302c575dfee0f6ce8282") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719712
setManifestid(3719712, "8795225943322852127", 224070)
addappid(3719718, 1, "0e2d9e3a30f27ff5df5164a6fecb9f47a59c94ad9cc9e0f3fb67200747b25368") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719718
setManifestid(3719718, "973249352064571620", 235719)
-- addappid(3548852, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548852 (no key available)
-- addappid(3548854, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548854 (no key available)
-- addappid(3548855, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548855 (no key available)
-- addappid(3548856, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548856 (no key available)
-- addappid(3548859, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548859 (no key available)
-- addappid(3719710, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719710 (no key available)
-- addappid(3719713, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719713 (no key available)
-- addappid(3719714, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719714 (no key available)
-- addappid(3719715, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719715 (no key available)
-- addappid(3719716, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719716 (no key available)
-- addappid(3719717, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719717 (no key available)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1235765) -- The Sims 4 Digital Deluxe Upgrade