addappid(2060280)
addappid(2060280,0,"8f210ec51cad794270eddc55022b23a70e688e715909c17bf7778d3fe8ccef71")


-- Auto added manifests
setManifestid(2060280,"4231231069023266225",1)
