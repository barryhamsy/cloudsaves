-- MAIN APPLICATION
addappid(3061810) -- Like a Dragon: Pirate Yakuza in Hawaii
-- MAIN APP DEPOTS
addappid(3061811, 1, "7a902c59f558f53204bf21403faa08aa113c0eca94bc03ad642f533ed35fc10a") -- Depot 3061811
setManifestid(3061811, "5791590246311215097", 59249797889)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3183940) -- Like a Dragon Pirate Yakuza in Hawaii - Ichiban Pirate Crew Set
addappid(3184000) -- Like a Dragon Pirate Yakuza in Hawaii - Ichiban Special Outfit Set
addappid(3184010) -- Like a Dragon Pirate Yakuza in Hawaii - Legendary Outfit Pack
addappid(3184020) -- Like a Dragon Pirate Yakuza in Hawaii - Extra Karaoke  CD Pack 
addappid(3184030) -- Like a Dragon Pirate Yakuza in Hawaii - Ship Customization Pack
addappid(3184040) -- Like a Dragon Pirate Yakuza in Hawaii - Legendary Pirate Crew Pack
addappid(3184050) -- Like a Dragon Pirate Yakuza in Hawaii - Kazuma Kiryu Special Outfit 