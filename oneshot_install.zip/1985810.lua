addappid(1985810) -- Call of Duty®: Black Ops Cold War
-- MAIN APP DEPOTS
addappid(1985811, 1, "74b923416f69424b2ccca7dcc697d336e0124d6784c9c07c17cddbf542837fc6") -- Depot 1985811
setManifestid(1985811, "5380296931597271327", 47974545231)
addappid(1985812, 1, "6eaa50aa32d813b61a3f640fd00f405336413e220506680c0fa3e61554d6795c") -- Depot 1985812
setManifestid(1985812, "3779238472083795815", 377498576)
addappid(2103784, 1, "0f077d673ee5c45f5b301cf52bcb5d69ecc63d16a692c118898b80e902449473") -- Depot 2103784
setManifestid(2103784, "7767260795764336147", 5736411)
addappid(2103767, 1, "d28c8e8b312b474758f3a732833f3c846298e2fdceb0d3d2f58c44134d521e53") -- Depot 2103767
setManifestid(2103767, "275200630370061621", 1458613513)
addappid(1985813, 1, "4fdc12da821a93bcf15f2547eb6822a5df7f672631695b91f08c26a98db083a9") -- Depot 1985813
setManifestid(1985813, "4429578122495442675", 2967551787)
addappid(2101904, 1, "ad2dd4cc71aa6ecbdaf18b39fa6ad045e6b6cec24621ec1b349871f052a75884") -- Depot 2101904
setManifestid(2101904, "5708757843122859507", 1524580795)
addappid(2103757, 1, "49b4fcad6d601798ed56999adfff031964b262f480fc55a76265d424364d873e") -- Depot 2103757
setManifestid(2103757, "1914474307680885882", 1549248938)
addappid(2103752, 1, "3ebc4f3f45f373ed8cadc488597f60fd432bfd1354ba85edf8a9ffbfd87aae08") -- Depot 2103752
setManifestid(2103752, "7392928280789375200", 1740091226)
addappid(2103747, 1, "4657a15ea8ed3f0a5dd9d7efc15dc3fd224284bb60fa5066a63443b547472317") -- Depot 2103747
setManifestid(2103747, "4480795951100760401", 1715202190)
addappid(2103742, 1, "01e1cbe815c4417d6150473c6e99630cdecbf537f4f792e76848954495c3e67c") -- Depot 2103742
setManifestid(2103742, "368513867459556084", 3175501618)
addappid(2103737, 1, "b484a2a8475ef935d14a6a60f7569c867628bfca507fddb258222e69381b4e90") -- Depot 2103737
setManifestid(2103737, "3607728913547296249", 3060362934)
addappid(2101927, 1, "87a1b64168774d0a396b03b12d8df54a4de73dbd877a081aeb8797da0363c338") -- Depot 2101927
setManifestid(2101927, "6853116117611746287", 3190529630)
addappid(1985818, 1, "d55adb014520b9d32f5c13abd57878a4cd9fb80b7d7a28dcb00ffd18a8fce003") -- Depot 1985818
setManifestid(1985818, "5847550128753994729", 1649073321)
addappid(2101909, 1, "46f865e5ebce844db9c738e3d346c385f84c5add8a90f53e37feff47f9a4c1bd") -- Depot 2101909
setManifestid(2101909, "7096856376192225772", 3218980448)
addappid(2103732, 1, "177292e5774b5428837e1845b378e171658137bf2a55c6977dcb7f96a87dfed0") -- Depot 2103732
setManifestid(2103732, "7516163718209429022", 1693382475)
addappid(2103762, 1, "12bc4d659160d22046469092d60fbc25fcb7022c19cc91fc8c0025d37d61f036") -- Depot 2103762
setManifestid(2103762, "6562319711057307537", 1728963538)
addappid(2103778, 1, "a705a6be88c1f552f682f5c0490d4b5ccd2f5bf2138b5fa500d8a9ef8eef5f2c") -- Depot 2103778
setManifestid(2103778, "7915557273737168687", 5910500)
addappid(2103779, 1, "e0990c3a19aa2ea5e6beefdf1481113805ad6c991037230a871660f62b7b7027") -- Depot 2103779
setManifestid(2103779, "723535141708346670", 5746817)
-- DLCS WITH DEDICATED DEPOTS
-- Call of Duty Black Ops Cold War - Campaign (AppID: 2101900)
addappid(2101900)
addappid(2103768, 1, "93daab6a9ebee0326a6652a580f682fda0316fe59c420efb5ab2363a267463e4") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103768
setManifestid(2103768, "48332887897998080", 226584035)
addappid(1985814, 1, "16c2c616b17dcb3a384f86531e3a3570a9fde5209b110f10875fe4775b3dc6e5") -- Call of Duty Black Ops Cold War - Campaign - Depot 1985814
setManifestid(1985814, "2527290578097296989", 450006004)
addappid(2101905, 1, "e8102ef142fe733e81826e278ee8ceb06e11e3ffd579770ece5718fcb5b10165") -- Call of Duty Black Ops Cold War - Campaign - Depot 2101905
setManifestid(2101905, "2841522058742231408", 241503047)
addappid(2103758, 1, "d50a18150c8d2f56c5b2d0ddd9b4937fa1deb8443540bd1bed3c59fedd68567a") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103758
setManifestid(2103758, "8483484438103395550", 219717417)
addappid(2103753, 1, "8dacad964a16a309736d254b9cef393a65181b088d5cbacec03b10b69c3b0aef") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103753
setManifestid(2103753, "6991120379391622539", 236524344)
addappid(2103748, 1, "aa243fee1f87f8d58d458234fd1ea688441893f3989d41b08451630f33251628") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103748
setManifestid(2103748, "8791877509575617201", 233979091)
addappid(2103743, 1, "37a7135b601e327963a958527e406fba849419c6e260cf1b8eb2aafebda8f642") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103743
setManifestid(2103743, "5653518866134855156", 458136985)
addappid(2103738, 1, "1c7dbc882d5199be5e144141acb9cf0518f695a3f7823ed27b48ca8a99398c0b") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103738
setManifestid(2103738, "330339129725932698", 483495051)
addappid(2101928, 1, "29c1bd473dc9c30a72d2e4e2de87ccd3ac459682c5c7cf57a93d297ddc84a003") -- Call of Duty Black Ops Cold War - Campaign - Depot 2101928
setManifestid(2101928, "8149073949349435582", 479368393)
addappid(1985819, 1, "25401b1316bdf835da8ef30c6baf5418791a20bea0cd36660a89328c01b69838") -- Call of Duty Black Ops Cold War - Campaign - Depot 1985819
setManifestid(1985819, "6815600489992821223", 223866466)
addappid(2101923, 1, "39828fa54d752c27f33921bacd06a48b6036beb3ac5297cd7fc4331c9edb604f") -- Call of Duty Black Ops Cold War - Campaign - Depot 2101923
setManifestid(2101923, "1646230148803553464", 465639648)
addappid(2103733, 1, "b6f4c5ddb6e6504bb25ad0d60b9979d36308e064980bb0f5c419af22cfc30cec") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103733
setManifestid(2103733, "2805076145045790773", 232366702)
addappid(2103763, 1, "ab9dfce4cf03177b13f41a9ffd9b6142201ae5ec17032fe7d577be8f919fe5e0") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103763
setManifestid(2103763, "5067928519147659533", 239359167)
addappid(2101900, 1, "8903afa6bccf8f4e2fd03a3a1a6339b497b6c05dd0f6642dc2b120cbed8dba52") -- Call of Duty Black Ops Cold War - Campaign - Depot 2101900
setManifestid(2101900, "9011827173531613176", 38497787950)
addappid(2103781, 1, "3b33966e408bc358549ad9dad65a4f80f46005d93cbd7580d5795794155ac288") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103781
setManifestid(2103781, "8626868342882602343", 5121439)
addappid(2103780, 1, "588855eade9bfab88c95661ba53b07d47a5fb6cf120ae02ec5bbc7d108784af8") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103780
setManifestid(2103780, "1411358328354941611", 5086988)
addappid(2103793, 1, "8793d897122e9a1edf121d7bc94f63f2356629c5151940ba72fb62233abcb967") -- Call of Duty Black Ops Cold War - Campaign - Depot 2103793
setManifestid(2103793, "3166936726869601702", 5085492)
-- Call of Duty Black Ops Cold War - Multiplayer (AppID: 2101920)
addappid(2101920)
addappid(2103769, 1, "f3ee7a08fea0ee6004050f1372dd98969767b4f6c7e48c23a0060aae29664d18") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103769
setManifestid(2103769, "757901174009189358", 21434037)
addappid(1985815, 1, "3b44fe5543e9ec35a99ce7930ad7c9435ffc59317978561d4b63599a0cc5267f") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 1985815
setManifestid(1985815, "7126153152639502361", 42693399)
addappid(2101906, 1, "23dfc019269f045fbfb76153e273a467161e628047d4b552cfc16c5bb70c4cf5") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2101906
setManifestid(2101906, "3124101575807229994", 22430909)
addappid(2103759, 1, "2dbda68778762c7afa37b9ec540c1fac8f789fcdfc863fbe909c4ecf67a5ac72") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103759
setManifestid(2103759, "6807841575164917096", 21225749)
addappid(2103754, 1, "65a80fcae1f5941b371d1cfdae9aaa17872ca8aac71908fb9b6c88e30ebf9887") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103754
setManifestid(2103754, "7934823921029356216", 22692463)
addappid(2103749, 1, "3a99767a9670714f855a1999d739e50c70b649888b0669a9fcd2cb849ac195f6") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103749
setManifestid(2103749, "2942433547896636314", 22626040)
addappid(2103744, 1, "3c16f67284a916d1ad7ce6bc173365287e3e075dcf4604947f04e73577067eff") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103744
setManifestid(2103744, "3815952609584048209", 45265839)
addappid(2103739, 1, "54297e8f3ae7c2fc12871b312af4992fd0cdfd8abdaf9984c00167090e072207") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103739
setManifestid(2103739, "7135495935999333452", 49817054)
addappid(2101929, 1, "6fc7e9e94141053bfaa179c1c26a4c701ce3a40ac4da1179948c3beef02a23d0") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2101929
setManifestid(2101929, "6632925521836911835", 45199249)
addappid(2101901, 1, "2b68754582ad8ac4a96e895d1980c40234dd72830006754ea8bb73384ad3fc9b") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2101901
setManifestid(2101901, "2579600936252378002", 23058465)
addappid(2101924, 1, "4397f717ee71314af02e6eb52cd81352d47d1cba08fe74a45a9ce73b8d8226f5") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2101924
setManifestid(2101924, "9010048758201965556", 44133157)
addappid(2103734, 1, "e9c4dd2c2ae423d80e6de34fd886b5c8fd9300141f2427c46453b64622f9eef1") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103734
setManifestid(2103734, "847722626218263397", 22236972)
addappid(2103764, 1, "d73fccb4a0486f8c7c10829e11ececd08eaaa609cfb08fa6716f0fe845c21eb0") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103764
setManifestid(2103764, "7638173781807168092", 22270714)
addappid(2101920, 1, "d0a9b42cb5f46d76ee0b5c6a9c1076c27c6981583f5444cc91f47ab246842535") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2101920
setManifestid(2101920, "1462581963452032230", 38119496702)
addappid(2103783, 1, "3b4560c2605efd27876506d45c469f69f54a41cb01ee559297056084eb7bf135") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103783
setManifestid(2103783, "5015109674005643496", 5657613)
addappid(2103782, 1, "ad55d39b04152bec49478b9534d972269122113f34c98fab3d7a57b9ac694b77") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103782
setManifestid(2103782, "6253535136358488658", 5675559)
addappid(2103794, 1, "16f8a880f912b8832a6bcad00295314057bc00b42d2e31595556fbae760a29bd") -- Call of Duty Black Ops Cold War - Multiplayer - Depot 2103794
setManifestid(2103794, "1443346426184682748", 5157005)
-- Call of Duty Black Ops Cold War - Zombies (AppID: 2101921)
addappid(2101921)
addappid(2103770, 1, "d0e3571175ad6c9fba011268da0ec78996e8d4e11fb0fc1f183993f749cbdc0e") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103770
setManifestid(2103770, "8430448478726302116", 200417974)
addappid(1985816, 1, "2c668e1d4a3fe35c449d0e0f2dc232d850ccfa67fb001bf93d002e98e31c126c") -- Call of Duty Black Ops Cold War - Zombies - Depot 1985816
setManifestid(1985816, "1013186448328809182", 399754857)
addappid(2101907, 1, "62765536ec0ac6842496e92fa4cd06ae87e85109487ef687ac8a4860407bba19") -- Call of Duty Black Ops Cold War - Zombies - Depot 2101907
setManifestid(2101907, "5979212930890385171", 214234324)
addappid(2103760, 1, "b74c1a1d24fa3448358be3244ccf57a11b315daf36ac6d08fabe46584b5b0670") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103760
setManifestid(2103760, "3997825600348625381", 202280015)
addappid(2103755, 1, "48e6d25439c3be9cf9daba728435642c54d67cd506cd22b3420160ce12396c2d") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103755
setManifestid(2103755, "5701614236414733650", 209207672)
addappid(2103750, 1, "d5f8bbefb5170a12fe6107a221b2f48e2a0cfeb5844cf0b161fd415a51fb6a80") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103750
setManifestid(2103750, "445854564952395617", 212238263)
addappid(2103745, 1, "82d01d1174eddf38fa01085782a6246c2b51486c44e93326edd5840dafd41f14") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103745
setManifestid(2103745, "5523092596509819572", 419512268)
addappid(2103740, 1, "9ad944d4943fd622f1e848e8edda25bb5740fefef8a6ee45dc25cc1834b3c2f6") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103740
setManifestid(2103740, "2312174966996360591", 438763280)
addappid(2103730, 1, "b67b37b24f9b451a7cc14e3a3b3e68e5e25644bae98d54981c81051326ef8c12") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103730
setManifestid(2103730, "3520317157568337940", 411066332)
addappid(2101902, 1, "4b397e56d1552822c03a23445465ffac569c7017fc39fde691bd9dda8dd9744d") -- Call of Duty Black Ops Cold War - Zombies - Depot 2101902
setManifestid(2101902, "8397557133983940504", 206434773)
addappid(2101925, 1, "c9199d46bee95432520d263eec0e4392e4b4c7bf64bb8de3a0a4f52ff5ad74e3") -- Call of Duty Black Ops Cold War - Zombies - Depot 2101925
setManifestid(2101925, "1996038931758819768", 414913881)
addappid(2103735, 1, "04c71d3f40cf3c57d95bd18a904158a8b4898d4280c7d6b0366ac79f1099817e") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103735
setManifestid(2103735, "2597932646983914017", 208292047)
addappid(2103765, 1, "80c77cdcd37f583d39bf6995f58afa6c27ced47d0a6ee4fe64bab6ab5ce3c589") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103765
setManifestid(2103765, "979231615733797167", 212447232)
addappid(2101921, 1, "6a32794f749ceb5ade6615d096fba1c91235d39cc448e994116c7dec70f8b5f3") -- Call of Duty Black Ops Cold War - Zombies - Depot 2101921
setManifestid(2101921, "937430578144837394", 12592250792)
addappid(2103786, 1, "e1a2287f154ee8bae8e6b0cb94ac534f92038cd7e22a8dc1e87f753f3bd88f63") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103786
setManifestid(2103786, "518369532288833196", 1947627)
addappid(2103785, 1, "7172416f08c1946c4eb9dc653586b08405ed2d783a6c3427ce2ebdd9b84db80d") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103785
setManifestid(2103785, "6227021759054786952", 1914588)
addappid(2103795, 1, "d9c4c1d5ea53543d93758399d86cceec9106c94dc35c7077d26112e11ef789e0") -- Call of Duty Black Ops Cold War - Zombies - Depot 2103795
setManifestid(2103795, "742297894199440346", 1915183)
-- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 (AppID: 2101922)
addappid(2101922)
addappid(2103771, 1, "767eaf9764f38c16d94cdef599d099f371b7b4e218b472363ff989e560e552d7") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103771
setManifestid(2103771, "1280072209284015880", 59363292)
addappid(1985817, 1, "9ce30947ddce198dd8285ebeb3acaa876a8a84bb41fbab3d7d45ca2bba4a6787") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 1985817
setManifestid(1985817, "7727499990995739389", 117977581)
addappid(2101908, 1, "855a4357c7d1b96e1aaeacb05611fa9c8097e542e575b62b6b19ffab762666cc") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2101908
setManifestid(2101908, "283635650293108102", 70787993)
addappid(2103761, 1, "316bc243610c1e03ae431f87c99386af5c857403bef30d9e11445eba469aa176") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103761
setManifestid(2103761, "8076854860235361265", 60527054)
addappid(2103756, 1, "07a21a584e5b0ebfee04d4673817650d1ed838ceca69561b42e8b4012da13a7c") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103756
setManifestid(2103756, "963111919229944091", 63401196)
addappid(2103751, 1, "2357bdff48fa46f16b29884edc996795d74e026b6072071618cdab43524d76b2") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103751
setManifestid(2103751, "8625773187638300818", 62793606)
addappid(2103746, 1, "481ded043db1286128813d19da5ee72d07678f45ae001a8bec6adcd9cf076074") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103746
setManifestid(2103746, "7711435895885641948", 129151653)
addappid(2103741, 1, "248657c54a11fa621ef0c0df5ec6fc090083aed24f06c6a37024416ad4df0a1a") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103741
setManifestid(2103741, "1410483983476407886", 148587491)
addappid(2103731, 1, "e27a1548d1dc91f752f6eaf7cdd9b27086bb7d437a4801692fe4554fdf05fd8c") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103731
setManifestid(2103731, "2573708959868354455", 123464411)
addappid(2101903, 1, "7d5dfab0f08c39b5abbaabaf0d307d7d20ec7e2868ef610b6611824e14a6b802") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2101903
setManifestid(2101903, "4909075144614876228", 62470772)
addappid(2101926, 1, "f6b1d90585d18fd0272e26349fb54516e01987f010a508faf5c586d3e8de5499") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2101926
setManifestid(2101926, "8530447272855763899", 124569597)
addappid(2103736, 1, "68c97af302af2bdeb678a660065e9c94336203cfe8117aa41aad3ac15b47ee3f") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103736
setManifestid(2103736, "7856508562217937386", 61262488)
addappid(2103766, 1, "3f3f517e7191d4c6c00974489d601759efeb98c582f5e5d033b404a2e5a645bb") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103766
setManifestid(2103766, "7240395855632265211", 63096973)
addappid(2101922, 1, "326c17da4b29bfde0f407ae7eda80e5848355ea8962ada02a792f73a3990e9ef") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2101922
setManifestid(2101922, "509839106016776119", 7693882252)
addappid(2103788, 1, "74eee895fa91ff347acead3e505344dd9a43223dd4785486aba04ff9d3b1a993") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103788
setManifestid(2103788, "7238009030785893142", 3006074)
addappid(2103787, 1, "7734a28d4016f70761a546b7c10fd8bcd482ab5684bd97f3cce50b2494a7db4a") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103787
setManifestid(2103787, "4850897305081198892", 2990833)
addappid(2103796, 1, "e56d86751f3171c5ce3086b056b6931cdcee65660e7d16d7dbddb744ff8036d8") -- Call of Duty Black Ops Cold War - Dead Ops Arcade 3 - Depot 2103796
setManifestid(2103796, "4079002366747453440", 2721667)
-- Call of Duty Black Ops Cold War - High-Resolution Assets (AppID: 2149500)
addappid(2149500)
addappid(2149500, 1, "d2ea7cd30ef578d81fcf24c5e9fb16203a640e1145f6e51bff42c5eef0d227a8") -- Call of Duty Black Ops Cold War - High-Resolution Assets - Depot 2149500
setManifestid(2149500, "5275158455324708780", 75051302912)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2289290) -- Call of Duty Endowment (C.O.D.E.) - Challenger Pack
addappid(2289291) -- Call of Duty Endowment (C.O.D.E.) - Battle Doc Pack
addappid(2289292) -- Call of Duty Black Ops Cold War - Starter Pack
addappid(2289293) -- Call of Duty Black Ops Cold War - Gilded Age III Pro Pack
addappid(2289294) -- Call of Duty Black Ops Cold War - Special Ops Pro Pack
addappid(2289295) -- Call of Duty Black Ops Cold War - Elite Pack
addappid(2289296) -- Call of Duty Black Ops Cold War - Chemical Reaction Pro Pack
addappid(2289297) -- Call of Duty Black Ops Cold War - Containment Breach Pro Pack
addappid(2289298) -- Call of Duty Black Ops Cold War - Ultimate Pack
addappid(2296260) -- Call of Duty Black Ops Cold War Points
addappid(2305230) -- Call of Duty Black Ops Cold War - Confrontation Weapons Pack