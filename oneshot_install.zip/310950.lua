addappid(310950, 1, "178da158b2405aea95ef234f5a620320ba332d35d9f68c38f1224d2d49dbf8c3") -- Street Fighter V
-- MAIN APP DEPOTS
addappid(310951, 1, "cde3f482aedb4b88421d61be7343f46674d5871746b189c56dc10b10ee3cada9") -- KIWI Content
setManifestid(310951, "4281346506506612445", 48872767681)
addappid(310952, 1, "4a147f5a5cbd4194a6eed1dd029b5a5e4fe2289bd588b3523eb881b099363254") -- Street Fighter V Depot - Dev
setManifestid(310952, "5579393335594350391", 4)
addappid(310953, 1, "18d1e71626cb0a8e17e55bb098bedea9b4737fc4cb7e52081175c7e03af05c1e") -- Street Fighter V Depot - QA
setManifestid(310953, "665527672323223830", 4)
addappid(444680, 1, "db42f16a2c7f575888338273f6a57333df09088a593c1f2ef1972d5e3bbe8052") -- Street Fighter V Original Soundtrack (444680) Depot
setManifestid(444680, "4334708473715125456", 378724129)
addappid(807290, 1, "736c56c0dc3b8d554a6301785f90ae2d9ddb41bd02062e39f28a2baedd80d96b") -- Street Fighter V: Arcade Edtion Original Soundtrack (MP3) (807290) Depot
setManifestid(807290, "5114511160089983206", 655149598)
addappid(1172540, 1, "654f536206ec0d43b2d537cca8c9c737ab400ab6978563f4045c0a1a73d3c226") -- DLC201911_02 (1172540) デポ
setManifestid(1172540, "1561420009549394100", 16548388)
addappid(1474240, 1, "02e28ddd341496a1e2d6911b524675379f2fd668b033e557317f82247463db73") -- DLC202101_02 (1474240) デポ
setManifestid(1474240, "7393267258824001410", 10241644)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Street Fighter V Original Soundtrack (AppID: 444680)
addappid(444680)
addappid(444681, 1, "53d2fa6baffbcdf37ade2be7c5ba940431452ff152201de96986463545b34b70") -- Street Fighter V Original Soundtrack - Street Fighter V Original Soundtrack [MP3 V0]
setManifestid(444681, "5594618389026688290", 359553273)
addappid(444682, 1, "67c495a3815315b9b134e5c240cf96ef2e88ec35ef4a9830271bb9182f4d8845") -- Street Fighter V Original Soundtrack - Street Fighter V Original Soundtrack [MP3 320]
setManifestid(444682, "752454272854440263", 413977479)
addappid(444683, 1, "953a8422938979d5c9e151d024b5f1ceb37a12fee19a5c8af225940a5dd46b8f") -- Street Fighter V Original Soundtrack - Street Fighter V Original Soundtrack [FLAC 16-bit]
setManifestid(444683, "7953050354784206310", 1228406064)
addappid(444684, 1, "75f3abed27cee21d3ecb70f4b002e71e6bcece488d6ae5451a7692c966793c0c") -- Street Fighter V Original Soundtrack - Street Fighter V Original Soundtrack [FLAC 24-bit]
setManifestid(444684, "3617451083888332535", 2025460944)
addappid(444685, 1, "e8d2f3ce912c319b5b2dd8c06335ae72788692ae087106f411c00f0d9346426c") -- Street Fighter V Original Soundtrack - Street Fighter V Original Soundtrack [AAC]
setManifestid(444685, "2250407312164593163", 456920518)
addappid(444686, 1, "96d7160b18f347c027601787bcb6fc4f0a5f0b284e03d3aadcbf652c4641e21b") -- Street Fighter V Original Soundtrack - ストリートファイターV オリジナル・サウンドトラック [MP3 V0]
setManifestid(444686, "8387965820318308298", 359553273)
addappid(444687, 1, "1033c64508d321bb55e9e50bfa8b20c53afdb1283f41e64973643faad89cdc91") -- Street Fighter V Original Soundtrack - ストリートファイターV オリジナル・サウンドトラック [MP3 320]
setManifestid(444687, "4564912732996950072", 413977479)
addappid(444688, 1, "b1d33aa476b5a306e5df3b1b7a5703903dfe8d5ed02f488067173094b2a594af") -- Street Fighter V Original Soundtrack - ストリートファイターV オリジナル・サウンドトラック [FLAC 16-bit]
setManifestid(444688, "2812062499536090500", 1228406064)
addappid(444689, 1, "fa791cab70376e31cfc4012dbc1743a06a2bc831e563f1a8bbc3292ac111d96c") -- Street Fighter V Original Soundtrack - ストリートファイターV オリジナル・サウンドトラック [FLAC 24-bit]
setManifestid(444689, "4797409791025313654", 2025460944)
-- addappid(1233930, 1, "MISSING_KEY") -- Street Fighter V Original Soundtrack - ストリートファイターV オリジナル・サウンドトラック [AAC] (no key available)
-- STREET FIGHTER V General Story A Shadow Falls (AppID: 475230)
addappid(475230)
addappid(475230, 1, "d508e856e2373e136a7f87a1756386fcae717c758409c450ed7c7fbf4efdee3e") -- STREET FIGHTER V General Story A Shadow Falls - SFV - Cinematic Story Mode (475230) Depot
setManifestid(475230, "2258455590697043247", 8951643221)
-- Street Fighter V Arcade Edition Original Soundtrack (AppID: 807290)
addappid(807290)
addappid(807291, 1, "84971ceff1c1c00316a40f52f8f2bafd72b86b0e1a2e729258131c350b6182b7") -- Street Fighter V Arcade Edition Original Soundtrack - Street Fighter V: Arcade Edition Original Soundtrack [MP3]
setManifestid(807291, "1665951421133843842", 655149598)
addappid(807292, 1, "2c50b2bc5f00df00004cb1a5824b74dc4c5d9cec2878a74e34263af99bba30fa") -- Street Fighter V Arcade Edition Original Soundtrack - Street Fighter V: Arcade Edition Original Soundtrack [FLAC]
setManifestid(807292, "7329595112567155509", 1822349186)
addappid(807293, 1, "3467d192ecc688317d05522eddc5f34515d4a00f27e0d0bdb0f6c90eefa432b3") -- Street Fighter V Arcade Edition Original Soundtrack - Street Fighter V: Arcade Edition Original Soundtrack [AAC]
setManifestid(807293, "5026022102596319014", 771965083)
addappid(807294, 1, "2e89eba1241e86675f3e4b3931d2685a57dd5c8ea5796b20679e9dc9029896aa") -- Street Fighter V Arcade Edition Original Soundtrack - ストリートファイターV アーケードエディション オリジナル・サウンドトラック [MP3]
setManifestid(807294, "9122201665469998545", 655149598)
addappid(807295, 1, "7beec9e96aa1c59f7645353799f26734fce33f4247871d376e76c165d7dd486a") -- Street Fighter V Arcade Edition Original Soundtrack - ストリートファイターV アーケードエディション オリジナル・サウンドトラック [FLAC]
setManifestid(807295, "7661322901939812758", 1822349186)
addappid(807296, 1, "e3edb7ff267ab2d081a17b78797c901713635b8d712aae0e9d17f85e835436d8") -- Street Fighter V Arcade Edition Original Soundtrack - ストリートファイターV アーケードエディション オリジナル・サウンドトラック [AAC]
setManifestid(807296, "4891206156582163900", 771965083)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(480520) -- Street Fighter V - Capcom Pro Tour 2016 Pack
addappid(590750) -- Street Fighter V - Capcom Pro Tour 2017 Premier Pass
addappid(789460) -- Street Fighter V - Capcom Pro Tour 2018 Premier Pass
addappid(995950) -- Street Fighter V - Capcom Pro Tour 2019 Premier Pass
addappid(1233100) -- Street Fighter V - Capcom Pro Tour 2020 Premier Pass
addappid(1405400) -- Street Fighter V - SFL2020 UYU Costumes Bundle
addappid(1405401) -- Street Fighter V - SFL2020 NASR Costumes Bundle
addappid(1503030) -- Street Fighter V - Capcom Pro Tour 2021 Premier Pass
addappid(1825950) -- Street Fighter V - Capcom Pro Tour 2022 Premier Pass
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Street Fighter V Champion Edition Original Soundtrack (AppID: 1403540) - missing depot keys
-- addappid(1403540)