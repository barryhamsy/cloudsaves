addappid(2362060, 1, "43d95e744211ec4d1671e74682b1c9d069e0564e51d304135a18c948f2df3367") -- CODE VEIN II
addtoken(2362060, "10049253451395720733")
-- MAIN APP DEPOTS
addappid(2362061, 1, "b01b93b4fd055fc2f23e77e6797ee933d5d83fbb293cf55442e567407723aa4b") -- Depot 2362061
setManifestid(2362061, "1995009758558788069", 67125014535)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3559210) -- CODE VEIN II - Custom Outfit Pack
addtoken(3559210, "9580235972559335095")
addappid(3559230) -- CODE VEIN II - CODE VEIN Character Costume Set
addtoken(3559230, "7040880122102985044")
addappid(3559240) -- CODE VEIN II - Stylized Forma Set
addtoken(3559240, "7796102293365901577")
addappid(3559250) -- CODE VEIN II - Deluxe Upgrade Pack
addtoken(3559250, "2371691821057026299")
addappid(3559260) -- CODE VEIN II - Ultimate Upgrade Pack
addtoken(3559260, "14728694277007258415")
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3559200) -- Depot 3559200 (empty depot)