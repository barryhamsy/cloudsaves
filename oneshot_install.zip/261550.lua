-- 261550's Lua and Manifest Created by Hubcap Manifest
-- Mount & Blade II: Bannerlord
-- Created: March 03, 2026 at 02:55:20 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(261550, 1, "979c4a097d819ee61862a7ad898e1a20dea3708a8dcbeaaa00a54c4975c1b107") -- Mount & Blade II: Bannerlord
-- MAIN APP DEPOTS
addappid(261552, 1, "b6cfe4c61b9f19a7399a290c50b3dc18052f63b095401ffb3aa8286277597365") -- Mount & Blade II: Bannerlord Disc Depot
setManifestid(261552, "5190102127508538142", 4867548209)
addappid(261551, 1, "16a71c423df683e98af58e40c60a6fc8087dc360f977a73c7d138e8d26b99062") -- Mount & Blade II Content
setManifestid(261551, "8316190348239003775", 61335580580)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Mount  Blade II Bannerlord - Digital Companion (AppID: 2240110)
addappid(2240110)
addappid(2240111, 1, "172d8d7fb867c14dfe3251829c334dd13bd3fa452eca4f34a3c583ed9928efea") -- Mount  Blade II Bannerlord - Digital Companion - Depot 2240111
setManifestid(2240111, "6194812840481947105", 1210058736)
-- Mount  Blade II Bannerlord - War Sails (AppID: 2927200)
addappid(2927200)
addappid(2927200, 1, "27f86f83a59f156011599d935b8f3f25a5472b9030cd56a2a91aa0597f939512") -- Mount  Blade II Bannerlord - War Sails - Depot 2927200
setManifestid(2927200, "3141806274536943164", 33393276540)