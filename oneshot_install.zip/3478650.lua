addappid(3478650, 1, "bae1c2f2922a2615da15651ab9306f3b4314b0765de99d37318ac1f366b68735") -- FreshWomen - Season 2
-- MAIN APP DEPOTS
addappid(3478651, 1, "ac18510eeb2d0b975c7fb8019572de8c568179c25d765f22223bce123eff775b") -- Depot 3478651
setManifestid(3478651, "4977488053936185106", 26808508874)
-- DLCS WITH DEDICATED DEPOTS
-- FreshWomen - Season 2 - Supporter Pack (AppID: 3930100)
addappid(3930100)
addappid(3930100, 1, "4cfc083bd45f19ea36197cdeafdf100cb186c1e56d447b80f94517f1fa9c60bd") -- FreshWomen - Season 2 - Supporter Pack - Depot 3930100
setManifestid(3930100, "4193197436706874424", 912935984)