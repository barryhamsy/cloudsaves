addappid(2677660, 1, "4b22dac540d24fab8fe0ce68b7166d192bd13bb6488c9a18de875706c9b32011") -- Indiana Jones and the Great Circle
addtoken(2677660, "11743623575295112529")
-- MAIN APP DEPOTS
addappid(2677661, 1, "0abf0860b7a1d53e5ae7b3ed8d7e97e668fa5619be6a6ad74c140c53871868bd") -- Depot 2677661
setManifestid(2677661, "1223798241005513044", 124652462329)
addappid(2677662, 1, "b4089fc44110008f2b07bc97f30e298c1ae457fa69964cdb239f480259baec84") -- Depot 2677662
setManifestid(2677662, "6807073924334951956", 410482600)
addappid(2830501, 1, "43cf88c0f48b755f8cb8d54bf6f3a04a2ed5551120d29b81c8ae098f26edbb0e") -- Depot 2830501
setManifestid(2830501, "6601360459876353050", 224920844)
addappid(2830502, 1, "c9fbb0008c00893bad5a3815793a4439d6a7d3ebcdc9bc6fe187a30f2ab326c7") -- Depot 2830502
setManifestid(2830502, "8007413738434142917", 307966856)
addappid(2830503, 1, "02d24f8070e356ac90fac5df5692432ee3e0ea0c1558e6bb78e76aade721cf68") -- Depot 2830503
setManifestid(2830503, "830671202293683776", 318175389)
addappid(2830504, 1, "ab46ce36b2648707946bc7ff2e1562491060503e25487e60fcc60e4a692f5c7b") -- Depot 2830504
setManifestid(2830504, "6629109004288775421", 316924506)
addappid(2830505, 1, "3a2de50a20a1204b2d32c00deb6b5f5082560e4e7ef80e78236b4a25299a5486") -- Depot 2830505
setManifestid(2830505, "2755672558638797836", 307566930)
addappid(2830506, 1, "1de09055224b1a241e117533dccab28c234008abe60653c30cd44f9ebf48e9f5") -- Depot 2830506
setManifestid(2830506, "3017367679564545429", 323221633)
addappid(2830507, 1, "fbde4f908358404a6544359f9c8c402bb8a40a336fb00fa92074cf4bf30143b2") -- Depot 2830507
setManifestid(2830507, "278507716317809228", 311372114)
addappid(2830508, 1, "f1808e29d18c4de5461e51d4e7d3f65b9a7eee466b91359150ad4588bdbbabe6") -- Depot 2830508
setManifestid(2830508, "6454515309235511181", 306280503)
addappid(2830509, 1, "7d4266463917726e639937e41582b2ba629c710a3a415dfaea90997ffd35e241") -- Depot 2830509
setManifestid(2830509, "6972604076386304594", 304321401)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Indiana Jones and the Great Circle The Order of Giants (AppID: 2830500)
addappid(2830500)
addappid(2830500, 1, "c51fae5748ae85fe9a754c5e7cb2bb783d4602005897d3401b00104492820eef") -- Indiana Jones and the Great Circle The Order of Giants - Depot 2830500
setManifestid(2830500, "2708321643392777102", 9416176109)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2830510) -- Indiana Jones and the Great Circle - Traveling Suit Outfit
addappid(2830520) -- Indiana Jones and the Great Circle - Lion Tamer Whip
addappid(2832880) -- Indiana Jones and the Great Circle - Temple of Doom Outfit
addappid(3138470) -- Indiana Jones and the Great Circle Digital Premium Upgrade