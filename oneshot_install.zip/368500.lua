addappid(368500) -- Assassin's Creed Syndicate
-- MAIN APP DEPOTS
addappid(368501, 1, "d1bdef91b5eaec4f3e423ca91fcfdf9431091873ffb54f6f72c040cc953b97e4") -- Assassin's Creed Syndicate Content
setManifestid(368501, "3950444377332639251", 40534548313)
addappid(368502, 1, "104abcec788393b8fdd109808cdd448282321f2ca2a2841bd144bf714a6c49c0") -- ww
setManifestid(368502, "7245430940335893091", 4334423232)
addappid(368503, 1, "a141f6692cc60dbbf88df0cb80c64887a85c1ab11b4f8c6b5f32c58443d5be37") -- russian
setManifestid(368503, "8445202823339236077", 584345759)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 632424)
-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed Syndicate - Jack The Ripper (AppID: 405080)
addappid(405080)
addappid(405080, 1, "0b90af327ed0210d31b63ebaf92971acbc3dd0d28ce213b5c7da0915a041b48a") -- Assassins Creed Syndicate - Jack The Ripper - Assassin's Creed Syndicate - Jack The Ripper (405080) Depot
setManifestid(405080, "7130849894187701516", 16473394809)
addappid(368504, 1, "fe94c08ddf5cca80f132536cc1fc78f52bb83920c7d7c25a065b1e2af798fdfc") -- Assassins Creed Syndicate - Jack The Ripper - DLC_WW
setManifestid(368504, "2992954383828961684", 557096682)
addappid(368505, 1, "8bb3f40ef7ed048b09cb108388bf7a67b3c488bfb865e592a87bf9cc3a4e7854") -- Assassins Creed Syndicate - Jack The Ripper - DLC_RUS
setManifestid(368505, "2445555025373299607", 65301364)
-- Assassins Creed Syndicate - Steampunk Pack (AppID: 407470)
addappid(407470)
addtoken(407470, "14313500131502997464")
addappid(407470, 1, "1c2aa26252e28e027a4ef7e686d7557f66d9d1a558c3daeb6a6c4eab6552acfd") -- Assassins Creed Syndicate - Steampunk Pack - Assassin's Creed Syndicate - WEAPON PACK 1 DLC (407470) Depot
setManifestid(407470, "3707348865287667255", 1494319104)
-- Assassins Creed Syndicate - Victorian Legends pack (AppID: 407471)
addappid(407471)
addtoken(407471, "11906388779735550720")
addappid(407471, 1, "4fb128097f83ca038a9ca86bf80ca2d030e47c314f274568906d2586ca2b8dd6") -- Assassins Creed Syndicate - Victorian Legends pack - Assassin's Creed Syndicate - WEAPON PACK 2 DLC (407471) Depot
setManifestid(407471, "1267306434745333523", 1493532672)
-- Assassins Creed Syndicate - Steampunk Outfit for Evie (AppID: 407472)
addappid(407472)
addtoken(407472, "10523805908066337608")
addappid(407472, 1, "4ada1b0ac4eaf0c9ddf28bdde57963e0e1bae66413d4c5262aadd3e8764e07c6") -- Assassins Creed Syndicate - Steampunk Outfit for Evie - Assassin's Creed Syndicate - OUTFIT 1 DLC (407472) Depot
setManifestid(407472, "6785341095949687424", 776830976)
-- Assassins Creed Syndicate - Victorian Legends Outfit for Jacob (AppID: 407473)
addappid(407473)
addtoken(407473, "9995795017656206850")
addappid(407473, 1, "faec6593cb6d2e6b32626b52677f86bb5201875eee76b2e27cf5b2d00bf5caaa") -- Assassins Creed Syndicate - Victorian Legends Outfit for Jacob - Assassin's Creed Syndicate - OUTFIT 2 DLC (407473) Depot
setManifestid(407473, "2255042779327026176", 738983936)
-- Assassins Creed Syndicate - The Last Maharaja (AppID: 407475)
addappid(407475)
addappid(407475, 1, "c1506ebebe02f663559ca77f6031bac61c86ea9dede7a44d22e391553d54afda") -- Assassins Creed Syndicate - The Last Maharaja - Assassin's Creed Syndicate - EXTRA STORIES DLC (407475) Depot
setManifestid(407475, "298960376516436252", 4665709424)
addappid(407476, 1, "c09880ee8e9d7f43f503b453d621475d21260f808c2a8ea3dcad8c84321e6e0a") -- Assassins Creed Syndicate - The Last Maharaja - Assassin's Creed Syndicate - TLM WW Depot
setManifestid(407476, "753387291892218228", 196423993)
addappid(407477, 1, "2ed345356b1c7f23d41c73dde724b24b97210e4071f17a0014895b3b31c5435f") -- Assassins Creed Syndicate - The Last Maharaja - Assassin's Creed Syndicate - TLM RUS Depot
setManifestid(407477, "2631881794433412166", 22576881)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(371020) -- Assassins Creed Syndicate Season Pass
addtoken(371020, "11342798832795940306")
addappid(407474) -- Assassins Creed Syndicate - Streets of London Pack
addappid(417960) -- Assassins Creed Syndicate - WW Pre-order Gold - Uplay Activation
addappid(417961) -- Assassins Creed Syndicate - WW Gold - Uplay Activation
addappid(417962) -- Assassins Creed Syndicate - WW - Uplay Activation
addappid(417963) -- Assassins Creed Syndicate - WW Pre-order - Uplay Activation
addappid(417964) -- Assassins Creed Syndicate - RU Pre-order Gold - Uplay Activation
addappid(417965) -- Assassins Creed Syndicate - RU Gold - Uplay Activation
addappid(417966) -- Assassins Creed Syndicate - RU - Uplay Activation
addappid(417967) -- Assassins Creed Syndicate - RU Pre-order - Uplay Activation
addappid(417968) -- Assassins Creed Syndicate - Season Pass - Uplay Activation
addappid(417970) -- Assassins Creed Syndicate - Jack The Ripper - Uplay Activation
addappid(417971) -- Assassins Creed Syndicate - Steampunk Pack - Uplay Activation
addappid(417972) -- Assassins Creed Syndicate - Victorian Legends Pack - Uplay Activation
addappid(417973) -- Assassins Creed Syndicate - Steampunk Outfit for Evie - Uplay Activation
addappid(417974) -- Assassins Creed Syndicate - Victorian Legends Outfit for Jacob - Uplay Activation
addappid(417975) -- Assassins Creed Syndicate - Streets of London Pack - Uplay Activation
addappid(417976) -- Assassins Creed Syndicate - The Last Maharaja - Uplay Activation
addappid(452960) -- Assassins Creed Syndicate - The Dreadful Crimes
addappid(456770) -- Assassins Creed Syndicate - The Dreadful Crimes Uplay Activation
addtoken(456770, "8782124308583257683")