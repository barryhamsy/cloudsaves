addappid(1114150, 1, "48650f4310aecbd46d7c261b9b6bdef32f593022e12ce27a39b2421526145a83") -- CarX Street
-- MAIN APP DEPOTS
addappid(1114151, 1, "472bd3a70105d0685574189912e9cf277940a72c562a19db7509fc56da74f3de") -- Depot 1114151
setManifestid(1114151, "6103919558744524490", 21016938358)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3028020) -- CarX Street - Deluxe Cars
addappid(3153040) -- CarX Street - DLC Sunset Speedway
addappid(3285610) -- Carx Street - Drift Cars
addappid(3480680) -- CarX Street - Pure Pulse
addappid(4209640) -- CarX Street - Build Your Car
