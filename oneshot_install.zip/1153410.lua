-- 1153410's Lua and Manifest Created by Hubcap Manifest
-- JDM: Japanese Drift Master
-- Created: December 19, 2025 at 14:56:42 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1153410) -- JDM: Japanese Drift Master
-- MAIN APP DEPOTS
addappid(1153411, 1, "aae6e034473725f27603fc003f2520e4df8111c1433317b84a92e8bb8fb64913") -- Depot 1153411
setManifestid(1153411, "5246107015794696966", 15741240767)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- JDM Japanese Drift Master - Support Pack (AppID: 3749550)
addappid(3749550)
addappid(3749551, 1, "ebe86f26c512a72840dfc92fcfd523c57ede0185d0150f30ea1f0e04a11a219d") -- JDM Japanese Drift Master - Support Pack - Depot 3749551
setManifestid(3749551, "3311103993817349003", 7002051648)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4054180) -- JDM Made in USA