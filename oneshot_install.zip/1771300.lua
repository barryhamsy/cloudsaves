addappid(1771300, 1, "3caed047b77bd7be8e68f818a3a6729b75371e0f67c871728c7a19de18aa6f53") -- Kingdom Come: Deliverance II
-- MAIN APP DEPOTS
addappid(1771302, 1, "41bc41c39ce79db318e98b533bab1fe71bfd294c4e8c90f90e4f8efa5fcc2a91") -- Depot 1771302
setManifestid(1771302, "4826030030885942644", 199406696)
addappid(1771303, 1, "397ab2e5c59bbb75f716c30dba3374be8af7ff49a2fc45c621e0bc23bafbd5f3") -- Depot 1771303
setManifestid(1771303, "3222098045559364073", 82572596199)
addappid(1771305, 1, "66d5a42e0171363eac9b79352c78401952d616880979d26967c385d2d7a88368") -- Depot 1771305
setManifestid(1771305, "4358917877440417639", 15251891829)
addappid(1771306, 1, "120aed0e767afa1ac85539240704d613b82c13473fcd7136d3cea555a784783e") -- Depot 1771306
setManifestid(1771306, "5397320021951793241", 13649866897)
addappid(1771307, 1, "8d47328b0b82d9b9ba25bfb199c69ea2dd005954298bd2aff2b448321569b727") -- Depot 1771307
setManifestid(1771307, "8613193015287904206", 11885139455)
addappid(1771308, 1, "b457fdf0e78f3465b9ccbfed5f8ecbb85f22428ba321534ee0df4a0d08754d02") -- Depot 1771308
setManifestid(1771308, "2880986098495496633", 12908230841)
addappid(1771309, 1, "1f8b55f9f4ac27eac8ffa310ca46163ee5aaad0937438035274a30b78de4e81a") -- Depot 1771309
setManifestid(1771309, "4150090098201849413", 12308102483)
addappid(3118101, 1, "69d3aecd16754fea50cf46182e56be5d29647e571e45c1dd1ef3294b966d0ee4") -- Depot 3118101
setManifestid(3118101, "459359545350465778", 12542800100)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Kingdom Come Deliverance II Artbook (AppID: 4075290)
addappid(4075290)
addappid(4075290, 1, "5719ab17163fb31ff02aedc90c95c0b06a0a0d66b687706cbef92a539a773b1b") -- Kingdom Come Deliverance II Artbook - Depot 4075290
setManifestid(4075290, "7365651604166421259", 355819526)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3118100) -- Kingdom Come Deliverance II The Lions Crest
addappid(3118110) -- Kingdom Come Deliverance II Gallant Huntsmans Kit
addappid(3118120) -- Kingdom Come Deliverance II Shields of Seasons Passing
addappid(3119920) -- Kingdom Come Deliverance II Expansion Pass
addappid(3368600) -- Kingdom Come Deliverance II Brushes with Death
addappid(3368610) -- Kingdom Come Deliverance II Legacy of the Forge
addappid(3368620) -- Kingdom Come Deliverance II Mysteria Ecclesiae