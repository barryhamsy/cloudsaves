addappid(1034140) -- Subverse
-- MAIN APP DEPOTS
addappid(1034141, 1, "9c712c1efc2a5b5f884a153935bfca195dbe00c3a2bba7d8ec93b2e29daeb527") -- Subverse Content
setManifestid(1034141, "8382418332524947103", 41231591493)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Subverse - 4KMovies (AppID: 3342820)
addappid(3342820)
addappid(3342820, 1, "d4e7b31fc2896aa5b8dbbfba739af9743b5faea198d0e66078f4ce1e8d16d2b0") -- Subverse - 4KMovies - Depot 3342820
setManifestid(3342820, "7228627330103879912", 30572164587)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Subverse - Celestina Unbound (AppID: 4245650) - missing depot keys
-- addappid(4245650)