-- MAIN APPLICATION
addappid(3717070, 1, "3571e3f8dbfafd5e2696b0e5f02e5497906f498f585edfd470a79d31610008af") -- WWE 2K26
-- MAIN APP DEPOTS
addappid(3717071, 1, "1bf7a881a3e1aceec7d3d40622e631e3d7472b7fb4a051051a5e151bb63d7c21") -- Depot 3717071
setManifestid(3717071, "7008707814501901259", 142920595514)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4125680) -- WWE 2K26 MyRISE Boost
addappid(4181540) -- WWE 2K26 Joe Hendry Pack
addappid(4181550) -- WWE 2K26 King of Kings Edition Pack
addappid(4181560) -- WWE 2K26 Attitude Era Edition Pack
addappid(4181570) -- WWE 2K26 Monday Night War Edition Pack
addappid(4181590) -- WWE 2K26 Ringside Pass Premium Season 1
addappid(4181610) -- WWE 2K26 Ringside Pass Premium Season 2
addappid(4333560) -- WWE 2K26 Season Pass
addappid(4357050) -- WWE 2K26 Superstar Mega-Boost
addappid(4429680) -- WWE 2K26 Monday Night War Edition