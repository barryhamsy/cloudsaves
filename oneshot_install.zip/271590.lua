addappid(271590, 1, "8f165460b5772d55a815775064a9735dee57b9bb222d7fa1eeb1c261fe8dd6ad") -- Grand Theft Auto V Legacy
-- MAIN APP DEPOTS
addappid(271591, 1, "baebeedec48b33c68a322fea0cbaa8d023d1dab4d2870aa909b82c33caa53941") -- Shetland Pony Content
setManifestid(271591, "971718195708802815", 76572017)
addappid(271592, 1, "e34313f0ec133a608e636cf04fd879d3ac1e8e10af38542436940be1b6834bee") -- Shetland Pony Depot
setManifestid(271592, "3190974936908963000", 30974647)
addappid(271593, 1, "71b57be5c50e5fbc819068a5bf31db42b653f1c75d88307da682ff0d5cae9457") -- Shetland Pony Depot
setManifestid(271593, "2967789647252082634", 17888398202)
addappid(271594, 1, "ae7ed6931a136d41d3aae146563368eb3b3e4e60963344f3f426c0abc74bbdab") -- Shetland Pony Depot
setManifestid(271594, "2961363011952051421", 70157768000)
addappid(271595, 1, "6dc0d2ce6b9dc96469ff792f6a607f759f0abd851d496cac73d71cd145c70b4d") -- Shetland Pony Depot
setManifestid(271595, "1376135673068470825", 39435642880)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b") -- RGL/SC Content (Shared from App 1899670)
setManifestid(1899671, "6894431991641066272", 218335277)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(362000) -- Grand Theft Auto V  Bonus 1,500,000  GTA San Andreas
addappid(362001) -- Grand Theft Auto V  Bonus 1,500,000
addappid(362002) -- Grand Theft Auto V  Bonus 1,350,000
addappid(362003) -- Grand Theft Auto V
addappid(413180) -- Grand Theft Auto V  Bonus 500,000
addappid(771300) -- Grand Theft Auto V Legacy - Criminal Enterprise Starter Pack