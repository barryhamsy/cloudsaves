addappid(2138710, 1, "74d4a05e74098d220d35e2bbba100a19cbadaeed357bb503d152a1b4294219ca") -- Sifu
-- MAIN APP DEPOTS
addappid(2138711, 1, "640993870daafc721632280e9e612a93f957d22bd8a16dcc526c3b8f73be0e33") -- Depot 2138711
setManifestid(2138711, "5545504035024010382", 32504249208)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sifu Digital Official Artbook (AppID: 2253841)
addappid(2253841)
addappid(2253841, 1, "27dc031b34fbcd34f1a8d7fd5658680f030c63aa34e8cfeb1a6c982888552d7f") -- Sifu Digital Official Artbook - Depot 2253841
setManifestid(2253841, "3893356194676043314", 34770887)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2231950) -- Sifu - Deluxe Cosmetic Pack