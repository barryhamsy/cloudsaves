-- 2622380's Lua and Manifest Created by Hubcap Manifest
-- ELDEN RING NIGHTREIGN
-- Created: March 31, 2026 at 05:08:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2622380, 1, "997d257d3a44c80b026acf14bc2c17b5280bec0051510350a580b1f76a7dc403") -- ELDEN RING NIGHTREIGN
-- MAIN APP DEPOTS
addappid(2622381, 1, "c3e9ccfedcda0cd10e53938e15261130b2e166007d2ca8f13aa5a05f06bd2630") -- Depot 2622381
setManifestid(2622381, "3117199117883238448", 27284638046)
addappid(2622383, 1, "c6e496ba5ae5c8bfa358f3a7d923ec39964fa0a41c4fa77006249fe34e677af2") -- Depot 2622383
setManifestid(2622383, "4090476371378011797", 118775416)
addappid(2622384, 1, "029f67382779483e0b34bc2f1a1fae303e7f83a4efead9ed076448f386afd28f") -- Depot 2622384
setManifestid(2622384, "2688544108317953872", 118775416)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- ELDEN RING NIGHTREIGN Digital Artbook  Mini Soundtrack (AppID: 3515600)
addappid(3515600)
addappid(3515600, 1, "698188f58b73df7953b831a1e83a2b75cce4a3ec24d6c8ea3e3869bed96219dd") -- ELDEN RING NIGHTREIGN Digital Artbook  Mini Soundtrack - Depot 3515600
setManifestid(3515600, "6335101482081834234", 419680750)
-- ELDEN RING NIGHTREIGN The Forsaken Hollows (AppID: 3531720)
addappid(3531720)
addappid(3531720, 1, "7869ded55b93c8a360d2b867c0f4dd91e0e1eb8a1de01d69a93c907a736d996c") -- ELDEN RING NIGHTREIGN The Forsaken Hollows - Depot 3531720
setManifestid(3531720, "455446701844620366", 882405589)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3319490) -- ELDEN RING NIGHTREIGN Bonus Gesture
addappid(3515610) -- ELDEN RING NIGHTREIGN - Deluxe Upgrade Pack
addappid(3637850) -- ELDEN RING NIGHTREIGN CE Content (Retail)