addappid(381210) -- Dead by Daylight
-- MAIN APP DEPOTS
addappid(381211, 1, "66477a849ed619510d127ff3f05d4d37b38a04fd7074654337053dfe817798ca") -- Dead by Daylight Content
setManifestid(381211, "943169454632267910", 57816375564)
addappid(381212, 1, "d514d170477029b1fc73e157f9550e3591facfc4508a7568deaf4599fc3a54b4") -- Dead by Daylight Digital Artbook
setManifestid(381212, "5921550076694751899", 31578081)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Dead by Daylight Original Soundtrack (AppID: 492140)
addappid(492140)
addappid(381213, 1, "525dbbc5d40bca2cd810f8cb48945f893aa16ca7c1ea90895e0d0c498f183ff5") -- Dead by Daylight Original Soundtrack - Dead by Daylight Original Soundtrack
setManifestid(381213, "6590975724534196178", 80741698)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(509060) -- Dead by Daylight The Last Breath Chapter
addappid(530711) -- Dead by Daylight - The Halloween Chapter
addappid(573940) -- Dead by Daylight - Left Behind
addappid(627510) -- Dead by Daylight - Charity Case
addappid(661770) -- Dead by Daylight - A Lullaby for the Dark
addappid(700280) -- Dead by Daylight LEATHERFACE
addappid(700282) -- Dead by Daylight - A Nightmare on Elm Street
addappid(750381) -- Dead by Daylight - The Saw Chapter
addappid(1009821) -- Dead by Daylight - Ash vs Evil Dead
addappid(1089270) -- Dead by Daylight Ghost Face
addappid(1135280) -- Dead by Daylight - Stranger Things Chapter
addappid(1324970) -- Dead By Daylight - Silent Hill Chapter
addappid(1622940) -- Dead by Daylight - Terror Expansion Pack
addappid(1622941) -- Dead by Daylight - Escape Expansion Pack
addappid(1634040) -- Dead by Daylight - Resident Evil Chapter
addappid(1899750) -- Dead by Daylight - Sadako Rising Chapter
addappid(2102730) -- Dead by Daylight - Resident Evil PROJECT W Chapter
addappid(2399750) -- Dead by Daylight - End Transmission Chapter
addappid(2469400) -- Dead by Daylight - Nicolas Cage Chapter Pack
addappid(2515990) -- Dead by Daylight - Alien Chapter Pack
addappid(2526530) -- Dead by Daylight - Maddening Darkness Pack
addappid(2526540) -- Dead by Daylight - Old Wounds Pack
addappid(2526550) -- Dead by Daylight - Macabre Tales Pack
addappid(2656010) -- Dead by Daylight - Chucky Chapter
addappid(2661250) -- Dead by Daylight - Alan Wake Chapter
addappid(2661270) -- Dead by Daylight - All Things Wicked Chapter
addappid(2922730) -- Dead by Daylight - Endless Hunt Pack
addappid(2958440) -- Dead by Daylight - Dungeons  Dragons
addappid(3024580) -- Dead by Daylight - Tomb Raider Chapter
addappid(3103150) -- Dead by Daylight - Castlevania Chapter
addappid(3261720) -- Dead by Daylight - Doomed Course Chapter
addappid(3448670) -- Dead by Daylight - Tokyo Ghoul
addappid(3698790) -- Dead by Daylight - Steady Pulse
addappid(3796620) -- Dead by Daylight Five Nights at Freddys
addappid(3884020) -- Dead by Daylight The Walking Dead
addappid(4019590) -- Dead by Daylight - Sinister Grace