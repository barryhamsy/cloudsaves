-- 1687950's Lua and Manifest Created by Morrenus
-- Persona 5 Royal
-- Created: September 30, 2025 at 06:24:50 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 12
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1687950) -- Persona 5 Royal
-- MAIN APP DEPOTS
addappid(1687951, 1, "63d197a9660d17f1f93004f842b51a99590dcb140cfa4b33b67f04b66e3ef2dc") -- Depot 1687951
addappid(1687952, 1, "786ef5979ef545b2322dcda59e5f0ccaaadd321a9f6ac7522b6a55198edff0b6") -- Depot 1687952
addappid(1687953, 1, "0d1a567ea2ea013eb35cae7c62deac6973987d8f0cf5585326fc9f0cec3f0868") -- Depot 1687953
addappid(1687954, 1, "26d7d88b05209c16a6ca45297dcaaa774b2185b6a74970bac121c1f5cb37b1d9") -- Depot 1687954
addappid(1687955, 1, "987640b74d60f9c60cbf8d2899469cd1d552f00df1da5a3aba3dfa44ea6f375a") -- Depot 1687955
addappid(1687956, 1, "c7b8a0e3c11d039f34b797ce0ce792926c0cb6e70c5cdac969785c85d7d29133") -- Depot 1687956
addappid(1687957, 1, "cd181cf543f85bc275f52e8836e5090293530f895c6109be61bbf8735fd1fa60") -- Depot 1687957
addappid(1687958, 1, "bcd88777efb6608bbd36b99c813acfda482f0a0ae1ebbef6844e9f9bb46c5872") -- Depot 1687958
addappid(1687959, 1, "4ed788043739d211ea18eaf3837f9739527b60da089c778b896d9baa05a16415") -- Depot 1687959
addappid(1753980, 1, "5373b843f2355df32399e1130a468df8893039961569bde75192c1be9e05f0d6") -- Depot 1753980
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)


-- Auto added manifests
setManifestid(1687951,"179949564195054526",1)
setManifestid(1687952,"3167861682612256520",1)
setManifestid(1687953,"676724932591096292",1)
setManifestid(1687954,"4383202142358403441",1)
setManifestid(1687955,"1440355225172460061",1)
setManifestid(1687956,"7521686342464165318",1)
setManifestid(1687957,"748315061441883037",1)
setManifestid(1687958,"4651383591850403589",1)
setManifestid(1687959,"223453434450812259",1)
setManifestid(1753980,"3263965511551036653",1)
