addappid(962130) -- Grounded
-- MAIN APP DEPOTS
addappid(962131, 1, "809ed5f98fa8a3d2c3636c33504157cf05fc683e1810d35e554d7976573a4424") -- Maine - Windows
setManifestid(962131, "1768200224774657340", 12144883677)
addappid(962134, 1, "d8b1b4a7d68cf73a4aade13a9d230c6f1b7b397273cfad6b1a5713c631170002") -- Depot 962134
setManifestid(962134, "5364155453177518539", 0)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)